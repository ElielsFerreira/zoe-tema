<?php

/**
 * Mensagens personalizadas e envios de e-mail em massa para inscritos.
 *
 * - Cada evento pode ter assunto e mensagem próprios no e-mail de confirmação
 *   (metas _zoe_email_assunto e _zoe_email_msg). Aceitam {nome} e {evento}.
 * - Envio em massa: "confirmacao" reenvia a confirmação de cada pedido (com
 *   assunto/mensagem extra opcionais); "aviso" manda um e-mail livre, com o
 *   visual da Zoe, uma vez por endereço.
 * - Os envios vão em lotes pequenos (8 por minuto), em segundo plano, para
 *   não estourar o limite de e-mails por hora da hospedagem.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_ENVIO_LOTE', 8);

/** Troca {nome} e {evento} pelos dados do pedido. */
function zoe_conf_tokens($txt, $order = null, $nome = '', $evento = '')
{
    if ($order) {
        $nome = zoe_conf_primeiro_nome($order);
        $its  = zoe_conf_itens($order);
        $evento = $its ? $its[0]['nome'] : '';
    }
    $txt = (string) $txt;
    if (trim($nome) === '') {
        // sem nome no pedido: "Oi {nome}!" vira "Oi!" e "Tudo certo, {nome}!" vira "Tudo certo!"
        $txt = preg_replace('/[,\s]*\{nome\}/u', '', $txt);
    }
    return strtr($txt, array('{nome}' => $nome, '{evento}' => $evento));
}

/** Mensagem livre: quebras de linha, links clicáveis, link de grupo do WhatsApp vira botão. */
function zoe_msg_html($txt)
{
    $grupos = array();
    $txt = preg_replace_callback('~https?://chat\.whatsapp\.com/[A-Za-z0-9]+~', function ($m) use (&$grupos) {
        $grupos[] = $m[0];
        return '';
    }, (string) $txt);
    $html = '';
    foreach (preg_split("/\n\s*\n/", trim($txt)) as $par) {
        if (trim($par) !== '') {
            $html .= '<p style="margin:0 0 12px">' . nl2br(make_clickable(esc_html(trim($par)))) . '</p>';
        }
    }
    foreach (array_unique($grupos) as $g) {
        $html .= zoe_conf_botao($g, 'Entrar no grupo do WhatsApp', '#25D366');
    }
    return $html;
}

/** E-mail livre com o visual da Zoe. */
function zoe_aviso_html($assunto, $mensagem, $nome = '')
{
    $f     = 'font-family:Arial,Helvetica,sans-serif;';
    $site  = get_bloginfo('name');
    $logo  = function_exists('zoe_img') ? zoe_img(zoe_opt('logo'), 'thumbnail') : '';
    $whats = zoe_link_whats(zoe_opt('whatsapp'));
    $insta = (string) zoe_opt('instagram');
    $end   = (string) zoe_opt('endereco');
    $razao = (string) zoe_opt('razao');
    $html  = '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html($assunto) . '</title></head><body style="margin:0;padding:0;background:#f3f1ee">'
        . '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="background:#f3f1ee"><tr><td align="center" style="padding:24px 12px">'
        . '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:18px;overflow:hidden">'
        . '<tr><td style="background:#141216;padding:22px 26px"><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr>'
        . ($logo ? '<td style="padding-right:12px"><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td bgcolor="#ffffff" style="background:#ffffff;border-radius:50%;padding:3px;line-height:0"><img src="' . esc_url($logo) . '" width="38" height="38" alt="Zoe" style="display:block;width:38px;height:38px;border-radius:50%;border:0"></td></tr></table></td>' : '')
        . '<td style="' . $f . 'font-size:18px;font-weight:bold;color:#ffffff">' . esc_html($site) . '</td></tr></table></td></tr>'
        . '<tr><td style="padding:30px 26px 6px;' . $f . 'color:#141216">'
        . '<h1 style="margin:0 0 14px;' . $f . 'font-size:24px;line-height:1.25;color:#141216">' . ($nome ? 'Olá, ' . esc_html($nome) . '!' : esc_html($assunto)) . '</h1>'
        . '<div style="font-size:16px;line-height:1.6;color:#3d3a40">' . zoe_msg_html($mensagem) . '</div></td></tr>'
        . ($whats ? '<tr><td style="padding:10px 26px 6px;' . $f . 'font-size:15px;line-height:1.6;color:#3d3a40"><p style="margin:0 0 6px">Ficou alguma dúvida? Fale com a gente:</p>' . zoe_conf_botao($whats, 'Falar no WhatsApp', '#141216') . '</td></tr>' : '')
        . '<tr><td style="padding:22px 26px 26px;' . $f . 'font-size:12px;line-height:1.6;color:#8d8792;border-top:1px solid #f0ece7">'
        . esc_html($razao ? $razao : $site) . '<br>' . ($end ? esc_html($end) . '<br>' : '')
        . '<a href="' . esc_url(home_url('/')) . '" style="color:#8d8792">' . esc_html(wp_parse_url(home_url(), PHP_URL_HOST)) . '</a>' . ($insta ? ' · <a href="' . esc_url($insta) . '" style="color:#8d8792">Instagram</a>' : '')
        . '</td></tr></table></td></tr></table></body></html>';
    return $html;
}

function zoe_aviso_enviar($para, $assunto, $mensagem, $nome = '', $evento = '')
{
    $assunto  = zoe_conf_tokens($assunto, null, $nome, $evento);
    $mensagem = zoe_conf_tokens($mensagem, null, $nome, $evento);
    return wp_mail($para, $assunto, zoe_aviso_html($assunto, $mensagem, $nome), array('Content-Type: text/html; charset=UTF-8'));
}

/** Pedidos pagos que contêm algum dos produtos, nos últimos N dias (0 = todos). */
function zoe_envio_pedidos($produtos, $dias)
{
    global $wpdb;
    $produtos = array_values(array_filter(array_map('absint', (array) $produtos)));
    if (!$produtos) {
        return array();
    }
    $in  = implode(',', $produtos);
    $ids = $wpdb->get_col(
        "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
         JOIN {$wpdb->prefix}woocommerce_order_itemmeta im ON im.order_item_id = oi.order_item_id
         WHERE oi.order_item_type = 'line_item' AND im.meta_key = '_product_id' AND im.meta_value IN ($in)" // phpcs:ignore
    );
    $limite = $dias > 0 ? time() - $dias * DAY_IN_SECONDS : 0;
    $out = array();
    foreach ($ids as $id) {
        $o = wc_get_order((int) $id);
        if (!$o || !is_a($o, 'WC_Order') || !in_array($o->get_status(), array('processing', 'completed'), true)) {
            continue;
        }
        $d = $o->get_date_paid() ? $o->get_date_paid() : $o->get_date_created();
        if ($limite && (!$d || $d->getTimestamp() < $limite)) {
            continue;
        }
        $out[] = $o;
    }
    usort($out, function ($a, $b) {
        return $a->get_id() - $b->get_id();
    });
    return $out;
}

/** Monta a lista de destinos de um envio. */
function zoe_envio_alvos($modo, $produtos, $dias)
{
    $alvos = array();
    $vistos = array();
    foreach (zoe_envio_pedidos($produtos, $dias) as $o) {
        $email = zoe_conf_email($o);
        if (!$email) {
            continue;
        }
        if ($modo === 'aviso') {
            $k = strtolower($email);
            if (isset($vistos[$k])) {
                continue;
            }
            $vistos[$k] = true;
            $its = zoe_conf_itens($o);
            $alvos[] = array('e' => $email, 'n' => zoe_conf_primeiro_nome($o), 'ev' => $its ? $its[0]['nome'] : '', 'o' => $o->get_id());
        } else {
            $alvos[] = array('e' => $email, 'o' => $o->get_id());
        }
    }
    return $alvos;
}

function zoe_envios()
{
    $j = get_option('zoe_envios', array());
    return is_array($j) ? $j : array();
}

function zoe_envio_salvar($id, $job)
{
    $todos = zoe_envios();
    $todos[$id] = $job;
    // guarda só os 20 envios mais recentes
    if (count($todos) > 20) {
        $todos = array_slice($todos, -20, null, true);
    }
    update_option('zoe_envios', $todos, false);
}

/** Envia um destino. Retorna true/false. */
function zoe_envio_um($job, $alvo, $para = null)
{
    $para = $para ? $para : $alvo['e'];
    if ($job['modo'] === 'aviso') {
        return zoe_aviso_enviar($para, $job['assunto'], $job['mensagem'], isset($alvo['n']) ? $alvo['n'] : '', isset($alvo['ev']) ? $alvo['ev'] : '');
    }
    $o = wc_get_order($alvo['o']);
    if (!$o) {
        return false;
    }
    $GLOBALS['zoe_conf_extra']   = $job['mensagem'];
    $GLOBALS['zoe_conf_assunto'] = $job['assunto'];
    $ok = false;
    if ($para !== $alvo['e']) {
        // teste: manda a confirmação deste pedido para outro endereço, sem marcar o pedido
        $GLOBALS['zoe_conf_retro'] = true;
        $html = zoe_conf_html($o);
        $GLOBALS['zoe_conf_retro'] = false;
        $its  = zoe_conf_itens($o);
        $ass  = $job['assunto'] ? zoe_conf_tokens($job['assunto'], $o) : 'Inscrição confirmada' . ($its ? ': ' . $its[0]['nome'] : '');
        $ok   = wp_mail($para, '[TESTE] ' . $ass, $html, array('Content-Type: text/html; charset=UTF-8'));
    } else {
        $ok = zoe_conf_enviar($o, true);
    }
    $GLOBALS['zoe_conf_extra']   = '';
    $GLOBALS['zoe_conf_assunto'] = '';
    return $ok;
}

/** Processa o próximo lote de um envio e agenda o seguinte. */
function zoe_envio_lote($id)
{
    $todos = zoe_envios();
    if (empty($todos[$id]) || $todos[$id]['status'] !== 'enviando') {
        return;
    }
    $job = $todos[$id];
    if (get_transient('zoe_envio_trava_' . $id)) {
        return;
    }
    set_transient('zoe_envio_trava_' . $id, 1, 120);
    $fim = min(count($job['alvos']), $job['pos'] + ZOE_ENVIO_LOTE);
    for ($i = $job['pos']; $i < $fim; $i++) {
        if (zoe_envio_um($job, $job['alvos'][$i])) {
            $job['ok']++;
        } else {
            $job['falhas'][] = $job['alvos'][$i]['e'];
        }
        $job['pos'] = $i + 1;
    }
    $job['ultimo'] = time();
    if ($job['pos'] >= count($job['alvos'])) {
        $job['status'] = 'concluido';
        $job['fim'] = time();
    } else {
        wp_schedule_single_event(time() + 60, 'zoe_envio_lote', array($id));
    }
    zoe_envio_salvar($id, $job);
    delete_transient('zoe_envio_trava_' . $id);
}
add_action('zoe_envio_lote', 'zoe_envio_lote');

/** Se o agendador do WordPress atrasar, a próxima consulta de status empurra o envio. */
function zoe_envio_destravar()
{
    foreach (zoe_envios() as $id => $j) {
        if ($j['status'] === 'enviando' && time() - (int) $j['ultimo'] > 150) {
            zoe_envio_lote($id);
        }
    }
}

function zoe_envio_resumo($id, $j)
{
    $total = count($j['alvos']);
    $falta = $total - $j['pos'];
    return array(
        'id' => $id,
        'status' => $j['status'],
        'modo' => $j['modo'],
        'assunto' => $j['assunto'],
        'criado' => date_i18n('d/m/Y H:i', $j['criado']),
        'por' => $j['por'],
        'total' => $total,
        'enviados' => $j['ok'],
        'falhas' => count($j['falhas']),
        'enderecos_com_falha' => array_slice($j['falhas'], 0, 20),
        'faltam' => $falta,
        'previsao_fim' => $j['status'] === 'enviando' ? 'cerca de ' . max(1, (int) ceil($falta / ZOE_ENVIO_LOTE)) . ' min' : '',
    );
}
