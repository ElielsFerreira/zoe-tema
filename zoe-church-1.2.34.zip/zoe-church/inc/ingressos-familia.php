<?php
/**
 * Auditoria de entrega dos ingressos e envio "por família".
 *
 * - Junta os pedidos pagos com ingresso (eventos com check-in) por e-mail: o pedido do START
 *   dos pais e o pedido do Kids dos filhos com o mesmo e-mail viram um grupo só. Pedidos sem
 *   e-mail (formulário antigo) entram no grupo de quem tem o mesmo telefone.
 * - Diz quem recebeu e quem não: sem e-mail, nunca enviado, ou enviado pelo servidor da
 *   hospedagem para Hotmail/Outlook antes da Brevo (a Microsoft bloqueava o IP).
 * - Envia um e-mail único por família com todos os QR Codes, e a confirmação de compra
 *   de quem nunca recebeu.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Domínios da Microsoft, que recusavam o servidor da hospedagem. */
function zoe_fam_e_ms($email)
{
    return (bool) preg_match('/@(hotmail|outlook|live|msn|windowslive)\.[a-z.]+$/i', $email);
}

/** E-mails que a Brevo aceitou: email => último envio aceito (timestamp). */
function zoe_fam_brevo_ok()
{
    $out = array();
    foreach ((array) get_option('zoe_brevo_log', array()) as $l) {
        if (empty($l['ok']) || empty($l['para'])) {
            continue;
        }
        foreach (array_map('trim', explode(',', strtolower($l['para']))) as $e) {
            $out[$e] = max(isset($out[$e]) ? $out[$e] : 0, (int) $l['t']);
        }
    }
    return $out;
}

function zoe_fam_tels($o)
{
    $tels = array();
    $ct = function_exists('zoe_pend_contato') ? zoe_pend_contato($o) : array('tel' => $o->get_billing_phone());
    $tels[] = $ct['tel'];
    foreach ($o->get_items() as $it) {
        $insc = $it->get_meta('_zoe_inscricoes');
        if (is_array($insc)) {
            foreach ($insc as $d) {
                foreach ((array) $d as $k => $v) {
                    if (is_string($v) && preg_match('/whats|telefone|contato/i', $k)) {
                        $tels[] = $v;
                    }
                }
            }
        }
    }
    $out = array();
    foreach ($tels as $t) {
        $k = substr(preg_replace('/\D/', '', (string) $t), -8);
        if (strlen($k) === 8) {
            $out[$k] = true;
        }
    }
    return array_keys($out);
}

/**
 * Grupos (famílias) com situação de entrega.
 * $falharam: e-mails que o rastreio mostrou que não receberam.
 */
function zoe_fam_grupos($falharam = array())
{
    $falharam = array_map('strtolower', array_map('trim', (array) $falharam));
    $evs = zoe_ci_eventos_ativos();
    $porPedido = array();
    foreach (zoe_ci_lista($evs) as $i) {
        $porPedido[$i['pedido']][] = $i;
    }
    $brevo = zoe_fam_brevo_ok();
    $brevoDesde = $brevo ? min($brevo) : PHP_INT_MAX;
    $grupos = array();
    $telParaGrupo = array();
    $semEmail = array();
    foreach ($porPedido as $oid => $ings) {
        $o = wc_get_order($oid);
        if (!$o) {
            continue;
        }
        $email = strtolower(zoe_conf_email($o));
        if ($email === '') {
            $semEmail[$oid] = array($o, $ings);
            continue;
        }
        if (!isset($grupos[$email])) {
            $grupos[$email] = array('email' => $email, 'pedidos' => array(), 'ingressos' => array());
        }
        $grupos[$email]['pedidos'][$oid] = $o;
        $grupos[$email]['ingressos'] = array_merge($grupos[$email]['ingressos'], $ings);
        foreach (zoe_fam_tels($o) as $t) {
            if (!isset($telParaGrupo[$t])) {
                $telParaGrupo[$t] = $email;
            }
        }
    }
    // Pedido sem e-mail com o mesmo telefone de uma família: entra nela.
    $soltos = array();
    foreach ($semEmail as $oid => $par) {
        $dest = '';
        foreach (zoe_fam_tels($par[0]) as $t) {
            if (isset($telParaGrupo[$t])) {
                $dest = $telParaGrupo[$t];
                break;
            }
        }
        if ($dest) {
            $grupos[$dest]['pedidos'][$oid] = $par[0];
            $grupos[$dest]['ingressos'] = array_merge($grupos[$dest]['ingressos'], $par[1]);
            $grupos[$dest]['agregados'][] = $oid;
        } else {
            $soltos[$oid] = $par;
        }
    }
    $out = array();
    foreach ($grupos as $email => $g) {
        $ms = zoe_fam_e_ms($email);
        $bOk = isset($brevo[$email]) ? $brevo[$email] : 0;
        $nunca = array();
        $semConf = array();
        $ultimoEnvio = 0;
        foreach ($g['pedidos'] as $oid => $o) {
            $env = max((int) $o->get_meta('_zoe_ci_enviado'), (int) $o->get_meta('_zoe_confirmacao'));
            if (!$env) {
                $nunca[] = $oid;
            }
            if (!$o->get_meta('_zoe_confirmacao')) {
                $semConf[] = $oid;
            }
            $ultimoEnvio = max($ultimoEnvio, $env);
        }
        $motivo = '';
        if (in_array($email, $falharam, true) && !$bOk) {
            $motivo = 'rastreio mostrou falha';
        } elseif ($nunca && count($nunca) === count($g['pedidos'])) {
            $motivo = 'nunca enviado';
        } elseif ($nunca) {
            $motivo = 'parte dos pedidos nunca enviada';
        } elseif ($ms && !$bOk) {
            $motivo = 'Hotmail/Outlook bloqueava o servidor antigo';
        }
        $orids = array_keys($g['pedidos']);
        sort($orids);
        $out[] = array(
            'email'     => $email,
            'pedidos'   => $orids,
            'familia'   => count($orids) > 1,
            'ingressos' => count($g['ingressos']),
            'nomes'     => array_values(array_unique(wp_list_pluck($g['ingressos'], 'nome'))),
            'eventos'   => array_values(array_unique(wp_list_pluck($g['ingressos'], 'evento'))),
            'recebeu'   => $motivo === '',
            'motivo'    => $motivo,
            'sem_confirmacao' => $semConf,
            'brevo'     => $bOk ? wp_date('d/m H:i', $bOk) : '',
            'agregados' => isset($g['agregados']) ? $g['agregados'] : array(),
            'familia_enviada' => count($orids) > 1 && (int) reset($g['pedidos'])->get_meta('_zoe_fam_enviado') >= count($g['ingressos']),
        );
    }
    foreach ($soltos as $oid => $par) {
        $out[] = array(
            'email'     => '',
            'pedidos'   => array($oid),
            'familia'   => false,
            'ingressos' => count($par[1]),
            'nomes'     => array_values(array_unique(wp_list_pluck($par[1], 'nome'))),
            'eventos'   => array_values(array_unique(wp_list_pluck($par[1], 'evento'))),
            'recebeu'   => false,
            'motivo'    => 'sem e-mail no pedido',
            'link'      => zoe_ci_link_ingresso($oid),
        );
    }
    return $out;
}

/** E-mail único com os ingressos de todos os pedidos da família. */
function zoe_fam_email_html($pedidos, $ings)
{
    // Quem recebe é quem fez o pedido do evento principal (adultos antes do Kids).
    usort($pedidos, function ($a, $b) {
        return $a->get_id() - $b->get_id();
    });
    $principal = $pedidos[0];
    foreach ($pedidos as $o) {
        foreach ($o->get_items() as $it) {
            if (!preg_match('/kids|konnect/i', $it->get_name())) {
                $principal = $o;
                break 2;
            }
        }
    }
    // Adultos primeiro, depois Kids; dentro de cada evento, na ordem dos pedidos.
    usort($ings, function ($a, $b) {
        $ka = preg_match('/kids|konnect/i', $a['evento']) ? 1 : 0;
        $kb = preg_match('/kids|konnect/i', $b['evento']) ? 1 : 0;
        return $ka !== $kb ? $ka - $kb : ($a['pedido'] - $b['pedido'] ?: $a['vaga'] - $b['vaga']);
    });
    $nome = zoe_conf_primeiro_nome($principal);
    $evs = array_values(array_unique(wp_list_pluck($ings, 'evento')));
    $txt = 'font-size:16px;line-height:1.65;color:#3d3a40';
    $c  = zoe_email_eyebrow('Ingressos da família · ' . implode(' + ', $evs));
    $c .= zoe_email_titulo('Olá' . ($nome ? ', ' . $nome : '') . '.');
    $c .= '<div style="' . $txt . ';margin:0 0 24px"><p style="margin:0 0 12px">Aqui estão, juntos, todos os ingressos das inscrições feitas com este e-mail (' . count($ings) . '). No dia, é só mostrar o QR Code na entrada: cada pessoa tem o seu.</p>'
        . '<p style="margin:0;color:#6f6a74;font-size:14px">Dica: deixe este e-mail à mão no celular ou tire um print de cada QR Code.</p></div>';
    $c .= zoe_ci_cards_html($ings);
    foreach ($pedidos as $o) {
        $c .= '<div style="margin:8px 0 0">' . zoe_conf_botao(zoe_ci_link_ingresso($o->get_id()), 'Abrir ingressos do pedido nº ' . $o->get_order_number(), '#141216') . '</div>';
    }
    $nums = array_map(function ($o) {
        return $o->get_order_number();
    }, $pedidos);
    $c .= '<div style="font-size:13px;line-height:1.7;color:#6f6a74;margin-top:18px">Pedidos nº ' . esc_html(implode(', ', $nums)) . '. Se o QR Code não abrir, é só dizer o nome na recepção.</div>';
    $assunto = 'Ingressos da família · ' . implode(' + ', $evs);
    return array($assunto, zoe_email_moldura($assunto, $c, zoe_conf_capa($ings[0]['pid']), ''));
}

/**
 * Envia para um grupo: confirmação de compra dos pedidos que nunca tiveram (já leva o QR do pedido)
 * e, se a família tem mais de um pedido, um e-mail com todos os QR Codes juntos.
 */
function zoe_fam_enviar($email, $pedidos_ids)
{
    $pedidos = array();
    $ings = array();
    foreach ($pedidos_ids as $oid) {
        $o = wc_get_order($oid);
        if ($o) {
            $pedidos[] = $o;
            $ings = array_merge($ings, zoe_ci_ingressos($o));
        }
    }
    if (!$pedidos || !$ings || !is_email($email)) {
        return array('ok' => false, 'motivo' => 'sem pedidos/ingressos ou e-mail inválido');
    }
    $feito = array();
    // Confirmação (comprovante) para quem nunca recebeu, ou recebeu só pelo servidor bloqueado.
    $ms = zoe_fam_e_ms($email);
    $brevo = zoe_fam_brevo_ok();
    foreach ($pedidos as $o) {
        if (strtolower(zoe_conf_email($o)) !== strtolower($email)) {
            continue; // pedido agregado sem e-mail: vai só no e-mail da família
        }
        $precisa = !$o->get_meta('_zoe_confirmacao') || ($ms && empty($brevo[strtolower($email)]));
        if ($precisa && function_exists('zoe_conf_enviar')) {
            zoe_conf_enviar($o, true);
            $feito[] = 'confirmação ' . $o->get_id();
        }
    }
    if (count($pedidos) > 1) {
        list($assunto, $html) = zoe_fam_email_html($pedidos, $ings);
        $ok = wp_mail($email, $assunto, $html, array('Content-Type: text/html; charset=UTF-8'));
        if ($ok) {
            foreach ($pedidos as $o) {
                $o->update_meta_data('_zoe_ci_enviado', time());
                $o->update_meta_data('_zoe_fam_enviado', count($ings));
                $o->add_order_note('Ingressos da família (' . count($ings) . ') enviados juntos para ' . $email . '.');
                $o->save();
            }
            $feito[] = 'família ' . count($ings) . ' QR';
        }
    } elseif (!$feito) {
        $ok = zoe_ci_enviar($pedidos[0], '');
        if ($ok) {
            $feito[] = 'ingresso';
        }
    }
    return array('ok' => (bool) $feito, 'enviado' => $feito);
}
