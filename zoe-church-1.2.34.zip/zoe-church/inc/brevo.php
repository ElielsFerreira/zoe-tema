<?php
/**
 * Envio de todos os e-mails do site pela API da Brevo (HTTPS, porta 443).
 *
 * A hospedagem bloqueia SMTP para servidores de fora e o IP dela está na lista de bloqueio
 * da Microsoft (Hotmail/Outlook). Com a chave da API configurada em Zoe Eventos → Relatórios,
 * todo wp_mail() (WooCommerce, ingressos, avisos, relatórios) sai pela Brevo, com o domínio
 * zoechurchfrg.com.br autenticado. Se a Brevo falhar, o e-mail cai no envio padrão da hospedagem.
 */
if (!defined('ABSPATH')) {
    exit;
}

function zoe_brevo_opcoes()
{
    $o = get_option('zoe_brevo', array());
    return wp_parse_args(is_array($o) ? $o : array(), array('chave' => '', 'remetente' => '', 'nome' => '', 'ativo' => 1));
}

function zoe_brevo_chave()
{
    $o = zoe_brevo_opcoes();
    if (!$o['chave'] || empty($o['ativo'])) {
        return '';
    }
    return function_exists('zoe_smtp_senha') ? zoe_smtp_senha($o['chave']) : '';
}

/** Lista "Nome <email>, outro@x" em array de ['email'=>..., 'name'=>...]. */
function zoe_brevo_enderecos($lista)
{
    if (!is_array($lista)) {
        $lista = explode(',', (string) $lista);
    }
    $out = array();
    foreach ($lista as $item) {
        $item = trim((string) $item);
        if ($item === '') {
            continue;
        }
        $nome = '';
        if (preg_match('/^(.*)<\s*([^>]+)\s*>$/', $item, $m)) {
            $nome = trim(trim($m[1]), '"\' ');
            $item = trim($m[2]);
        }
        if (!is_email($item)) {
            continue;
        }
        $e = array('email' => $item);
        if ($nome !== '') {
            $e['name'] = $nome;
        }
        $out[] = $e;
    }
    return $out;
}

/** Guarda os últimos envios (para rastrear quem recebeu). */
function zoe_brevo_log($para, $assunto, $ok, $info)
{
    $log = get_option('zoe_brevo_log', array());
    if (!is_array($log)) {
        $log = array();
    }
    array_unshift($log, array(
        't'   => time(),
        'para' => implode(', ', array_map(function ($e) {
            return $e['email'];
        }, $para)),
        'assunto' => mb_substr((string) $assunto, 0, 120),
        'ok'  => $ok ? 1 : 0,
        'info' => mb_substr((string) $info, 0, 300),
    ));
    update_option('zoe_brevo_log', array_slice($log, 0, 300), false);
}

/**
 * Envia um e-mail pela Brevo. Retorna true ou WP_Error.
 */
function zoe_brevo_enviar($atts, $chave)
{
    $to = zoe_brevo_enderecos($atts['to']);
    if (!$to) {
        return new WP_Error('zoe_brevo', 'Sem destinatário válido');
    }
    $headers = $atts['headers'];
    if (!is_array($headers)) {
        $headers = preg_split('/\r\n|\r|\n/', (string) $headers);
    }
    $ct = '';
    $cc = array();
    $bcc = array();
    $reply = array();
    $from_nome = '';
    $extra = array();
    foreach ($headers as $h) {
        if (strpos((string) $h, ':') === false) {
            continue;
        }
        list($k, $v) = array_map('trim', explode(':', $h, 2));
        switch (strtolower($k)) {
            case 'content-type':
                $ct = strtolower(trim(explode(';', $v)[0]));
                break;
            case 'cc':
                $cc = array_merge($cc, zoe_brevo_enderecos($v));
                break;
            case 'bcc':
                $bcc = array_merge($bcc, zoe_brevo_enderecos($v));
                break;
            case 'reply-to':
                $reply = zoe_brevo_enderecos($v);
                break;
            case 'from':
                if (preg_match('/^(.*)<[^>]+>$/', $v, $m)) {
                    $from_nome = trim(trim($m[1]), '"\' ');
                }
                break;
            default:
                if (preg_match('/^x-/i', $k)) {
                    $extra[$k] = $v;
                }
        }
    }
    if ($ct === '') {
        $ct = apply_filters('wp_mail_content_type', 'text/plain');
    }
    $o = zoe_brevo_opcoes();
    $de = is_email($o['remetente']) ? $o['remetente'] : 'contato@' . preg_replace('/^www\./', '', wp_parse_url(home_url(), PHP_URL_HOST));
    $nome = $o['nome'];
    if ($nome === '') {
        $nome = $from_nome !== '' ? $from_nome : apply_filters('wp_mail_from_name', get_bloginfo('name'));
        if ($nome === 'WordPress' || $nome === '') {
            $nome = get_bloginfo('name');
        }
    }
    $corpo = array(
        'sender'  => array('email' => $de, 'name' => wp_specialchars_decode($nome, ENT_QUOTES)),
        'to'      => $to,
        'subject' => wp_specialchars_decode((string) $atts['subject'], ENT_QUOTES),
    );
    $msg = (string) $atts['message'];
    if ($ct === 'text/html') {
        $corpo['htmlContent'] = $msg;
    } else {
        $corpo['textContent'] = $msg;
    }
    if ($cc) {
        $corpo['cc'] = $cc;
    }
    if ($bcc) {
        $corpo['bcc'] = $bcc;
    }
    if ($reply) {
        $corpo['replyTo'] = $reply[0];
    }
    if ($extra) {
        $corpo['headers'] = $extra;
    }
    $anexos = $atts['attachments'];
    if (!is_array($anexos)) {
        $anexos = array_filter(preg_split('/\r\n|\r|\n/', (string) $anexos));
    }
    foreach ($anexos as $nome_arq => $arq) {
        if (is_readable($arq)) {
            $corpo['attachment'][] = array(
                'name'    => is_string($nome_arq) ? $nome_arq : basename($arq),
                'content' => base64_encode(file_get_contents($arq)), // phpcs:ignore
            );
        }
    }
    $r = wp_remote_post('https://api.brevo.com/v3/smtp/email', array(
        'timeout' => 20,
        'headers' => array('api-key' => $chave, 'Content-Type' => 'application/json', 'Accept' => 'application/json'),
        'body'    => wp_json_encode($corpo),
    ));
    if (is_wp_error($r)) {
        zoe_brevo_log($to, $atts['subject'], false, $r->get_error_message());
        return $r;
    }
    $cod = (int) wp_remote_retrieve_response_code($r);
    $res = json_decode(wp_remote_retrieve_body($r), true);
    if ($cod >= 200 && $cod < 300) {
        zoe_brevo_log($to, $atts['subject'], true, isset($res['messageId']) ? $res['messageId'] : 'ok');
        return true;
    }
    $erro = 'Brevo ' . $cod . ': ' . (isset($res['message']) ? $res['message'] : wp_remote_retrieve_body($r));
    zoe_brevo_log($to, $atts['subject'], false, $erro);
    return new WP_Error('zoe_brevo', $erro);
}

// Todo wp_mail() passa por aqui antes do envio padrão.
add_filter('pre_wp_mail', function ($nulo, $atts) {
    if ($nulo !== null) {
        return $nulo;
    }
    $chave = zoe_brevo_chave();
    if ($chave === '') {
        return null;
    }
    $ok = zoe_brevo_enviar($atts, $chave);
    if ($ok === true) {
        do_action('wp_mail_succeeded', $atts);
        return true;
    }
    update_option('zoe_brevo_erro', array('t' => time(), 'msg' => $ok->get_error_message()), false);
    // Brevo fora do ar ou chave errada: não perde o e-mail, segue pelo envio padrão.
    return null;
}, 10, 2);

/** Cartão de configuração em Zoe Eventos → Relatórios. */
function zoe_brevo_cartao()
{
    $o = zoe_brevo_opcoes();
    $url = admin_url('admin-post.php');
    $erro = get_option('zoe_brevo_erro');
    echo '<form method="post" action="' . esc_url($url) . '">';
    wp_nonce_field('zoe_brevo_salvar');
    echo '<input type="hidden" name="action" value="zoe_brevo_salvar">';
    echo '<div class="zoe-card"><h2>Envio pela Brevo (recomendado)</h2>';
    echo '<p class="description">Com a chave da API da Brevo, todos os e-mails do site (compras, ingressos, avisos) saem pela Brevo e chegam também no Hotmail/Outlook. Na Brevo: <i>SMTP e API → Chaves API e MCP → Gerar uma nova chave API</i>. Se a Brevo falhar, o site usa o envio padrão.</p>';
    echo '<p><b>Situação:</b> ' . ($o['chave'] && $o['ativo'] ? '<span style="color:#0a7a3d">ativo — e-mails saindo pela Brevo</span>' : 'desligado — e-mails saindo pelo servidor da hospedagem') . '</p>';
    if (is_array($erro) && !empty($erro['t']) && $erro['t'] > time() - 3 * DAY_IN_SECONDS) {
        echo '<p style="color:#b32d2e">Última falha da Brevo (' . esc_html(wp_date('d/m H:i', $erro['t'])) . '): ' . esc_html($erro['msg']) . '</p>';
    }
    echo '<table class="form-table">';
    echo '<tr><th>Chave da API</th><td><input type="password" name="chave" value="" class="regular-text" autocomplete="new-password" placeholder="' . ($o['chave'] ? '•••••••• (guardada; deixe vazio para manter)' : 'xkeysib-...') . '"></td></tr>';
    echo '<tr><th>E-mail do remetente</th><td><input type="email" name="remetente" value="' . esc_attr($o['remetente']) . '" placeholder="contato@zoechurchfrg.com.br" class="regular-text"></td></tr>';
    echo '<tr><th>Nome do remetente</th><td><input type="text" name="nome" value="' . esc_attr($o['nome']) . '" placeholder="(o do e-mail, ex.: Zoe Church)" class="regular-text"></td></tr>';
    echo '</table><p>';
    echo '<button class="button button-primary" name="teste" value="1">Salvar e mandar e-mail de teste para mim</button> ';
    submit_button('Salvar', 'secondary', 'submit', false);
    if ($o['chave']) {
        echo ' <button class="button-link-delete" name="desligar" value="1" style="margin-left:10px">' . ($o['ativo'] ? 'Desligar Brevo' : 'Religar Brevo') . '</button>';
    }
    echo '</p>';
    $log = get_option('zoe_brevo_log', array());
    if (is_array($log) && $log) {
        echo '<details><summary>Últimos envios pela Brevo</summary><table class="widefat striped" style="margin-top:8px"><thead><tr><th>Quando</th><th>Para</th><th>Assunto</th><th>Resultado</th></tr></thead><tbody>';
        foreach (array_slice($log, 0, 30) as $l) {
            echo '<tr><td>' . esc_html(wp_date('d/m H:i', $l['t'])) . '</td><td>' . esc_html($l['para']) . '</td><td>' . esc_html($l['assunto']) . '</td><td>' . ($l['ok'] ? '✓ aceito' : '✗ ' . esc_html($l['info'])) . '</td></tr>';
        }
        echo '</tbody></table></details>';
    }
    echo '</div></form>';
}

add_action('admin_post_zoe_brevo_salvar', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('zoe_brevo_salvar')) {
        wp_die('Só o administrador do site pode mudar o envio de e-mails.');
    }
    $volta = admin_url('admin.php?page=zoe-relatorios');
    $o = zoe_brevo_opcoes();
    if (!empty($_POST['desligar'])) {
        $o['ativo'] = $o['ativo'] ? 0 : 1;
        update_option('zoe_brevo', $o, false);
        wp_safe_redirect($volta . '&zoe_rel=salvo');
        exit;
    }
    $chave = isset($_POST['chave']) ? trim((string) wp_unslash($_POST['chave'])) : ''; // phpcs:ignore
    if ($chave !== '' && function_exists('zoe_smtp_cifrar')) {
        $o['chave'] = zoe_smtp_cifrar($chave);
        $o['ativo'] = 1;
    }
    $o['remetente'] = sanitize_email(wp_unslash(isset($_POST['remetente']) ? $_POST['remetente'] : ''));
    $o['nome'] = sanitize_text_field(wp_unslash(isset($_POST['nome']) ? $_POST['nome'] : ''));
    update_option('zoe_brevo', $o, false);
    delete_option('zoe_brevo_erro');
    if (!empty($_POST['teste'])) {
        $eu = wp_get_current_user();
        $k = zoe_brevo_chave();
        $r = $k ? zoe_brevo_enviar(array(
            'to' => $eu->user_email,
            'subject' => 'Teste de envio pela Brevo — ' . get_bloginfo('name'),
            'message' => 'Se você recebeu este e-mail, o site já está enviando pela Brevo.',
            'headers' => '',
            'attachments' => array(),
        ), $k) : new WP_Error('sem', 'Informe a chave da API.');
        set_transient('zoe_smtp_teste_' . $eu->ID, $r === true ? 'ok' : $r->get_error_message(), 120);
        wp_safe_redirect($volta . '&zoe_rel=' . ($r === true ? 'testeok' : 'testefalhou'));
        exit;
    }
    wp_safe_redirect($volta . '&zoe_rel=salvo');
    exit;
});
