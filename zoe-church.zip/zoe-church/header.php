<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php $logo = zoe_img(zoe_opt('logo'), 'thumbnail'); ?>
<header class="topo <?php echo is_front_page() ? 'transp' : ''; ?>"><div class="wrap">
    <a class="logo" href="<?php echo esc_url(home_url('/')); ?>"><?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="" width="38" height="38"><?php endif; ?><span><?php bloginfo('name'); ?></span></a>
    <div class="dir">
        <?php if (class_exists('WooCommerce')) : ?>
        <button class="pill so" data-abrir="carrinho" aria-label="Carrinho"><?php echo zoe_ic('sacola'); // phpcs:ignore ?><?php echo zoe_qtd_carrinho(); // phpcs:ignore ?></button>
        <?php endif; ?>
        <button class="pill" data-abrir="menu" aria-label="Abrir menu"><span class="hamb-l"><i></i><i></i></span><span>Menu</span></button>
    </div>
</div></header>

<div class="menu-full" id="menuFull" aria-hidden="true">
    <div class="wrap cab"><a class="logo" href="<?php echo esc_url(home_url('/')); ?>" style="color:#fff"><?php if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="" width="38" height="38"><?php endif; ?><span><?php bloginfo('name'); ?></span></a><button class="x-btn" data-fechar="menu" aria-label="Fechar"><?php echo zoe_ic('fechar'); // phpcs:ignore ?></button></div>
    <div class="wrap" style="flex:1;display:flex"><nav>
        <?php
        $home = home_url('/');
        $itens = array();
        $locs = get_nav_menu_locations();
        if (!empty($locs['principal']) && ($m = wp_get_nav_menu_items($locs['principal']))) {
            foreach ($m as $it) {
                if (!$it->menu_item_parent) {
                    $itens[] = array($it->title, $it->url);
                }
            }
        } else {
            $itens = array(array('Início', $home), array('Nossa *visão*', $home . '#visao'), array('Eventos', zoe_url_eventos()), array('*Células*', $home . '#celulas'), array('Ministérios', $home . '#ministerios'), array('Contribua', $home . '#contribua'), array('Contato', $home . '#contato'));
        }
        foreach ($itens as $i => $it) {
            printf('<a href="%s"><small>%02d</small>%s</a>', esc_url($it[1]), $i + 1, zoe_serif($it[0])); // phpcs:ignore
        }
        printf('<a href="%s" class="m-adm"><small>%02d</small>' . zoe_ic('cadeado') . ' Administração</a>', esc_url(zoe_link_admin()), count($itens) + 1);
        ?>
    </nav></div>
    <div class="wrap"><div class="rod"><span><?php echo esc_html(zoe_opt('endereco')); ?></span><span><?php echo esc_html(implode(' · ', array_map(function ($l) { return explode('|', $l)[0]; }, zoe_linhas(zoe_opt('cultos'))))); ?></span></div></div>
</div>
<main id="conteudo">
