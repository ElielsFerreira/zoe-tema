<?php
/* Loja / categorias do WooCommerce: mostra a lista de eventos no estilo do tema. */
get_header(); ?>
<section class="sec" style="padding-top:clamp(40px,7vw,90px)"><div class="wrap">
    <span class="eyebrow">Agenda</span>
    <h1 class="titulo" style="margin-bottom:clamp(28px,5vw,60px)"><?php echo is_shop() ? 'Eventos <span class="serif">&amp; cursos</span>' : esc_html(woocommerce_page_title(false)); ?></h1>
    <?php if (is_shop()) {
        $lista = zoe_eventos(false);
        echo '<div class="lista-ev">';
        foreach ($lista as $e) { echo zoe_linha_evento($e); } // phpcs:ignore
        echo '</div>';
    } else {
        echo '<div class="lista-ev">';
        while (have_posts()) { the_post(); $p = wc_get_product(get_the_ID()); if ($p) { echo zoe_linha_evento(array('p' => $p, 'aberto' => $p->is_purchasable() && $p->is_in_stock(), 'data' => (string) get_post_meta($p->get_id(), '_zoe_data', true))); } } // phpcs:ignore
        echo '</div>';
    } ?>
</div></section>
<?php get_footer();
