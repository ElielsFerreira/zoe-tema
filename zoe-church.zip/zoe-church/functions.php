<?php
/**
 * Tema Zoe Church — leve, sem construtor de páginas.
 */
if (!defined('ABSPATH')) {
    exit;
}
define('ZOE_TEMA_V', '1.2.15');

require_once get_template_directory() . '/inc/opcoes.php';
require_once get_template_directory() . '/inc/eventos.php';   // Zoe Eventos embutido (dispensa instalar o plugin)
require_once get_template_directory() . '/inc/ativacao.php';
require_once get_template_directory() . '/inc/painel.php';    // administração no estilo do protótipo (/painel/)
require_once get_template_directory() . '/inc/regras.php';    // endereços antigos e regras da igreja (antes em plugins)
require_once get_template_directory() . '/inc/lembretes.php'; // lembrete de pagamento e lista "Aguardando pagamento"
require_once get_template_directory() . '/inc/emails.php';
require_once get_template_directory() . '/inc/atualizacoes.php'; // atualização automática via GitHub    // e-mail de confirmação da inscrição com o visual da Zoe

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    add_theme_support('woocommerce', array('single_image_width' => 900, 'thumbnail_image_width' => 400));
    add_theme_support('responsive-embeds');
    register_nav_menus(array('principal' => 'Menu principal (tela cheia)'));
});

/* ---------- CSS / JS ---------- */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('zoe-fontes', 'https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap', array(), null);
    wp_enqueue_style('zoe-tema', get_stylesheet_uri(), array(), ZOE_TEMA_V);
    wp_enqueue_script('zoe-tema', get_template_directory_uri() . '/assets/zoe.js', array(), ZOE_TEMA_V, array('in_footer' => true, 'strategy' => 'defer'));
    if (class_exists('WooCommerce')) {
        wp_enqueue_script('wc-cart-fragments'); // contador e carrinho lateral sempre atualizados (mesmo com cache)
        wp_add_inline_script('zoe-tema', 'window.zoeLoja=' . wp_json_encode(array(
            'checkout'  => wc_get_checkout_url(),
            'fragments' => WC_AJAX::get_endpoint('get_refreshed_fragments'),
        )) . ';', 'before');
    }
    // estilos que o tema não usa
    wp_dequeue_style('classic-theme-styles');
    if (!is_singular() || is_front_page()) {
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('global-styles');
    }
    if (!(function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout() || is_account_page()))) {
        wp_dequeue_style('wc-blocks-style');
    }
}, 20);
add_filter('woocommerce_enqueue_styles', '__return_empty_array'); // o tema tem o próprio estilo da loja

add_action('wp_head', function () {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<meta name="theme-color" content="#141216">' . "\n";
}, 1);

/* ---------- limpeza / desempenho ---------- */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

add_filter('body_class', function ($c) {
    if (is_front_page()) {
        $c[] = 'sobre-hero';
    }
    return $c;
});

/* Garante os templates do tema na home, na página de eventos e na loja,
   mesmo com Elementor (modelo "Canvas"), ShopEngine ou Xpro instalados.
   As outras páginas feitas no Elementor continuam como estão. */
add_filter('template_include', function ($t) {
    $dir = get_template_directory();
    if (is_front_page() && !is_home()) {
        return $dir . '/front-page.php';
    }
    if (is_page('eventos')) {
        return $dir . '/page-eventos.php';
    }
    if (!function_exists('is_checkout')) {
        return $t;
    }
    if (is_product()) {
        return $dir . '/woocommerce/single-product.php';
    }
    if (is_cart() || is_checkout() || is_account_page()) {
        return $dir . '/index.php';
    }
    return $t;
}, PHP_INT_MAX - 1);

/* Cabeçalho e rodapé do próprio tema: tira os que plugins de "header/footer"
   (Elementor Header & Footer, Xpro, ShopEngine) tentam pôr por cima. */
function zoe_tirar_hooks_de_plugins($hook)
{
    global $wp_filter;
    if (empty($wp_filter[$hook])) {
        return;
    }
    foreach ($wp_filter[$hook]->callbacks as $prio => $cbs) {
        foreach ($cbs as $cb) {
            $f    = $cb['function'];
            $nome = '';
            if (is_array($f)) {
                $nome = is_object($f[0]) ? get_class($f[0]) : (string) $f[0];
            } elseif (is_string($f)) {
                $nome = $f;
            } elseif ($f instanceof Closure) {
                $r    = new ReflectionFunction($f);
                $nome = (string) $r->getFileName();
            }
            if ($nome && preg_match('~(^|\\\\|/)(HFE|Header_Footer_Elementor|header-footer-elementor|hfe_|Xpro|xpro-theme-builder|ShopEngine|shopengine)~i', $nome)) {
                remove_action($hook, $f, $prio);
            }
        }
    }
}
add_action('template_redirect', function () {
    if (is_admin()) {
        return;
    }
    foreach (array('get_header', 'get_footer', 'wp_body_open', 'wp_footer') as $h) {
        zoe_tirar_hooks_de_plugins($h);
    }
}, PHP_INT_MAX);

/* Na hora exata em que o tema chama o cabeçalho/rodapé, nenhum plugin pode trocá-los
   (alguns, como o Xpro, só se registram depois do template_redirect). O tema não usa
   esses ganchos, então tudo o que estiver neles vem de plugins de header/footer. */
function zoe_so_cabecalho_do_tema()
{
    $h = current_filter();
    global $wp_filter;
    if (is_admin() || empty($wp_filter[$h])) {
        return;
    }
    foreach ($wp_filter[$h]->callbacks as $prio => $cbs) {
        foreach ($cbs as $cb) {
            if ($cb['function'] !== 'zoe_so_cabecalho_do_tema') {
                remove_action($h, $cb['function'], $prio);
            }
        }
    }
}
add_action('get_header', 'zoe_so_cabecalho_do_tema', -PHP_INT_MAX);
add_action('get_footer', 'zoe_so_cabecalho_do_tema', -PHP_INT_MAX);
add_action('wp_body_open', function () {
    zoe_tirar_hooks_de_plugins('wp_body_open');
}, -PHP_INT_MAX);
add_action('wp_footer', function () {
    zoe_tirar_hooks_de_plugins('wp_footer');
}, -PHP_INT_MAX);

/* Cria a página "Eventos" ao ativar o tema */
add_action('after_switch_theme', function () {
    if (!get_page_by_path('eventos')) {
        wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Eventos', 'post_name' => 'eventos'));
    }
});

/* ---------- utilidades ---------- */
/** Ícones do tema (traço fino, mesma família em todo o site). */
function zoe_ic($nome)
{
    static $i = array(
        'painel' => '<rect x="3.5" y="3.5" width="7" height="9" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="5" rx="1.5"/><rect x="13.5" y="11.5" width="7" height="9" rx="1.5"/><rect x="3.5" y="15.5" width="7" height="5" rx="1.5"/>',
        'calendario' => '<rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
        'mais' => '<path d="M12 5v14M5 12h14"/>',
        'pessoas' => '<circle cx="9" cy="8.5" r="3.2"/><path d="M3.5 19.5c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><path d="M15.5 5.6a3 3 0 0 1 0 5.8M17.5 14.8c1.7.6 2.7 2.2 3 4.7"/>',
        'imagem' => '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m4 18 5-5 4 4 2.5-2.5L20 19"/>',
        'planilha' => '<path d="M6 3.5h8.5L19 8v12.5H6z"/><path d="M14.5 3.5V8H19"/><path d="M9.5 17v-3M12.5 17v-5M15.5 17v-2"/>',
        'texto' => '<path d="M5 7V5h14v2M12 5v14M9.5 19h5"/>',
        'casa' => '<path d="M4 10.5 12 4l8 6.5"/><path d="M6 9v11h12V9"/><path d="M10 20v-5.5h4V20"/>',
        'externo' => '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5.5H4.5V6H10"/>',
        'sair' => '<path d="M14 4.5H6.5v15H14"/><path d="M10.5 12H20M16.5 8.5 20 12l-3.5 3.5"/>',
        'sacola' => '<path d="M5 8h14l-1.2 12.5H6.2z"/><path d="M9 10V7a3 3 0 0 1 6 0v3"/>',
        'cadeado' => '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
        'lapis' => '<path d="M4.5 19.5 5.5 15 15.8 4.7a2 2 0 0 1 2.8 0l.7.7a2 2 0 0 1 0 2.8L9 18.5z"/><path d="m13.5 7 3.5 3.5"/>',
        'baixar' => '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19.5h14"/>',
        'envelope' => '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="m4 7 8 6 8-6"/>',
        'camera' => '<path d="M4 8.5h3.5L9 6h6l1.5 2.5H20v11H4z"/><circle cx="12" cy="13.5" r="3.3"/>',
        'olho' => '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
        'fechar' => '<path d="M6 6l12 12M18 6 6 18"/>',
        'menu' => '<path d="M4 8h16M4 16h16"/>',
        'check' => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
        'lista' => '<path d="M9 6.5h11M9 12h11M9 17.5h11M4.5 6.5h.5M4.5 12h.5M4.5 17.5h.5"/>'
    );
    return isset($i[$nome]) ? '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' . $i[$nome] . '</svg>' : '';
}

function zoe_img($v, $size = 'large')
{
    if (is_numeric($v) && (int) $v > 0) {
        $u = wp_get_attachment_image_url((int) $v, $size);
        return $u ? $u : '';
    }
    return $v ? esc_url($v) : '';
}

/** Texto com *palavra* em itálico serifado (ex.: "Nossa mensagem é *Jesus*"). */
function zoe_serif($txt)
{
    return preg_replace('/\*(.+?)\*/u', '<span class="serif">$1</span>', esc_html($txt));
}

function zoe_url_eventos()
{
    $p = get_page_by_path('eventos');
    return $p ? get_permalink($p) : (function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/'));
}

function zoe_link_admin()
{
    return function_exists('zoe_url_painel') ? zoe_url_painel() : admin_url();
}

/** Produtos publicados como eventos. $abertos = só os que aceitam inscrição. */
function zoe_eventos($abertos = false, $limite = -1, $so_eventos = false)
{
    if (!function_exists('wc_get_products')) {
        return array();
    }
    $prods = wc_get_products(array('status' => 'publish', 'limit' => 100, 'visibility' => 'visible', 'orderby' => 'date', 'order' => 'DESC'));
    $lista = array();
    foreach ($prods as $p) {
        $aberto = $p->is_purchasable() && $p->is_in_stock();
        if ($abertos && !$aberto) {
            continue;
        }
        if ($so_eventos && !get_post_meta($p->get_id(), '_zoe_evento', true)) {
            continue;
        }
        $lista[] = array('p' => $p, 'aberto' => $aberto, 'destaque' => $p->is_featured(), 'data' => (string) get_post_meta($p->get_id(), '_zoe_data', true));
    }
    usort($lista, function ($a, $b) {
        if ($a['aberto'] !== $b['aberto']) {
            return $a['aberto'] ? -1 : 1;
        }
        // "Produto em destaque" (estrela no WooCommerce) vem primeiro
        if ($a['destaque'] !== $b['destaque']) {
            return $a['destaque'] ? -1 : 1;
        }
        // Entre os destaques: "Ordem do menu" do produto (Avançado), depois data, depois nome
        if ($a['destaque']) {
            $oa = (int) get_post_field('menu_order', $a['p']->get_id());
            $ob = (int) get_post_field('menu_order', $b['p']->get_id());
            if ($oa !== $ob) {
                return $oa < $ob ? -1 : 1;
            }
            if ($a['data'] !== $b['data']) {
                return strcmp($a['data'] ? $a['data'] : '9999', $b['data'] ? $b['data'] : '9999');
            }
            return strcasecmp($a['p']->get_name(), $b['p']->get_name());
        }
        $da = $a['data'] ? $a['data'] : '9999';
        $db = $b['data'] ? $b['data'] : '9999';
        return strcmp($da, $db);
    });
    return $limite > 0 ? array_slice($lista, 0, $limite) : $lista;
}

function zoe_data_br($ymd)
{
    $t = $ymd ? strtotime($ymd) : 0;
    return $t ? date_i18n('d/m/Y', $t) : '';
}

function zoe_linha_evento($item)
{
    $p      = $item['p'];
    $aberto = $item['aberto'];
    $d      = $item['data'] ? strtotime($item['data']) : 0;
    $meses  = array('JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ');
    $img    = wp_get_attachment_image_url($p->get_image_id(), 'medium_large');
    $img    = $img ? $img : wc_placeholder_img_src('medium');
    $resumo = wp_strip_all_tags($p->get_short_description());
    $preco  = wp_strip_all_tags(wc_price($p->get_price()));
    ob_start(); ?>
    <a class="ev-linha rv <?php echo $aberto ? '' : 'fechado'; ?>" href="<?php echo esc_url($p->get_permalink()); ?>" data-img="<?php echo esc_url($img); ?>">
        <div class="ev-data"><?php if ($d) : ?><b><?php echo esc_html(date_i18n('d', $d)); ?></b><span><?php echo esc_html($meses[(int) date('n', $d) - 1] . ' ' . date('Y', $d)); ?></span><?php else : ?><b>—</b><?php endif; ?></div>
        <div class="ev-thumb"><img src="<?php echo esc_url($img); ?>" alt=""<?php echo zoe_pos_attr(get_post_meta($p->get_id(), '_zoe_img_pos', true)); // phpcs:ignore ?> loading="lazy"></div>
        <div class="ev-nome"><h3><?php echo esc_html($p->get_name()); ?></h3>
            <p><?php if ($d) : ?><span class="p-m"><?php echo esc_html(date_i18n('d/m/Y', $d)); ?> · </span><?php endif; ?><?php echo esc_html(wp_trim_words($resumo, 22)); ?><span class="p-m"> · <?php echo esc_html($preco); ?></span></p>
            <?php if (!$aberto) : ?><span class="ev-status">Inscrições encerradas</span><?php endif; ?></div>
        <div class="ev-preco"><?php echo esc_html($preco); ?></div><div class="ev-ir" aria-hidden="true">↗</div>
    </a>
    <?php return ob_get_clean();
}

/* ---------- carrinho lateral ---------- */
function zoe_qtd_carrinho()
{
    $n = (function_exists('WC') && WC()->cart) ? WC()->cart->get_cart_contents_count() : 0;
    return '<span class="badge zoe-qtd' . ($n ? ' tem' : '') . '">' . (int) $n . '</span>';
}
/** Botão flutuante "sacola · N · total" (aparece quando há itens, como no protótipo). */
function zoe_botao_flutuante()
{
    $n = (function_exists('WC') && WC()->cart) ? WC()->cart->get_cart_contents_count() : 0;
    if (!$n) {
        return '<button class="btn flutuante zoe-flut" data-abrir="carrinho" hidden></button>';
    }
    return '<button class="btn flutuante zoe-flut" data-abrir="carrinho">' . zoe_ic('sacola') . ' ' . (int) $n . ' · ' . wp_strip_all_tags(WC()->cart->get_cart_total()) . '</button>';
}
add_filter('woocommerce_add_to_cart_fragments', function ($f) {
    $f['span.zoe-qtd'] = zoe_qtd_carrinho();
    $f['button.zoe-flut'] = zoe_botao_flutuante();
    ob_start();
    echo '<div class="widget_shopping_cart_content">';
    woocommerce_mini_cart();
    echo '</div>';
    $f['div.widget_shopping_cart_content'] = ob_get_clean();
    return $f;
});

/* Botão "Inscrever-se" em vez de "Comprar" */
add_filter('woocommerce_product_single_add_to_cart_text', function () {
    return 'Inscrever-se →';
});
add_filter('woocommerce_order_button_text', function () {
    return 'Confirmar inscrição';
});

/* ---------- remover / esvaziar carrinho ---------- */
// "Esvaziar carrinho" no carrinho lateral
/* Carrinho lateral como no protótipo: "Finalizar inscrição" + "Continuar navegando" */
add_action('init', function () {
    remove_action('woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_button_view_cart', 10);
    remove_action('woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_proceed_to_checkout', 20);
});
add_action('woocommerce_widget_shopping_cart_buttons', function () {
    echo '<a href="' . esc_url(wc_get_checkout_url()) . '" class="button checkout wc-forward">Finalizar inscrição <span class="seta">→</span></a>';
}, 20);
add_action('woocommerce_widget_shopping_cart_after_buttons', function () {
    echo '<button type="button" class="button zoe-continuar" data-fechar="carrinho">Continuar navegando</button>';
    if (WC()->cart && !WC()->cart->is_empty()) {
        echo '<a class="zoe-esvaziar" href="' . esc_url(wp_nonce_url(add_query_arg('zoe_esvaziar', '1', home_url('/')), 'zoe_esvaziar')) . '">Esvaziar carrinho</a>';
    }
});
add_action('wp_loaded', function () {
    if (isset($_GET['zoe_esvaziar']) && function_exists('WC') && WC()->cart && wp_verify_nonce(isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '', 'zoe_esvaziar')) { // phpcs:ignore
        WC()->cart->empty_cart();
        wc_add_notice('Carrinho esvaziado.', 'success');
        wp_safe_redirect(wp_get_referer() ? remove_query_arg(array('zoe_esvaziar', '_wpnonce'), wp_get_referer()) : home_url('/'));
        exit;
    }
}, 20);
// "Remover" em cada item do resumo da finalização
add_filter('woocommerce_cart_item_name', function ($nome, $item, $chave) {
    if (function_exists('is_checkout') && is_checkout() && !is_wc_endpoint_url()) {
        $nome .= ' <a class="zoe-remover" href="' . esc_url(wc_get_cart_remove_url($chave)) . '">Remover</a>';
    }
    return $nome;
}, 10, 3);
// carrinho vazio na finalização: volta para os eventos
add_action('template_redirect', function () {
    if (function_exists('is_checkout') && is_checkout() && !is_wc_endpoint_url() && WC()->cart && WC()->cart->is_empty()) {
        wp_safe_redirect(zoe_url_eventos());
        exit;
    }
}, 5);
// Como no protótipo, não existe "página do carrinho": o carrinho é a gaveta lateral.
// Quem cair em /carrinho/ vai direto para a finalização (ou para os eventos, se estiver vazio).
add_action('template_redirect', function () {
    if (!function_exists('is_cart') || !is_cart() || isset($_GET['ver_carrinho'])) { // phpcs:ignore
        return;
    }
    wp_safe_redirect(WC()->cart && !WC()->cart->is_empty() ? wc_get_checkout_url() : zoe_url_eventos());
    exit;
}, 6);
// Sem o aviso "foi adicionado ao seu carrinho": o carrinho lateral já mostra
add_filter('wc_add_to_cart_message_html', '__return_empty_string', 99);
