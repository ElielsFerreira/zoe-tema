</main>
<footer><div class="wrap">
    <div class="foot-cols">
        <div><h4>Visite</h4><p><?php echo esc_html(zoe_opt('endereco')); ?></p></div>
        <div><h4>Cultos</h4><p><?php foreach (zoe_linhas(zoe_opt('cultos')) as $l) { $c = explode('|', $l); echo esc_html(trim($c[0]) . (isset($c[1]) ? ' — ' . trim($c[1]) : '')) . '<br>'; } ?></p></div>
        <div><h4>Contato</h4><p>
            <?php if (zoe_opt('email')) : ?><a href="mailto:<?php echo esc_attr(zoe_opt('email')); ?>"><?php echo esc_html(zoe_opt('email')); ?></a><br><?php endif; ?>
            <?php if (zoe_opt('whatsapp')) : ?><a href="<?php echo esc_url(zoe_link_whats(zoe_opt('whatsapp'))); ?>" target="_blank" rel="noopener">WhatsApp</a><br><?php endif; ?>
            <?php if (zoe_opt('instagram')) : ?><a href="<?php echo esc_url(zoe_opt('instagram')); ?>" target="_blank" rel="noopener">Instagram</a><br><?php endif; ?>
            <?php if (zoe_opt('facebook')) : ?><a href="<?php echo esc_url(zoe_opt('facebook')); ?>" target="_blank" rel="noopener">Facebook</a><br><?php endif; ?>
            <?php if (zoe_opt('youtube')) : ?><a href="<?php echo esc_url(zoe_opt('youtube')); ?>" target="_blank" rel="noopener">YouTube</a><?php endif; ?>
        </p></div>
        <div><h4>Site</h4><p><a href="<?php echo esc_url(zoe_url_eventos()); ?>">Eventos</a><br><?php if (function_exists('wc_get_page_permalink')) : ?><a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>">Minhas inscrições</a><br><?php endif; ?><a href="<?php echo esc_url(zoe_link_admin()); ?>">Administração</a></p></div>
    </div>
    <p class="marca-gigante"><?php echo esc_html(mb_strtoupper(get_bloginfo('name'))); ?></p>
    <div class="foot-base"><span>© <?php echo esc_html(date('Y')); ?> <?php echo esc_html(zoe_opt('razao')); ?></span><span><?php echo esc_html(zoe_opt('cnpj') ? 'CNPJ ' . zoe_opt('cnpj') : ''); ?></span></div>
</div></footer>

<?php if (class_exists('WooCommerce') && !is_checkout()) : ?>
<div class="veu" id="veu" data-fechar="carrinho"></div>
<aside class="gaveta" id="gaveta" aria-hidden="true">
    <div class="cab"><b>Carrinho</b><button class="x-btn" data-fechar="carrinho" aria-label="Fechar"><?php echo zoe_ic('fechar'); // phpcs:ignore ?></button></div>
    <div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
</aside>
<?php endif; ?>
<?php if (class_exists('WooCommerce') && !is_checkout() && !is_cart()) { echo zoe_botao_flutuante(); } // phpcs:ignore ?>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<div class="prev-flut" id="prevFlut" aria-hidden="true"><img alt=""></div>
<?php wp_footer(); ?>
</body>
</html>
