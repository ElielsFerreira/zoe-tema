<?php
/* Página "Eventos" (slug eventos): lista todos os eventos/produtos. */
get_header(); ?>
<section class="sec" style="padding-top:clamp(40px,7vw,90px)"><div class="wrap">
    <span class="eyebrow">Agenda</span>
    <h1 class="titulo" style="margin-bottom:clamp(28px,5vw,60px)">Eventos <span class="serif">&amp; cursos</span></h1>
    <?php $lista = zoe_eventos(false); if ($lista) : ?>
        <div class="lista-ev"><?php foreach ($lista as $e) { echo zoe_linha_evento($e); } // phpcs:ignore ?></div>
    <?php else : ?><p class="vazio">Nenhum evento publicado.</p><?php endif; ?>
    <?php while (have_posts()) { the_post(); if (trim(get_the_content())) { echo '<div class="entry" style="margin-top:40px">'; the_content(); echo '</div>'; } } ?>
</div></section>
<?php get_footer();
