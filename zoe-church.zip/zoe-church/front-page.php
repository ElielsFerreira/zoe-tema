<?php
get_header();
$hero = array();
foreach ((array) zoe_opt('hero') as $hi => $hv) {
    $hu = zoe_img($hv, 'full');
    if ($hu) {
        $hero[] = array($hu, zoe_pos('hero-' . $hi));
    }
}
$titulo  = zoe_opt('titulo');
$palavras = preg_split('/\s+/u', trim($titulo));
// quebra o título em até 3 linhas para a animação
$n = count($palavras);
if ($n <= 3) {
    $linhas = $palavras;
} else { // 3 linhas: as primeiras com uma palavra a mais quando sobra (ex.: Nossa / mensagem / é Jesus)
    $por = (int) floor($n / 3);
    $resto = $n - 3 * $por;
    $a = $por;
    $b = $por;
    $linhas = array(implode(' ', array_slice($palavras, 0, $a)), implode(' ', array_slice($palavras, $a, $b)), implode(' ', array_slice($palavras, $a + $b)));
}
$linhas = array_values(array_filter($linhas, 'strlen'));
$cultos = zoe_linhas(zoe_opt('cultos'));
$eventos = zoe_eventos(true, 5, true);
if (!$eventos) {
    $eventos = zoe_eventos(true, 5); // sem eventos do painel ainda: mostra os produtos abertos
}
?>
<section class="hero">
    <div class="bgs"><?php foreach ($hero as $i => $hh) : $u = $hh[0]; ?><img src="<?php echo esc_url($u); ?>" class="<?php echo $i ? '' : 'on'; ?>"<?php echo zoe_pos_attr($hh[1]); // phpcs:ignore ?> alt="" <?php echo $i ? 'loading="lazy"' : 'fetchpriority="high"'; ?>><?php endforeach; ?></div>
    <p class="frase"><?php echo esc_html(zoe_opt('frase')); ?></p>
    <div class="conteudo"><div class="wrap">
        <span class="eyebrow" style="color:#d9d2e0"><?php echo esc_html(zoe_opt('subtitulo')); ?></span>
        <h1><?php foreach ($linhas as $l) : ?><span class="l"><span><?php echo zoe_serif($l); // phpcs:ignore ?></span></span><?php endforeach; ?></h1>
        <div class="rodape-hero">
            <div class="info">
                <?php if ($cultos) : ?><div><b>Domingos</b><?php echo esc_html(implode(' e ', array_map(function ($l) { return trim(explode('|', $l)[0]); }, $cultos))); ?></div><?php endif; ?>
                <div><b>Endereço</b><?php echo esc_html(explode('·', zoe_opt('endereco'))[0]); ?></div>
            </div>
            <a class="btn claro" href="<?php echo esc_url(zoe_url_eventos()); ?>">Próximos eventos <span class="seta">→</span></a>
        </div>
    </div></div>
</section>

<?php $faixa = zoe_linhas(zoe_opt('faixa')); if ($faixa) : ?>
<div class="marquee" aria-hidden="true"><div class="trilha"><?php for ($k = 0; $k < 2; $k++) { foreach ($faixa as $f) { echo '<span>' . esc_html($f) . '</span>'; } } ?></div></div>
<?php endif; ?>

<section class="sec" id="visao"><div class="wrap">
    <span class="eyebrow rv">Nossa visão</span>
    <p class="manifesto rv" style="margin-top:18px"><?php echo zoe_serif(zoe_opt('visao_titulo')); // phpcs:ignore ?></p>
    <div class="visao-txt desc rv"><?php echo zoe_paragrafos(zoe_opt('visao')); // phpcs:ignore ?></div>
    <?php $pastores = (array) zoe_opt('pastores'); if ($pastores) : ?>
    <div class="pastores"><?php foreach ($pastores as $p) : $p = wp_parse_args($p, array('nome' => '', 'cargo' => '', 'img' => '')); $pi = zoe_img($p['img'], 'large'); ?>
        <div class="pastor rv"><div class="ft"><?php if ($pi) : ?><img src="<?php echo esc_url($pi); ?>" alt="<?php echo esc_attr($p['nome']); ?>"<?php echo zoe_pos_attr(isset($p['pos']) ? $p['pos'] : ''); // phpcs:ignore ?> loading="lazy"><?php endif; ?></div><b><?php echo esc_html($p['nome']); ?></b><span><?php echo esc_html($p['cargo']); ?></span></div>
    <?php endforeach; ?></div>
    <?php endif; ?>
</div></section>

<?php if (class_exists('WooCommerce')) : ?>
<section class="sec" style="padding-top:0"><div class="wrap">
    <div class="cab-sec rv"><div><span class="eyebrow">Agenda</span><h2 class="titulo">Inscrições <span class="serif">abertas</span></h2></div><a class="link-sub" href="<?php echo esc_url(zoe_url_eventos()); ?>">Ver todos os eventos <span class="seta">→</span></a></div>
    <?php if ($eventos) : ?><div class="lista-ev"><?php foreach ($eventos as $e) { echo zoe_linha_evento($e); } // phpcs:ignore ?></div>
    <?php else : ?><p class="vazio">Nenhuma inscrição aberta no momento.</p><?php endif; ?>
</div></section>
<?php endif; ?>

<?php if (zoe_opt('ano_titulo')) : ?>
<section class="sec escuro" id="ano"><div class="wrap duas">
    <div class="rv"><span class="eyebrow">Tema do ano</span><h2 class="titulo"><?php echo zoe_serif(zoe_opt('ano_titulo')); // phpcs:ignore ?></h2>
        <?php if (zoe_opt('ano_verso')) : ?><p class="versiculo" style="margin-top:30px"><?php echo esc_html(zoe_opt('ano_verso')); ?></p><span class="versiculo-ref"><?php echo esc_html(zoe_opt('ano_ref')); ?></span><?php endif; ?>
        <div class="fluir"><?php foreach (zoe_linhas(zoe_opt('ano_itens')) as $t) { echo '<span>' . esc_html($t) . '</span>'; } ?></div>
        <?php if (zoe_opt('ano_frase')) : ?><p class="sub" style="margin:26px 0 0"><?php echo esc_html(zoe_opt('ano_frase')); ?></p><?php endif; ?>
    </div>
    <?php $ai = zoe_img(zoe_opt('ano_img'), 'large'); if ($ai) : ?><div class="ano-img rv"><img src="<?php echo esc_url($ai); ?>" alt="Tema do ano"<?php echo zoe_pos_attr(zoe_pos('ano')); // phpcs:ignore ?> loading="lazy"></div><?php endif; ?>
</div></section>
<?php endif; ?>

<?php if (zoe_opt('vida_texto')) : ?>
<section class="sec" id="vida"><div class="wrap duas">
    <div class="foto rv"><?php $vi = zoe_img(zoe_opt('vida_img'), 'large'); if ($vi) : ?><img src="<?php echo esc_url($vi); ?>" alt=""<?php echo zoe_pos_attr(zoe_pos('vida')); // phpcs:ignore ?> loading="lazy"><?php endif; ?></div>
    <div class="rv"><span class="eyebrow">Família Zoe</span><h2 class="titulo"><?php echo zoe_serif(zoe_opt('vida_titulo')); // phpcs:ignore ?></h2>
        <div class="desc" style="margin-top:22px"><?php echo zoe_paragrafos(zoe_opt('vida_texto')); // phpcs:ignore ?></div>
        <?php if (zoe_opt('vida_verso')) : ?><p class="versiculo" style="font-size:clamp(22px,2.6vw,32px);margin-top:10px"><?php echo esc_html(zoe_opt('vida_verso')); ?></p><span class="versiculo-ref"><?php echo esc_html(zoe_opt('vida_ref')); ?></span><?php endif; ?>
        <div style="margin-top:30px"><a class="btn sec" href="#celulas">Encontre uma célula <span class="seta">→</span></a></div>
    </div>
</div></section>
<?php endif; ?>

<section class="sec escuro" id="cultos"><div class="wrap">
    <div class="cab-sec rv"><div><span class="eyebrow">Todo domingo</span><h2 class="titulo">Cultos de <span class="serif">celebração</span></h2></div><p class="sub" style="max-width:360px;margin:0"><?php echo esc_html(zoe_opt('cultos_txt')); ?></p></div>
    <div class="cultos rv"><?php foreach ($cultos as $l) { $c = explode('|', $l); echo '<div class="culto"><b>' . esc_html(trim($c[0])) . '</b><span>' . esc_html(isset($c[1]) ? trim($c[1]) : '') . '</span></div>'; } ?></div>
</div></section>

<section class="sec" id="celulas"><div class="wrap duas">
    <div class="foto rv"><?php $ci = zoe_img(zoe_opt('cel_img'), 'large'); if ($ci) : ?><img src="<?php echo esc_url($ci); ?>" alt=""<?php echo zoe_pos_attr(zoe_pos('cel')); // phpcs:ignore ?> loading="lazy"><?php endif; ?></div>
    <div class="rv"><span class="eyebrow">Pequenos grupos</span><h2 class="titulo">Células</h2>
        <p class="desc" style="margin-top:22px"><?php echo esc_html(zoe_opt('cel_txt')); ?></p>
        <?php $reu = zoe_linhas(zoe_opt('reuniao')); if ($reu) : ?>
        <p class="eyebrow" style="margin:30px 0 0">O que acontece em uma reunião?</p>
        <div class="reuniao"><?php foreach ($reu as $i => $t) { printf('<div><small>%02d</small>%s</div>', $i + 1, esc_html($t)); } ?></div>
        <?php endif; ?>
        <?php $redes = array_values(array_filter((array) zoe_opt('redes'), function ($r) { return !isset($r['ativa']) || !empty($r['ativa']); })); if ($redes) : ?>
        <p class="eyebrow" style="margin:34px 0 0">Redes de células · toque para ver</p>
        <div class="redes">
            <?php foreach ($redes as $r) :
                $r = wp_parse_args($r, array('nome' => '', 'lider' => '', 'dia' => '', 'bairro' => '', 'contatos' => '', 'desc' => '')); ?>
            <div class="rede">
                <button class="rede-cab" aria-expanded="false"><span><b><?php echo esc_html($r['nome']); ?></b><small><?php echo esc_html(implode(' · ', array_filter(array($r['dia'], $r['bairro'])))); ?></small></span><i class="mais"></i></button>
                <div class="rede-corpo"><div class="rede-in">
                    <div class="rede-info"><div><span>Liderança</span><b><?php echo esc_html($r['lider'] ? $r['lider'] : $r['nome']); ?></b></div><div><span>Quando</span><b><?php echo esc_html($r['dia'] ? $r['dia'] : '—'); ?></b></div><div><span>Onde</span><b><?php echo esc_html($r['bairro'] ? $r['bairro'] : '—'); ?></b></div></div>
                    <?php if ($r['desc']) : ?><p class="desc" style="margin:0 0 16px;font-size:15px"><?php echo esc_html($r['desc']); ?></p><?php endif; ?>
                    <div class="rede-cont"><?php foreach (zoe_linhas($r['contatos']) as $c) {
                        $partes = preg_split('/\s+[—–-]\s+/u', $c, 2);
                        $nome = count($partes) > 1 ? $partes[0] : '';
                        $tel  = count($partes) > 1 ? $partes[1] : $partes[0];
                        $wa   = 'https://wa.me/55' . preg_replace('/\D/', '', $tel) . '?text=' . rawurlencode('Olá! Vi o site da Zoe Church e quero participar de uma célula.');
                        echo '<a class="btn sec peq" href="' . esc_url($wa) . '" target="_blank" rel="noopener">WhatsApp' . ($nome ? ' ' . esc_html($nome) : '') . ' · ' . esc_html($tel) . '</a>';
                    } ?></div>
                </div></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if (zoe_opt('cel_verso')) : ?><div style="margin-top:40px"><p class="versiculo" style="font-size:clamp(22px,2.6vw,32px)"><?php echo esc_html(zoe_opt('cel_verso')); ?></p><span class="versiculo-ref"><?php echo esc_html(zoe_opt('cel_ref')); ?></span></div><?php endif; ?>
    </div>
</div></section>

<?php $mins = (array) zoe_opt('ministerios'); if ($mins) : ?>
<section class="sec papel" id="ministerios"><div class="wrap">
    <div class="cab-sec rv"><div><span class="eyebrow">Para todas as idades</span><h2 class="titulo">Ministérios <span class="serif">&amp; projetos</span></h2></div><a class="link-sub" href="<?php echo esc_url(zoe_url_eventos()); ?>">Ver inscrições <span class="seta">→</span></a></div>
    <div class="lista-ev"><?php foreach ($mins as $i => $m) :
        $m = wp_parse_args($m, array('nome' => '', 'txt' => '', 'link' => ''));
        $lk = zoe_link_min($m['link']);
        $num = sprintf('%02d', $i + 1);
        $miolo = '<small>' . $num . '</small><div><h3>' . esc_html($m['nome']) . '</h3>' . ($m['txt'] ? '<p>' . esc_html($m['txt']) . '</p>' : '') . '</div>';
        echo $lk ? '<a class="min-linha rv" href="' . esc_url($lk) . '">' . $miolo . '<div class="ev-ir">↗</div></a>' : '<div class="min-linha rv">' . $miolo . '<div></div></div>'; // phpcs:ignore
    endforeach; ?></div>
</div></section>
<?php endif; ?>

<section class="sec escuro" id="contribua"><div class="wrap contrib">
    <div class="rv"><span class="eyebrow">Generosidade</span><h2 class="titulo">Contribua</h2><p class="sub" style="margin-top:20px;max-width:520px"><?php echo esc_html(zoe_opt('contrib_txt')); ?></p></div>
    <div class="cnpj rv"><span class="eyebrow">CNPJ · PIX</span><b><?php echo esc_html(zoe_opt('cnpj')); ?></b><span style="color:#b1aab8;font-size:14px"><?php echo esc_html(zoe_opt('razao')); ?></span><br>
        <button class="btn claro peq" style="margin-top:16px" data-copiar="<?php echo esc_attr(zoe_opt('pix')); ?>">Copiar chave PIX</button></div>
</div></section>
<section class="sec" id="contato"><div class="wrap contato-grid">
    <div class="rv"><span class="eyebrow">Contato</span><h2 class="titulo">Fale <span class="serif">conosco</span></h2><p class="desc" style="margin-top:22px;max-width:520px"><?php echo esc_html(zoe_opt('contato_txt')); ?></p></div>
    <div class="rv">
        <?php if (zoe_opt('email')) : ?><p style="margin:0 0 18px"><span class="eyebrow">E-mail</span><br><a href="mailto:<?php echo esc_attr(zoe_opt('email')); ?>" style="font-size:clamp(18px,2vw,24px);font-weight:600"><?php echo esc_html(zoe_opt('email')); ?></a></p><?php endif; ?>
        <div class="contato-links"><?php
        foreach (array(array('WhatsApp', zoe_link_whats(zoe_opt('whatsapp')), ''), array('Instagram', zoe_opt('instagram'), 'sec'), array('Facebook', zoe_opt('facebook'), 'sec'), array('YouTube', zoe_opt('youtube'), 'sec')) as $l) {
            if ($l[1]) {
                echo '<a class="btn ' . esc_attr($l[2]) . '" href="' . esc_url($l[1]) . '" target="_blank" rel="noopener">' . esc_html($l[0]) . ' <span class="seta">↗</span></a>';
            }
        } ?></div>
    </div>
</div></section>
<?php get_footer();
