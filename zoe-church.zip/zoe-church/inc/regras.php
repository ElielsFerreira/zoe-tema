<?php
/**
 * Regras da igreja que antes ficavam soltas em plugins (Code Snippets, Elementor):
 *  1. Endereços antigos (páginas feitas no Elementor) levam para as páginas novas.
 *  2. Zoe Judô infantil: a partir de 2 inscrições, cada uma sai por R$ 50.
 */
if (!defined('ABSPATH')) {
    exit;
}

/* ---------- 1. Endereços antigos → páginas novas ---------- */
function zoe_redirecionamentos()
{
    $padrao = array(
        // Conferência Start
        'conferencia-start'              => '/produto/inscricao-start-2025/',
        'conferencia-start-2'            => '/produto/inscricao-start-2025/',
        // eventos que têm página nova
        'reencontro-com-deus'            => '/produto/reencontro-com-deus/',
        'zoe-school'                     => '/produto/zoe-school/',
        'escola-de-discipulos-ead'       => '/produto/escola-de-discipulos-ead/',
        'cordao-de-3-dobras'             => '/produto/cordao-de-3-dobras/',
        'cordao-de-3-dobras-copy-1614'   => '/produto/cordao-de-3-dobras/',
        'zoe-music-copy-6097'            => '/produto/zoe-music-turmas-2026/',
        // páginas de eventos antigos ou com mais de um evento → lista de eventos
        'encontro-com-deus-copy'         => '/eventos/',
        'encontro-com-deus-copy-305'     => '/eventos/',
        'encontro-com-deus-teens-copy-2572' => '/eventos/',
        'ecd-h-ou-m'                     => '/eventos/',
        'originais'                      => '/eventos/',
        'homem-e-mulher-originais'       => '/eventos/',
        'rede-de-casais'                 => '/eventos/',
        'revisao'                        => '/eventos/',
        'fromatura-juventude-z'          => '/eventos/',
        // seções da página inicial
        'contribua'                      => '/#contribua',
        'localizacao'                    => '/#contato',
        'contact'                        => '/#contato',
        'about-us'                       => '/#visao',
        // páginas de modelo / testes / home antiga
        'home-nature-v1'                 => '/',
        'home-copy-695-2'                => '/',
        'projects'                       => '/',
        'services'                       => '/',
        'teste'                          => '/',
        'elementor-3060'                 => '/',
    );
    $extra = get_option('zoe_redirecionamentos', array());
    return array_merge($padrao, is_array($extra) ? $extra : array());
}

add_action('template_redirect', function () {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
        return;
    }
    // quem está editando no Elementor continua conseguindo abrir as páginas antigas
    if (isset($_GET['elementor-preview']) || isset($_GET['preview'])) { // phpcs:ignore
        return;
    }
    $caminho = trim((string) wp_parse_url(isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '', PHP_URL_PATH), '/'); // phpcs:ignore
    if ($caminho === '') {
        return;
    }
    $mapa = zoe_redirecionamentos();
    if (isset($mapa[$caminho])) {
        wp_redirect(home_url($mapa[$caminho]), 301);
        exit;
    }
}, 0);

/* ---------- 2. Zoe Judô infantil: 2 ou mais saem por R$ 50 cada ---------- */
add_action('woocommerce_before_calculate_totals', function ($cart) {
    if (is_admin() && !(defined('DOING_AJAX') && DOING_AJAX)) {
        return;
    }
    $variacao   = 6848;  // Zoe Judô — Infantil (6 a 13 anos)
    $preco_novo = 50.00;
    $minimo     = 2;
    $qtd = 0;
    foreach ($cart->get_cart() as $item) {
        if ((int) $item['variation_id'] === $variacao) {
            $qtd += (int) $item['quantity'];
        }
    }
    if ($qtd < $minimo) {
        return;
    }
    foreach ($cart->get_cart() as $item) {
        if ((int) $item['variation_id'] === $variacao) {
            $item['data']->set_price($preco_novo);
        }
    }
}, 99);
