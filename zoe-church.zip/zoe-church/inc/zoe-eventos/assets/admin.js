jQuery(function ($) {
    // Imagem do evento
    $(document).on('click', '.zoe-escolher-img', function (e) {
        e.preventDefault();
        var box = $(this).closest('.zoe-img-pick');
        var frame = wp.media({ title: 'Imagem do evento', button: { text: 'Usar esta imagem' }, library: { type: 'image' }, multiple: false });
        frame.on('select', function () {
            var a = frame.state().get('selection').first().toJSON();
            box.find('input[name=imagem]').val(a.id);
            box.find('input[name=img_pos]').val('50% 50%');
            box.find('.zoe-foco').css({ 'background-image': 'url(' + (a.sizes && a.sizes.medium_large ? a.sizes.medium_large.url : a.url) + ')', 'background-position': '50% 50%' });
            box.find('.zoe-ponto').css({ left: '50%', top: '50%' });
            var m = [];
            if (a.width && (a.width < 760 || a.height < 760)) { m.push('A imagem tem ' + a.width + ' × ' + a.height + ' px; o ideal é 1080 × 1080. Pode ficar borrada.'); }
            if (a.width && Math.abs(a.width / a.height - 1) > 0.3) { m.push('O espaço é quadrado: parte da imagem será cortada. Marque o ponto principal.'); }
            box.find('.zoe-aviso-img').text(m.join(' ')).toggle(!!m.length);
        });
        frame.open();
    });
    $(document).on('click', '.zoe-remover-img', function (e) {
        e.preventDefault();
        var box = $(this).closest('.zoe-img-pick');
        box.find('input[name=imagem]').val(0);
        box.find('.zoe-foco').css('background-image', 'none');
    });

    // Ponto de foco da imagem do evento
    var arrastando = null;
    function moverFoco(el, e) {
        var r = el.getBoundingClientRect(), x = Math.round(Math.min(100, Math.max(0, (e.clientX - r.left) / r.width * 100))), y = Math.round(Math.min(100, Math.max(0, (e.clientY - r.top) / r.height * 100))), p = x + '% ' + y + '%';
        $(el).css('background-position', p).find('.zoe-ponto').css({ left: x + '%', top: y + '%' });
        $(el).closest('.zoe-img-pick').find('input[name=img_pos]').val(p);
    }
    $(document).on('pointerdown', '.zoe-foco', function (e) { arrastando = this; this.setPointerCapture(e.originalEvent.pointerId); moverFoco(this, e.originalEvent); });
    $(document).on('pointermove', '.zoe-foco', function (e) { if (arrastando === this) { moverFoco(this, e.originalEvent); } });
    $(document).on('pointerup pointercancel', '.zoe-foco', function () { arrastando = null; });

    // Perguntas personalizadas
    var idx = $('.zoe-custom tbody tr').length + 100;
    $('.zoe-add-custom').on('click', function () {
        var html = $('#zoe-tpl-custom').html().replace(/__i__/g, idx++);
        $('.zoe-custom tbody').append(html);
    });
    $(document).on('click', '.zoe-del-custom', function () { $(this).closest('tr').remove(); });

    // Copiar formulário de outro evento
    $('.zoe-copiar').on('change', function () {
        if (!this.value) return;
        if (confirm('Carregar o formulário desse evento? Os campos marcados agora serão substituídos (nada é salvo até clicar em Salvar).')) {
            window.location = $(this).data('base') + '&copiar_de=' + this.value;
        }
    });

    // Trocar imagem de página
    $(document).on('click', '.zoe-trocar', function (e) {
        e.preventDefault();
        var form = $(this).closest('form');
        var frame = wp.media({ title: 'Escolha a nova imagem', button: { text: 'Trocar imagem' }, library: { type: 'image' }, multiple: false });
        frame.on('select', function () {
            var a = frame.state().get('selection').first().toJSON();
            form.find('input[name=nova]').val(a.id);
            form.find('img').css('opacity', .4);
            form.submit();
        });
        frame.open();
    });
});
