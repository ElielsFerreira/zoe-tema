(function () {
    // Mostra/esconde campos que dependem de outro (ex.: "Qual célula?" só quando "Sim").
    function valorDe(bloco, chave) {
        var marcado = bloco.querySelector('[data-zoe-key="' + chave + '"] input[type=radio]:checked');
        if (marcado) return marcado.value;
        var campo = bloco.querySelector('[data-zoe-key="' + chave + '"] select, [data-zoe-key="' + chave + '"] input:not([type=radio])');
        return campo ? campo.value : '';
    }
    function atualizar(bloco) {
        bloco.querySelectorAll('[data-zoe-dep]').forEach(function (p) {
            var ok = valorDe(bloco, p.getAttribute('data-zoe-dep')) === p.getAttribute('data-zoe-val');
            p.style.display = ok ? '' : 'none';
        });
    }
    // "Mesma célula e líder da pessoa 1": copia os campos da primeira vaga do mesmo evento.
    function campo(bloco, chave) {
        return bloco.querySelector('[data-zoe-key="' + chave + '"]');
    }
    function copiar(destino) {
        var cx = destino.querySelector('[data-zoe-copiar]');
        if (!cx || !cx.checked) return;
        var origem = document.querySelector('.zoe-bloco[data-item="' + destino.getAttribute('data-item') + '"][data-vaga="1"]');
        if (!origem) return;
        cx.getAttribute('data-zoe-copiar').split(',').forEach(function (k) {
            var de = campo(origem, k), para = campo(destino, k);
            if (!de || !para) return;
            var r = de.querySelector('input[type=radio]:checked');
            if (r) {
                var alvo = para.querySelector('input[type=radio][value="' + r.value + '"]');
                if (alvo) alvo.checked = true;
            } else {
                var a = de.querySelector('select, input, textarea'), b = para.querySelector('select, input, textarea');
                if (a && b) b.value = a.value;
            }
        });
        atualizar(destino);
    }
    function iniciar() {
        document.querySelectorAll('.zoe-bloco').forEach(function (bloco) {
            atualizar(bloco);
            bloco.addEventListener('change', function (e) {
                atualizar(bloco);
                if (e.target && e.target.hasAttribute('data-zoe-copiar')) copiar(bloco);
                if (bloco.getAttribute('data-vaga') === '1') {
                    document.querySelectorAll('.zoe-bloco[data-item="' + bloco.getAttribute('data-item') + '"]').forEach(copiar);
                }
            });
            bloco.addEventListener('input', function () {
                if (bloco.getAttribute('data-vaga') === '1') {
                    document.querySelectorAll('.zoe-bloco[data-item="' + bloco.getAttribute('data-item') + '"]').forEach(copiar);
                }
            });
        });
        // Aviso de inscrição já paga: mostra a caixinha "É outra inscrição".
        if (window.jQuery) {
            window.jQuery(document.body).on('checkout_error', function () {
                var err = document.querySelector('.woocommerce-error, .woocommerce-NoticeGroup-checkout');
                var box = document.querySelector('.zoe-ja-ok');
                if (box && err && /já tem inscrição/.test(err.textContent)) box.style.display = '';
            });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
    else iniciar();
})();
