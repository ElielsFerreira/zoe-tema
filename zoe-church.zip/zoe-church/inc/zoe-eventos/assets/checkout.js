(function () {
    // Mostra/esconde campos que dependem de outro (ex.: "Qual célula?" só quando "Sim").
    function valorDe(bloco, chave) {
        var marcado = bloco.querySelector('[data-zoe-key="' + chave + '"] input[type=radio]:checked');
        if (marcado) return marcado.value;
        var campo = bloco.querySelector('[data-zoe-key="' + chave + '"] select, [data-zoe-key="' + chave + '"] input:not([type=radio])');
        return campo ? campo.value : '';
    }
    function atualizar(bloco) {
        bloco.querySelectorAll('[data-zoe-dep]').forEach(function (p) {
            var ok = valorDe(bloco, p.getAttribute('data-zoe-dep')) === p.getAttribute('data-zoe-val');
            p.style.display = ok ? '' : 'none';
        });
    }
    function iniciar() {
        document.querySelectorAll('.zoe-bloco').forEach(function (bloco) {
            atualizar(bloco);
            bloco.addEventListener('change', function () { atualizar(bloco); });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
    else iniciar();
})();
