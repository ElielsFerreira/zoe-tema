<?php
/**
 * "Imagens do site": lista as imagens de qualquer página feita no Elementor e troca uma por uma,
 * guardando cópia para poder desfazer.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', function () {
    add_submenu_page('zoe-eventos', 'Imagens do site', 'Imagens do site', 'edit_pages', 'zoe-imagens', 'zoe_ev_pagina_imagens');
}, 20);

/** Páginas e modelos que têm conteúdo do Elementor. */
function zoe_ev_paginas_elementor()
{
    global $wpdb;
    $tipos = array('page' => 'Página', 'elementor-hf' => 'Cabeçalho/Rodapé', 'wpr_templates' => 'Modelo', 'elementor_library' => 'Modelo', 'xpro-themer' => 'Modelo');
    $in    = "'" . implode("','", array_map('esc_sql', array_keys($tipos))) . "'";
    $rows  = $wpdb->get_results(
        "SELECT p.ID, p.post_title, p.post_type FROM {$wpdb->posts} p
         JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_elementor_data' AND m.meta_value NOT IN ('', '[]')
         WHERE p.post_status = 'publish' AND p.post_type IN ($in)
         ORDER BY FIELD(p.post_type, $in), p.post_title"
    );
    $out = array();
    foreach ($rows as $r) {
        $out[$r->ID] = $tipos[$r->post_type] . ': ' . ($r->post_title !== '' ? $r->post_title : '(sem título)');
    }
    return $out;
}

/** Percorre o JSON do Elementor e devolve todas as imagens com o "caminho" até elas. */
function zoe_ev_achar_imagens($node, $path = array(), $widget = '', &$out = array())
{
    if (!is_array($node)) {
        return $out;
    }
    if (isset($node['widgetType'])) {
        $widget = $node['widgetType'];
    } elseif (isset($node['elType']) && $node['elType'] !== 'widget') {
        $widget = $node['elType'];
    }
    if (isset($node['url']) && is_string($node['url']) && preg_match('/\.(jpe?g|png|gif|webp|svg|avif)(\?.*)?$/i', $node['url'])) {
        $out[] = array('path' => $path, 'url' => $node['url'], 'id' => isset($node['id']) ? (int) $node['id'] : 0, 'widget' => $widget, 'campo' => end($path));
        return $out;
    }
    foreach ($node as $k => $v) {
        if (is_array($v)) {
            zoe_ev_achar_imagens($v, array_merge($path, array($k)), $widget, $out);
        }
    }
    return $out;
}

function zoe_ev_nome_widget($w, $campo)
{
    $nomes = array(
        'image' => 'Imagem', 'section' => 'Fundo de seção', 'container' => 'Fundo de bloco', 'column' => 'Fundo de coluna',
        'wpr-advanced-slider' => 'Slide do carrossel', 'wpr-logo' => 'Logo', 'image-box' => 'Caixa com imagem',
        'image-carousel' => 'Carrossel de imagens', 'image-gallery' => 'Galeria', 'shopengine-single-product-images' => 'Imagem do produto',
    );
    $n = isset($nomes[$w]) ? $nomes[$w] : ($w ? $w : 'Imagem');
    if (is_string($campo) && strpos($campo, 'background') !== false && strpos($n, 'Fundo') === false) {
        $n .= ' (fundo)';
    }
    return $n;
}

function zoe_ev_pagina_imagens()
{
    $paginas = zoe_ev_paginas_elementor();
    $sel     = isset($_GET['pagina']) ? absint($_GET['pagina']) : 0; // phpcs:ignore
    echo '<div class="wrap zoe-wrap"><h1>Imagens do site</h1>';
    zoe_ev_aviso();
    echo '<p class="description">Escolha a página, clique em <strong>Trocar</strong> na imagem e selecione a nova. O site é atualizado na hora e dá para desfazer.</p>';
    echo '<form method="get" class="zoe-escolher-pagina"><input type="hidden" name="page" value="zoe-imagens"><select name="pagina" onchange="this.form.submit()"><option value="">— Escolha a página —</option>';
    foreach ($paginas as $id => $t) {
        echo '<option value="' . (int) $id . '"' . selected($sel, $id, false) . '>' . esc_html($t) . '</option>';
    }
    echo '</select> <noscript><button class="button">Abrir</button></noscript></form>';

    if (!$sel || !isset($paginas[$sel])) {
        echo '</div>';
        return;
    }
    $data = json_decode((string) get_post_meta($sel, '_elementor_data', true), true);
    $imgs = is_array($data) ? zoe_ev_achar_imagens($data) : array();
    $bkp  = get_post_meta($sel, '_zoe_bkp_elementor', true);

    echo '<p><a class="button" target="_blank" href="' . esc_url(get_permalink($sel)) . '">Ver página</a> ';
    if (is_array($bkp) && $bkp) {
        $undo = wp_nonce_url(admin_url('admin-post.php?action=zoe_ev_desfazer_img&pagina=' . $sel), 'zoe_ev_undo_' . $sel);
        echo '<a class="button" href="' . esc_url($undo) . '" onclick="return confirm(\'Desfazer a última troca de imagem desta página?\')">↶ Desfazer última troca</a>';
    }
    echo '</p>';

    if (!$imgs) {
        echo '<p>Nenhuma imagem encontrada nesta página.</p></div>';
        return;
    }
    echo '<div class="zoe-galeria">';
    foreach ($imgs as $i => $img) {
        echo '<form class="zoe-img-card" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('zoe_ev_img_' . $sel);
        echo '<input type="hidden" name="action" value="zoe_ev_trocar_img"><input type="hidden" name="pagina" value="' . (int) $sel . '">';
        echo '<input type="hidden" name="caminho" value="' . esc_attr(wp_json_encode($img['path'])) . '"><input type="hidden" name="antiga" value="' . esc_attr($img['url']) . '">';
        echo '<input type="hidden" name="nova" value="">';
        echo '<div class="zoe-img-box"><img src="' . esc_url($img['url']) . '" loading="lazy" alt=""></div>';
        echo '<p class="zoe-img-info"><strong>' . esc_html(zoe_ev_nome_widget($img['widget'], $img['campo'])) . '</strong> #' . ($i + 1) . '<br><span>' . esc_html(wp_basename($img['url'])) . '</span></p>';
        echo '<button type="button" class="button button-primary zoe-trocar">Trocar</button>';
        echo '</form>';
    }
    echo '</div></div>';
}

add_action('admin_post_zoe_ev_trocar_img', function () {
    $pid = absint($_POST['pagina']);
    if (!current_user_can('edit_post', $pid) || !check_admin_referer('zoe_ev_img_' . $pid)) {
        wp_die('Sem permissão.');
    }
    $nova    = absint($_POST['nova']);
    $caminho = json_decode(wp_unslash($_POST['caminho']), true);
    $antiga  = esc_url_raw(wp_unslash($_POST['antiga']));
    $url     = $nova ? wp_get_attachment_url($nova) : '';
    $voltar  = admin_url('admin.php?page=zoe-imagens&pagina=' . $pid);
    $raw     = (string) get_post_meta($pid, '_elementor_data', true);
    $data    = json_decode($raw, true);

    if (!$url || !is_array($caminho) || !is_array($data)) {
        wp_safe_redirect($voltar . '&zoe_msg=erro');
        exit;
    }
    // Vai até a imagem pelo caminho e confere se ainda é a mesma (evita trocar a imagem errada).
    $ref = &$data;
    foreach ($caminho as $k) {
        if (!is_array($ref) || !array_key_exists($k, $ref)) {
            wp_safe_redirect($voltar . '&zoe_msg=erro');
            exit;
        }
        $ref = &$ref[$k];
    }
    if (!is_array($ref) || !isset($ref['url']) || $ref['url'] !== $antiga) {
        wp_safe_redirect($voltar . '&zoe_msg=erro');
        exit;
    }
    $ref['url'] = $url;
    $ref['id']  = $nova;
    if (isset($ref['alt'])) {
        $ref['alt'] = (string) get_post_meta($nova, '_wp_attachment_image_alt', true);
    }
    unset($ref);

    zoe_ev_guardar_backup($pid, $raw);
    update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($data)));
    zoe_ev_limpar_cache_pagina($pid);
    wp_safe_redirect($voltar . '&zoe_msg=imagem');
    exit;
});

add_action('admin_post_zoe_ev_desfazer_img', function () {
    $pid = absint($_GET['pagina']); // phpcs:ignore
    if (!current_user_can('edit_post', $pid) || !check_admin_referer('zoe_ev_undo_' . $pid)) {
        wp_die('Sem permissão.');
    }
    $bkp = get_post_meta($pid, '_zoe_bkp_elementor', true);
    if (is_array($bkp) && $bkp) {
        $ultimo = array_pop($bkp);
        update_post_meta($pid, '_elementor_data', wp_slash($ultimo['raw']));
        update_post_meta($pid, '_zoe_bkp_elementor', wp_slash($bkp));
        zoe_ev_limpar_cache_pagina($pid);
    }
    wp_safe_redirect(admin_url('admin.php?page=zoe-imagens&pagina=' . $pid . '&zoe_msg=desfeito'));
    exit;
});

/** Guarda as últimas 5 versões para o botão Desfazer. */
function zoe_ev_guardar_backup($pid, $raw)
{
    $bkp = get_post_meta($pid, '_zoe_bkp_elementor', true);
    $bkp = is_array($bkp) ? $bkp : array();
    $bkp[] = array('t' => time(), 'raw' => $raw);
    update_post_meta($pid, '_zoe_bkp_elementor', wp_slash(array_slice($bkp, -5))); // wp_slash: preserva as barras do JSON
}

function zoe_ev_limpar_cache_pagina($pid)
{
    delete_post_meta($pid, '_elementor_element_cache');
    delete_post_meta($pid, '_elementor_css');
    zoe_ev_limpar_cache();
    clean_post_cache($pid);
}
