<?php
/**
 * Biblioteca de campos prontos e funções de formulário.
 * Cada evento só escolhe quais campos quer — sem regras condicionais por produto.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Campos prontos. "grupo" junta campos que aparecem juntos quando o item é marcado.
 * "dep" => [campo, valor] faz o campo aparecer só quando outro campo tem aquele valor.
 */
function zoe_ev_biblioteca()
{
    $celulas = zoe_ev_celulas();
    return array(
        'nome' => array(
            'titulo' => 'Nome e sobrenome',
            'campos' => array(
                // Dois campos para ninguém colocar só o primeiro nome. No pedido fica salvo junto como "Nome completo".
                'nome'      => array('label' => 'Nome', 'type' => 'text', 'req' => true, 'col' => 'first'),
                'sobrenome' => array('label' => 'Sobrenome', 'type' => 'text', 'req' => true, 'col' => 'last'),
            ),
        ),
        'whatsapp' => array(
            'titulo' => 'WhatsApp',
            'campos' => array(
                'whatsapp' => array('label' => 'WhatsApp', 'type' => 'tel', 'req' => true),
            ),
        ),
        'email' => array(
            'titulo' => 'E-mail do participante',
            'campos' => array(
                'email' => array('label' => 'E-mail do participante', 'type' => 'email', 'req' => false),
            ),
        ),
        'nascimento' => array(
            'titulo' => 'Data de nascimento',
            'campos' => array(
                'nascimento' => array('label' => 'Data de nascimento', 'type' => 'date', 'req' => true),
            ),
        ),
        'idade' => array(
            'titulo' => 'Idade',
            'campos' => array(
                'idade' => array('label' => 'Idade', 'type' => 'number', 'req' => true),
            ),
        ),
        'celula' => array(
            'titulo' => 'Célula (faz parte? qual? líder? quem convidou?)',
            'campos' => array(
                'celula_sim'  => array('label' => 'Você faz parte de uma célula?', 'type' => 'simnao', 'req' => true),
                'celula'      => array('label' => 'Qual a sua célula?', 'type' => 'select', 'options' => $celulas, 'req' => true, 'dep' => array('celula_sim', 'Sim')),
                'lider'       => array('label' => 'Quem é seu líder?', 'type' => 'text', 'req' => true, 'dep' => array('celula_sim', 'Sim')),
                'convidou'    => array('label' => 'Quem te convidou?', 'type' => 'text', 'req' => true, 'dep' => array('celula_sim', 'Não')),
            ),
        ),
        'igreja' => array(
            'titulo' => 'Igreja que frequenta',
            'campos' => array(
                'igreja' => array('label' => 'Qual igreja você frequenta?', 'type' => 'text', 'req' => false),
            ),
        ),
        'saude' => array(
            'titulo' => 'Medicamento / restrição alimentar',
            'campos' => array(
                'saude_sim' => array('label' => 'Faz uso de algum medicamento ou tem restrição alimentar?', 'type' => 'simnao', 'req' => true),
                'saude'     => array('label' => 'Qual medicamento ou restrição?', 'type' => 'textarea', 'req' => true, 'dep' => array('saude_sim', 'Sim')),
            ),
        ),
        'responsavel' => array(
            'titulo' => 'Responsável (para menores)',
            'campos' => array(
                'resp_nome' => array('label' => 'Nome do responsável', 'type' => 'text', 'req' => true),
                'resp_tel'  => array('label' => 'WhatsApp do responsável', 'type' => 'tel', 'req' => true),
            ),
        ),
        'camiseta' => array(
            'titulo' => 'Tamanho de camiseta',
            'campos' => array(
                'camiseta' => array('label' => 'Tamanho de camiseta', 'type' => 'select', 'options' => array('PP', 'P', 'M', 'G', 'GG', 'XGG', 'Infantil 4', 'Infantil 6', 'Infantil 8', 'Infantil 10', 'Infantil 12', 'Infantil 14'), 'req' => true),
            ),
        ),
        'casal' => array(
            'titulo' => 'Casal (nome dele, nome dela, estado civil)',
            'campos' => array(
                'nome_homem'   => array('label' => 'Nome do homem', 'type' => 'text', 'req' => true),
                'nome_mulher'  => array('label' => 'Nome da mulher', 'type' => 'text', 'req' => true),
                'estado_civil' => array('label' => 'Estado civil', 'type' => 'select', 'options' => array('Casados', 'Noivos', 'Namorados', 'União estável'), 'req' => true),
            ),
        ),
        'ano_encontro' => array(
            'titulo' => 'Ano em que fez o Encontro com Deus',
            'campos' => array(
                'ano_encontro' => array('label' => 'Em que ano você fez o Encontro com Deus?', 'type' => 'text', 'req' => true),
            ),
        ),
    );
}

/** Tipos disponíveis para perguntas personalizadas. */
function zoe_ev_tipos()
{
    return array(
        'text'     => 'Texto curto',
        'textarea' => 'Texto longo',
        'number'   => 'Número',
        'date'     => 'Data',
        'tel'      => 'Telefone',
        'email'    => 'E-mail',
        'select'   => 'Lista de opções',
        'simnao'   => 'Sim / Não',
    );
}

/** Formulário salvo no produto (ou null se o produto não usa o formulário Zoe). */
function zoe_ev_get_form($product_id)
{
    $parent = wp_get_post_parent_id($product_id);
    if ($parent) {
        $product_id = $parent;
    }
    if (!get_post_meta($product_id, '_zoe_evento', true)) {
        return null;
    }
    $form = get_post_meta($product_id, '_zoe_form', true);
    if (!is_array($form)) {
        $form = array();
    }
    return wp_parse_args($form, array(
        'blocos'         => array('nome', 'whatsapp'),
        'opcionais'      => array(),
        'custom'         => array(),
        'por_vaga'       => 1,
    ));
}

/**
 * Transforma a configuração do evento na lista final de campos (em ordem).
 * Retorna [chave => definição].
 */
function zoe_ev_campos_do_form($form)
{
    $lib = zoe_ev_biblioteca();
    $out = array();
    foreach ((array) $form['blocos'] as $bloco) {
        if (!isset($lib[$bloco])) {
            continue;
        }
        foreach ($lib[$bloco]['campos'] as $k => $def) {
            if (in_array($bloco, (array) $form['opcionais'], true) && empty($def['dep'])) {
                $def['req'] = false;
            }
            $out[$k] = $def;
        }
    }
    foreach ((array) $form['custom'] as $i => $c) {
        if (empty($c['label'])) {
            continue;
        }
        $def = array(
            'label' => $c['label'],
            'type'  => isset($c['type']) ? $c['type'] : 'text',
            'req'   => !empty($c['req']),
        );
        if ($def['type'] === 'select') {
            $def['options'] = array_values(array_filter(array_map('trim', explode(',', (string) $c['options']))));
        }
        $out['p' . ($i + 1)] = $def;
    }
    return $out;
}

/** Desenha um campo no checkout. $name é o atributo name completo. */
function zoe_ev_render_campo($key, $def, $name, $value, $id)
{
    $req   = !empty($def['req']);
    $attrs = '';
    if (!empty($def['dep'])) {
        $attrs = ' data-zoe-dep="' . esc_attr($def['dep'][0]) . '" data-zoe-val="' . esc_attr($def['dep'][1]) . '"';
    }
    $col = !empty($def['col']) && in_array($def['col'], array('first', 'last'), true) ? 'form-row-' . $def['col'] : 'form-row-wide';
    echo '<p class="form-row ' . $col . ' zoe-campo zoe-campo-' . esc_attr($key) . ($req ? ' validate-required' : '') . '" data-zoe-key="' . esc_attr($key) . '"' . $attrs . '>';
    echo '<label for="' . esc_attr($id) . '">' . esc_html($def['label']);
    echo $req ? ' <abbr class="required" title="obrigatório">*</abbr>' : ' <span class="optional">(opcional)</span>';
    echo '</label><span class="woocommerce-input-wrapper">';

    switch ($def['type']) {
        case 'textarea':
            echo '<textarea class="input-text" name="' . esc_attr($name) . '" id="' . esc_attr($id) . '" rows="2">' . esc_textarea($value) . '</textarea>';
            break;
        case 'select':
            echo '<select name="' . esc_attr($name) . '" id="' . esc_attr($id) . '"><option value="">Selecione…</option>';
            foreach ((array) $def['options'] as $opt) {
                echo '<option value="' . esc_attr($opt) . '"' . selected($value, $opt, false) . '>' . esc_html($opt) . '</option>';
            }
            echo '</select>';
            break;
        case 'simnao':
            foreach (array('Sim', 'Não') as $j => $opt) {
                echo '<label class="zoe-radio"><input type="radio" name="' . esc_attr($name) . '" value="' . esc_attr($opt) . '"' . checked($value, $opt, false) . ($j === 0 ? ' id="' . esc_attr($id) . '"' : '') . '> ' . esc_html($opt) . '</label>';
            }
            break;
        default:
            $type = in_array($def['type'], array('text', 'number', 'date', 'tel', 'email'), true) ? $def['type'] : 'text';
            echo '<input type="' . esc_attr($type) . '" class="input-text" name="' . esc_attr($name) . '" id="' . esc_attr($id) . '" value="' . esc_attr($value) . '"' . ($type === 'number' ? ' min="0"' : '') . '>';
    }
    echo '</span></p>';
}

/** Um campo com dependência só vale se a condição foi atendida. */
function zoe_ev_campo_ativo($def, $valores)
{
    if (empty($def['dep'])) {
        return true;
    }
    list($k, $v) = $def['dep'];
    return isset($valores[$k]) && $valores[$k] === $v;
}

/** Limpa um valor conforme o tipo. */
function zoe_ev_limpar($def, $v)
{
    $v = is_string($v) ? wp_unslash($v) : '';
    switch ($def['type']) {
        case 'textarea':
            return sanitize_textarea_field($v);
        case 'email':
            return sanitize_email($v);
        case 'number':
            return $v === '' ? '' : (string) absint($v);
        case 'date':
            $v = sanitize_text_field($v);
            if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m)) {
                return $m[3] . '/' . $m[2] . '/' . $m[1]; // salva como 21/08/1990
            }
            return $v;
        case 'select':
        case 'simnao':
            $opts = $def['type'] === 'simnao' ? array('Sim', 'Não') : (array) $def['options'];
            $v = sanitize_text_field($v);
            return in_array($v, $opts, true) ? $v : '';
        default:
            return sanitize_text_field($v);
    }
}

/** Campos como ficam salvos no pedido: Nome + Sobrenome viram "Nome completo". */
function zoe_ev_campos_para_salvar($campos)
{
    if (isset($campos['sobrenome'], $campos['nome'])) {
        $campos['nome']['label'] = 'Nome completo';
        unset($campos['sobrenome']);
    }
    return $campos;
}

function zoe_ev_juntar_nome($valores)
{
    if (isset($valores['sobrenome'])) {
        $valores['nome'] = trim((isset($valores['nome']) ? $valores['nome'] : '') . ' ' . $valores['sobrenome']);
        unset($valores['sobrenome']);
    }
    return $valores;
}

