<?php
/**
 * Configurações: lista de células e comportamento do checkout.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', function () {
    add_submenu_page('zoe-eventos', 'Configurações', 'Configurações', 'manage_woocommerce', 'zoe-config', 'zoe_ev_pagina_config');
}, 30);

function zoe_ev_pagina_config()
{
    echo '<div class="wrap zoe-wrap"><h1>Configurações — Zoe Eventos</h1>';
    zoe_ev_aviso();
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('zoe_ev_config');
    echo '<input type="hidden" name="action" value="zoe_ev_config">';

    $off = (array) get_option('zoe_ev_celulas_inativas', array());
    echo '<div class="zoe-card"><h2>Células</h2><p class="description">Aparecem na pergunta "Qual a sua célula?" de <strong>todos</strong> os eventos. Desmarque para esconder uma célula sem apagar (as inscrições antigas continuam com o nome).</p>';
    echo '<div id="zoe-cels">';
    foreach (zoe_ev_celulas(true) as $i => $c) {
        echo '<p class="zoe-cel"><input type="checkbox" name="cel_on[' . (int) $i . ']" value="1"' . checked(!in_array($c, $off, true), true, false) . ' title="Aparece na inscrição"> <input type="text" name="cel[' . (int) $i . ']" value="' . esc_attr($c) . '" class="regular-text"> <button type="button" class="button-link-delete zoe-del-cel">Apagar</button></p>';
    }
    echo '</div><p><button type="button" class="button" id="zoe-add-cel">+ Adicionar célula</button></p></div>';
    echo '<script>jQuery(function($){var n=1000;$("#zoe-add-cel").on("click",function(){$("#zoe-cels").append(\'<p class="zoe-cel"><input type="checkbox" name="cel_on[\'+n+\']" value="1" checked> <input type="text" name="cel[\'+n+\']" class="regular-text" placeholder="Nome da célula"> <button type="button" class="button-link-delete zoe-del-cel">Apagar</button></p>\');n++;});$(document).on("click",".zoe-del-cel",function(){if(confirm("Apagar esta célula da lista?"))$(this).closest("p").remove();});});</script>';

    $chk = function ($k, $txt, $desc) {
        echo '<p><label><input type="checkbox" name="s[' . esc_attr($k) . ']" value="1"' . checked((bool) zoe_ev_setting($k, 0), true, false) . '> ' . esc_html($txt) . '</label><br><span class="description">' . esc_html($desc) . '</span></p>';
    };
    echo '<div class="zoe-card"><h2>Checkout</h2>';
    $chk('direto_checkout', 'Ao clicar em "Inscreva-se", ir direto para a finalização', 'Pula a página do carrinho nos eventos.');
    $chk('simplificar', 'Dados de cobrança simplificados', 'Quando o carrinho só tem eventos, pede apenas nome, e-mail e WhatsApp de quem paga, sem endereço e sem os campos antigos.');
    $chk('pedir_cpf', 'Pedir CPF de quem paga', 'Ligue se o meio de pagamento (PIX/Mercado Pago) exigir CPF.');
    echo '</div>';
    submit_button('Salvar configurações');
    echo '</form></div>';
}

add_action('admin_post_zoe_ev_config', function () {
    if (!current_user_can('manage_woocommerce') || !check_admin_referer('zoe_ev_config')) {
        wp_die('Sem permissão.');
    }
    $nomes = array();
    $off = array();
    foreach ((array) (isset($_POST['cel']) ? wp_unslash($_POST['cel']) : array()) as $i => $nome) { // phpcs:ignore
        $nome = sanitize_text_field($nome);
        if ($nome === '' || in_array($nome, $nomes, true)) {
            continue;
        }
        $nomes[] = $nome;
        if (empty($_POST['cel_on'][$i])) {
            $off[] = $nome;
        }
    }
    update_option('zoe_ev_celulas', implode("\n", $nomes));
    update_option('zoe_ev_celulas_inativas', $off);
    $s = isset($_POST['s']) && is_array($_POST['s']) ? $_POST['s'] : array();
    update_option('zoe_ev_settings', array(
        'direto_checkout' => empty($s['direto_checkout']) ? 0 : 1,
        'simplificar'     => empty($s['simplificar']) ? 0 : 1,
        'pedir_cpf'       => empty($s['pedir_cpf']) ? 0 : 1,
    ));
    wp_safe_redirect(admin_url('admin.php?page=zoe-config&zoe_msg=config'));
    exit;
});
