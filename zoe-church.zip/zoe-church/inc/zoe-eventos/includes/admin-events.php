<?php
/**
 * Painel "Zoe Eventos": lista, criação/edição, duplicar, converter e exportar inscritos.
 */
if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_EV_CAP', 'edit_products');

add_action('admin_menu', function () {
    add_menu_page('Zoe Eventos', 'Zoe Eventos', ZOE_EV_CAP, 'zoe-eventos', 'zoe_ev_pagina_lista', 'dashicons-calendar-alt', 3);
    add_submenu_page('zoe-eventos', 'Eventos', 'Eventos', ZOE_EV_CAP, 'zoe-eventos', 'zoe_ev_pagina_lista');
    add_submenu_page('zoe-eventos', 'Novo evento', 'Novo evento', ZOE_EV_CAP, 'zoe-evento', 'zoe_ev_pagina_editor');
});

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos($hook, 'zoe-') === false) {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_style('zoe-ev-admin', ZOE_EV_URL . 'assets/admin.css', array(), ZOE_EV_VERSION);
    wp_enqueue_script('zoe-ev-admin', ZOE_EV_URL . 'assets/admin.js', array('jquery'), ZOE_EV_VERSION, true);
    wp_localize_script('zoe-ev-admin', 'ZoeEv', array('tipos' => zoe_ev_tipos()));
});

function zoe_ev_aviso()
{
    if (empty($_GET['zoe_msg'])) { // phpcs:ignore
        return;
    }
    $msgs = array(
        'salvo'      => 'Evento salvo.',
        'duplicado'  => 'Cópia criada como rascunho. Ajuste nome, datas e preço e publique.',
        'imagem'     => 'Imagem trocada. O cache foi limpo.',
        'desfeito'   => 'Alteração desfeita.',
        'config'     => 'Configurações salvas.',
        'erro'       => 'Não foi possível concluir. Tente de novo.',
    );
    $m = sanitize_key($_GET['zoe_msg']); // phpcs:ignore
    if (isset($msgs[$m])) {
        $tipo = $m === 'erro' ? 'error' : 'success';
        echo '<div class="notice notice-' . $tipo . ' is-dismissible"><p>' . esc_html($msgs[$m]) . '</p></div>';
    }
}

function zoe_ev_eventos($extra = array())
{
    return get_posts(array_merge(array(
        'post_type'      => 'product',
        'post_status'    => array('publish', 'draft', 'private', 'pending'),
        'posts_per_page' => 200,
        'meta_key'       => '_zoe_evento',
        'meta_value'     => '1',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ), $extra));
}

// ================= LISTA =================
function zoe_ev_pagina_lista()
{
    $eventos = zoe_ev_eventos();
    $novo    = admin_url('admin.php?page=zoe-evento');
    echo '<div class="wrap zoe-wrap"><h1 class="wp-heading-inline">Eventos</h1> <a class="page-title-action" href="' . esc_url($novo) . '">+ Novo evento</a><hr class="wp-header-end">';
    zoe_ev_aviso();

    if (!$eventos) {
        echo '<div class="zoe-vazio"><p>Nenhum evento criado no painel ainda.</p><p><a class="button button-primary button-hero" href="' . esc_url($novo) . '">Criar o primeiro evento</a></p></div>';
    } else {
        echo '<table class="widefat striped zoe-tabela"><thead><tr><th></th><th>Evento</th><th>Data</th><th>Inscrições até</th><th>Preço</th><th>Vendidos</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
        foreach ($eventos as $p) {
            $prod = wc_get_product($p->ID);
            if (!$prod) {
                continue;
            }
            $data  = get_post_meta($p->ID, '_zoe_data', true);
            $prazo = get_post_meta($p->ID, '_zoe_prazo', true);
            $edit  = admin_url('admin.php?page=zoe-evento&id=' . $p->ID);
            $dup   = wp_nonce_url(admin_url('admin-post.php?action=zoe_ev_duplicar&id=' . $p->ID), 'zoe_ev_dup_' . $p->ID);
            $exp   = wp_nonce_url(admin_url('admin-post.php?action=zoe_ev_exportar&id=' . $p->ID), 'zoe_ev_exp_' . $p->ID);
            $status = array('publish' => '<span class="zoe-tag zoe-ok">Publicado</span>', 'draft' => '<span class="zoe-tag">Rascunho</span>', 'private' => '<span class="zoe-tag">Privado</span>', 'pending' => '<span class="zoe-tag">Pendente</span>');
            if ($p->post_status === 'publish' && !$prod->is_purchasable()) {
                $status['publish'] = '<span class="zoe-tag zoe-fim">Encerrado</span>';
            }
            echo '<tr>';
            echo '<td class="zoe-thumb">' . $prod->get_image(array(48, 48)) . '</td>';
            echo '<td><strong><a href="' . esc_url($edit) . '">' . esc_html($prod->get_name()) . '</a></strong></td>';
            echo '<td>' . esc_html(zoe_ev_data_br($data)) . '</td>';
            echo '<td>' . esc_html($prazo ? zoe_ev_data_br($prazo) : '—') . '</td>';
            echo '<td>' . wp_kses_post($prod->get_price_html()) . '</td>';
            echo '<td>' . (int) $prod->get_total_sales() . '</td>';
            echo '<td>' . (isset($status[$p->post_status]) ? $status[$p->post_status] : esc_html($p->post_status)) . '</td>';
            echo '<td class="zoe-acoes"><a class="button" href="' . esc_url($edit) . '">Editar</a> ';
            echo '<a class="button" href="' . esc_url(get_permalink($p->ID)) . '" target="_blank">Ver</a> ';
            echo '<a class="button" href="' . esc_url($dup) . '">Duplicar</a> ';
            echo '<a class="button" href="' . esc_url($exp) . '">Baixar inscritos</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    // Produtos antigos que ainda dependem do plugin de campos.
    $antigos = get_posts(array(
        'post_type'      => 'product',
        'post_status'    => array('publish', 'draft', 'private'),
        'posts_per_page' => 200,
        'meta_query'     => array(array('key' => '_zoe_evento', 'compare' => 'NOT EXISTS')),
        'orderby'        => 'modified',
        'order'          => 'DESC',
    ));
    if ($antigos) {
        echo '<h2 class="zoe-sub">Produtos antigos</h2><p class="description">Estes produtos ainda usam os campos do plugin antigo. Clique em <strong>Usar formulário Zoe</strong> para escolher os campos de forma simples. Nada muda no produto até você salvar.</p>';
        echo '<table class="widefat striped zoe-tabela"><thead><tr><th>Produto</th><th>Status</th><th>Vendidos</th><th></th></tr></thead><tbody>';
        foreach ($antigos as $p) {
            $prod = wc_get_product($p->ID);
            if (!$prod) {
                continue;
            }
            echo '<tr><td>' . esc_html($prod->get_name()) . '</td><td>' . esc_html($p->post_status === 'publish' ? 'Publicado' : 'Rascunho') . '</td><td>' . (int) $prod->get_total_sales() . '</td>';
            echo '<td><a class="button" href="' . esc_url(admin_url('admin.php?page=zoe-evento&id=' . $p->ID)) . '">Usar formulário Zoe</a></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';
}

function zoe_ev_data_br($ymd)
{
    if (!$ymd) {
        return '—';
    }
    $t = strtotime($ymd);
    return $t ? date_i18n('d/m/Y', $t) : $ymd;
}

// ================= EDITOR =================
function zoe_ev_pagina_editor()
{
    $id   = isset($_GET['id']) ? absint($_GET['id']) : 0; // phpcs:ignore
    $prod = $id ? wc_get_product($id) : null;
    if ($id && !$prod) {
        echo '<div class="wrap"><p>Evento não encontrado.</p></div>';
        return;
    }
    $simples = !$prod || $prod->is_type('simple');
    $form    = $id ? zoe_ev_get_form($id) : null;
    $copiar  = isset($_GET['copiar_de']) ? absint($_GET['copiar_de']) : 0; // phpcs:ignore
    if ($copiar && ($f = zoe_ev_get_form($copiar))) {
        $form = $f;
    }
    if (!$form) {
        $form = array('blocos' => array('nome', 'whatsapp', 'celula'), 'opcionais' => array(), 'custom' => array(), 'por_vaga' => 1);
    }

    $v = array(
        'titulo'    => $prod ? $prod->get_name() : '',
        'status'    => $prod ? $prod->get_status() : 'draft',
        'imagem'    => $prod ? $prod->get_image_id() : 0,
        'img_pos'   => $prod ? (string) get_post_meta($prod->get_id(), '_zoe_img_pos', true) : '',
        'resumo'    => $prod ? $prod->get_short_description() : '',
        'descricao' => $prod ? $prod->get_description() : '',
        'preco'     => $prod && $simples ? $prod->get_regular_price() : '',
        'promo'     => $prod && $simples ? $prod->get_sale_price() : '',
        'vagas'     => $prod && $simples && $prod->get_manage_stock() ? $prod->get_stock_quantity() : '',
        'data'      => $id ? get_post_meta($id, '_zoe_data', true) : '',
        'prazo'     => $id ? get_post_meta($id, '_zoe_prazo', true) : '',
        'local'     => $id ? get_post_meta($id, '_zoe_local', true) : '',
    );

    echo '<div class="wrap zoe-wrap"><h1>' . ($id ? 'Editar evento' : 'Novo evento') . '</h1>';
    zoe_ev_aviso();
    if ($id && !get_post_meta($id, '_zoe_evento', true)) {
        echo '<div class="notice notice-info"><p>Este produto ainda usa o plugin de campos antigo. Ao salvar aqui, o checkout dele passa a usar o formulário abaixo.</p></div>';
    }
    if (!$simples) {
        echo '<div class="notice notice-warning"><p>Este produto tem variações (lotes/opções). Preço e vagas continuam sendo editados em <a href="' . esc_url(get_edit_post_link($id)) . '">Produtos</a>. Aqui você edita textos, imagem, datas e formulário.</p></div>';
    }

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="zoe-form">';
    wp_nonce_field('zoe_ev_salvar');
    echo '<input type="hidden" name="action" value="zoe_ev_salvar"><input type="hidden" name="id" value="' . (int) $id . '">';

    // --- Informações ---
    echo '<div class="zoe-card"><h2>1. Informações do evento</h2>';
    echo '<p><label>Nome do evento<br><input type="text" name="titulo" class="large-text" required value="' . esc_attr($v['titulo']) . '" placeholder="Ex.: Encontro com Deus Mulheres 2027"></label></p>';
    echo '<div class="zoe-grid">';
    echo '<p><label>Data do evento<br><input type="date" name="data" value="' . esc_attr($v['data']) . '"></label></p>';
    echo '<p><label>Inscrições até<br><input type="date" name="prazo" value="' . esc_attr($v['prazo']) . '"></label><br><span class="description">Depois desse dia, o botão de inscrição some sozinho.</span></p>';
    echo '<p><label>Local<br><input type="text" name="local" value="' . esc_attr($v['local']) . '" placeholder="Ex.: Zoe Church"></label></p>';
    echo '</div>';
    if ($simples) {
        echo '<div class="zoe-grid">';
        echo '<p><label>Preço (R$)<br><input type="text" name="preco" inputmode="decimal" value="' . esc_attr(wc_format_localized_price($v['preco'])) . '" placeholder="Ex.: 150,00"></label></p>';
        echo '<p><label>Preço promocional (opcional)<br><input type="text" name="promo" inputmode="decimal" value="' . esc_attr(wc_format_localized_price($v['promo'])) . '"></label></p>';
        echo '<p><label>Número de vagas<br><input type="number" min="0" name="vagas" value="' . esc_attr($v['vagas']) . '" placeholder="Deixe vazio = sem limite"></label></p>';
        echo '</div>';
    }
    echo '<p><label>Resumo (aparece perto do botão de inscrição)<br><textarea name="resumo" rows="3" class="large-text">' . esc_textarea($v['resumo']) . '</textarea></label></p>';
    echo '<p><strong>Descrição completa</strong></p>';
    wp_editor($v['descricao'], 'zoe_descricao', array('textarea_name' => 'descricao', 'textarea_rows' => 8, 'media_buttons' => true));
    echo '</div>';

    // --- Imagem ---
    $img = $v['imagem'] ? wp_get_attachment_image_url($v['imagem'], 'medium') : '';
    echo '<div class="zoe-card"><h2>2. Imagem do evento</h2>';
    $pos = preg_match('/^\d{1,3}% \d{1,3}%$/', $v['img_pos']) ? $v['img_pos'] : '50% 50%';
    list($px, $py) = explode(' ', $pos);
    echo '<div class="zoe-img-pick" data-w="1080" data-h="1080"><div class="zoe-foco" style="background-position:' . esc_attr($pos) . ($img ? ';background-image:url(' . esc_url($img) . ')' : '') . '"><span class="zoe-ponto" style="left:' . esc_attr($px) . ';top:' . esc_attr($py) . '"></span></div>';
    echo '<input type="hidden" name="imagem" value="' . (int) $v['imagem'] . '"><input type="hidden" name="img_pos" value="' . esc_attr($pos) . '">';
    echo '<p class="zoe-spec"><strong>Ideal: 1080 × 1080 px · quadrado 1:1.</strong> Pode ser a mesma arte do post do Instagram. Toque na prévia para marcar o ponto que sempre aparece.</p><p class="zoe-aviso-img"></p>';
    echo '<p><button type="button" class="button zoe-escolher-img">Escolher imagem</button> <button type="button" class="button-link zoe-remover-img">Remover</button></p></div></div>';

    // --- Formulário ---
    $lib = zoe_ev_biblioteca();
    echo '<div class="zoe-card"><h2>3. Formulário de inscrição</h2>';
    echo '<p class="description">Marque o que deve ser perguntado <strong>neste evento</strong>. Só esses campos aparecem no checkout, um bloco por inscrição.</p>';
    $outros = array_filter(zoe_ev_eventos(), function ($p) use ($id) {
        return $p->ID !== $id;
    });
    if ($outros) {
        echo '<p><label>Copiar formulário de outro evento: <select class="zoe-copiar" data-base="' . esc_url(admin_url('admin.php?page=zoe-evento' . ($id ? '&id=' . $id : ''))) . '"><option value="">— escolher —</option>';
        foreach ($outros as $o) {
            echo '<option value="' . (int) $o->ID . '"' . selected($copiar, $o->ID, false) . '>' . esc_html($o->post_title) . '</option>';
        }
        echo '</select></label></p>';
    }
    echo '<table class="widefat zoe-blocos"><thead><tr><th>Usar</th><th>Pergunta</th><th>Opcional?</th></tr></thead><tbody>';
    foreach ($lib as $k => $b) {
        $on  = in_array($k, (array) $form['blocos'], true);
        $opc = in_array($k, (array) $form['opcionais'], true);
        echo '<tr><td><input type="checkbox" name="blocos[]" value="' . esc_attr($k) . '"' . checked($on, true, false) . ' id="zb_' . esc_attr($k) . '"></td>';
        echo '<td><label for="zb_' . esc_attr($k) . '">' . esc_html($b['titulo']) . '</label></td>';
        echo '<td><input type="checkbox" name="opcionais[]" value="' . esc_attr($k) . '"' . checked($opc, true, false) . '></td></tr>';
    }
    echo '</tbody></table>';

    echo '<h3>Perguntas personalizadas</h3><p class="description">Para algo específico deste evento (ex.: "Turma", "Já participou antes?"). Em "Lista de opções", separe as opções por vírgula.</p>';
    echo '<table class="widefat zoe-custom"><thead><tr><th>Pergunta</th><th>Tipo</th><th>Opções</th><th>Obrigatória</th><th></th></tr></thead><tbody>';
    foreach ((array) $form['custom'] as $i => $c) {
        zoe_ev_linha_custom($i, $c);
    }
    echo '</tbody></table><p><button type="button" class="button zoe-add-custom">+ Adicionar pergunta</button></p>';
    echo '<p><label><input type="checkbox" name="por_vaga" value="1"' . checked(!empty($form['por_vaga']), true, false) . '> Pedir os dados de <strong>cada pessoa</strong> quando comprarem mais de uma vaga</label></p>';
    echo '</div>';

    // --- Publicação ---
    echo '<div class="zoe-card zoe-salvar"><label>Status: <select name="status"><option value="publish"' . selected($v['status'], 'publish', false) . '>Publicado (aceitando inscrições)</option><option value="draft"' . selected($v['status'], 'draft', false) . '>Rascunho (escondido)</option></select></label> ';
    submit_button($id ? 'Salvar evento' : 'Criar evento', 'primary large', 'submit', false);
    if ($id) {
        echo ' <a class="button button-large" target="_blank" href="' . esc_url(get_permalink($id)) . '">Ver página</a>';
    }
    echo '</div></form></div>';

    echo '<script type="text/template" id="zoe-tpl-custom">';
    zoe_ev_linha_custom('__i__', array());
    echo '</script>';
}

function zoe_ev_linha_custom($i, $c)
{
    $c = wp_parse_args($c, array('label' => '', 'type' => 'text', 'options' => '', 'req' => 0));
    echo '<tr><td><input type="text" class="regular-text" name="custom[' . esc_attr($i) . '][label]" value="' . esc_attr($c['label']) . '" placeholder="Ex.: Qual sua turma?"></td><td><select name="custom[' . esc_attr($i) . '][type]">';
    foreach (zoe_ev_tipos() as $k => $t) {
        echo '<option value="' . esc_attr($k) . '"' . selected($c['type'], $k, false) . '>' . esc_html($t) . '</option>';
    }
    echo '</select></td><td><input type="text" name="custom[' . esc_attr($i) . '][options]" value="' . esc_attr($c['options']) . '" placeholder="Opção 1, Opção 2"></td>';
    echo '<td><input type="checkbox" name="custom[' . esc_attr($i) . '][req]" value="1"' . checked(!empty($c['req']), true, false) . '></td>';
    echo '<td><button type="button" class="button-link zoe-del-custom" aria-label="Remover"><span class="dashicons dashicons-no-alt"></span></button></td></tr>';
}

// ================= SALVAR =================
add_action('admin_post_zoe_ev_salvar', function () {
    if (!current_user_can(ZOE_EV_CAP) || !check_admin_referer('zoe_ev_salvar')) {
        wp_die('Sem permissão.');
    }
    $id   = absint($_POST['id']);
    $prod = $id ? wc_get_product($id) : new WC_Product_Simple();
    if (!$prod) {
        wp_safe_redirect(admin_url('admin.php?page=zoe-eventos&zoe_msg=erro'));
        exit;
    }
    $p = wp_unslash($_POST);

    $prod->set_name(sanitize_text_field($p['titulo']));
    $prod->set_status(in_array($p['status'], array('publish', 'draft'), true) ? $p['status'] : 'draft');
    $prod->set_short_description(wp_kses_post($p['resumo']));
    $prod->set_description(wp_kses_post($p['descricao']));
    $prod->set_image_id(absint($p['imagem']));
    $ipos = isset($p['img_pos']) ? sanitize_text_field($p['img_pos']) : '';

    if ($prod->is_type('simple')) {
        $prod->set_virtual(true);
        $prod->set_regular_price(zoe_ev_preco(isset($p['preco']) ? $p['preco'] : ''));
        $prod->set_sale_price(zoe_ev_preco(isset($p['promo']) ? $p['promo'] : ''));
        if (isset($p['vagas']) && $p['vagas'] !== '') {
            $prod->set_manage_stock(true);
            $prod->set_stock_quantity(absint($p['vagas']));
            $prod->set_stock_status(absint($p['vagas']) > 0 ? 'instock' : 'outofstock');
        } else {
            $prod->set_manage_stock(false);
            $prod->set_stock_status('instock');
        }
    }

    $lib     = array_keys(zoe_ev_biblioteca());
    $blocos  = array_values(array_intersect($lib, (array) (isset($p['blocos']) ? $p['blocos'] : array())));
    $opc     = array_values(array_intersect($lib, (array) (isset($p['opcionais']) ? $p['opcionais'] : array())));
    $custom  = array();
    foreach ((array) (isset($p['custom']) ? $p['custom'] : array()) as $c) {
        if (!is_array($c) || trim((string) $c['label']) === '') {
            continue;
        }
        $custom[] = array(
            'label'   => sanitize_text_field($c['label']),
            'type'    => array_key_exists($c['type'], zoe_ev_tipos()) ? $c['type'] : 'text',
            'options' => sanitize_text_field(isset($c['options']) ? $c['options'] : ''),
            'req'     => !empty($c['req']) ? 1 : 0,
        );
    }

    $prod->update_meta_data('_zoe_evento', '1');
    $prod->update_meta_data('_zoe_form', array('blocos' => $blocos, 'opcionais' => $opc, 'custom' => $custom, 'por_vaga' => !empty($p['por_vaga']) ? 1 : 0));
    $prod->update_meta_data('_zoe_data', zoe_ev_data_valida($p['data']));
    $prod->update_meta_data('_zoe_prazo', zoe_ev_data_valida($p['prazo']));
    $prod->update_meta_data('_zoe_local', sanitize_text_field($p['local']));
    $novo_id = $prod->save();
    update_post_meta($prod->get_id(), '_zoe_img_pos', preg_match('/^\d{1,3}% \d{1,3}%$/', $ipos) ? $ipos : '50% 50%');

    zoe_ev_limpar_cache();
    wp_safe_redirect(admin_url('admin.php?page=zoe-evento&id=' . $novo_id . '&zoe_msg=salvo'));
    exit;
});

/** Aceita "150", "150,00", "1.500,00" ou "150.00". */
function zoe_ev_preco($s)
{
    $s = preg_replace('/[^\d,\.]/', '', (string) $s);
    if ($s === '') {
        return '';
    }
    if (strpos($s, ',') !== false) {
        $s = str_replace(',', '.', str_replace('.', '', $s));
    } elseif (substr_count($s, '.') > 1 || preg_match('/\.\d{3}$/', $s)) {
        $s = str_replace('.', '', $s);
    }
    return wc_format_decimal($s, 2);
}

function zoe_ev_data_valida($d)
{
    $d = sanitize_text_field((string) $d);
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) ? $d : '';
}

function zoe_ev_limpar_cache()
{
    do_action('litespeed_purge_all');
    if (class_exists('\Elementor\Plugin')) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
}

// ================= DUPLICAR =================
add_action('admin_post_zoe_ev_duplicar', function () {
    $id = absint($_GET['id']); // phpcs:ignore
    if (!current_user_can(ZOE_EV_CAP) || !check_admin_referer('zoe_ev_dup_' . $id)) {
        wp_die('Sem permissão.');
    }
    $orig = wc_get_product($id);
    if (!$orig) {
        wp_die('Evento não encontrado.');
    }
    if ($orig->is_type('simple')) {
        $novo = new WC_Product_Simple();
        $novo->set_regular_price($orig->get_regular_price());
        $novo->set_sale_price($orig->get_sale_price());
        $novo->set_virtual(true);
        if ($orig->get_manage_stock()) {
            $novo->set_manage_stock(true);
            $novo->set_stock_quantity((int) $orig->get_stock_quantity() + (int) $orig->get_total_sales());
        }
    } else {
        if (!class_exists('WC_Admin_Duplicate_Product')) {
            include_once WC_ABSPATH . 'includes/admin/class-wc-admin-duplicate-product.php';
        }
        $dup  = new WC_Admin_Duplicate_Product();
        $novo = $dup->product_duplicate($orig);
    }
    $novo->set_name($orig->get_name() . ' (cópia)');
    $novo->set_status('draft');
    $novo->set_description($orig->get_description());
    $novo->set_short_description($orig->get_short_description());
    $novo->set_image_id($orig->get_image_id());
    $novo->set_category_ids($orig->get_category_ids());
    $novo->set_total_sales(0);
    foreach (array('_zoe_evento', '_zoe_form', '_zoe_local') as $k) {
        $novo->update_meta_data($k, $orig->get_meta($k));
    }
    $novo->update_meta_data('_zoe_data', '');
    $novo->update_meta_data('_zoe_prazo', '');
    $nid = $novo->save();
    wp_safe_redirect(admin_url('admin.php?page=zoe-evento&id=' . $nid . '&zoe_msg=duplicado'));
    exit;
});

// ================= EXPORTAR INSCRITOS (CSV para Excel) =================
add_action('admin_post_zoe_ev_exportar', function () {
    global $wpdb;
    $id = absint($_GET['id']); // phpcs:ignore
    if (!current_user_can(ZOE_EV_CAP) || !check_admin_referer('zoe_ev_exp_' . $id)) {
        wp_die('Sem permissão.');
    }
    $prod = wc_get_product($id);
    $itens = $wpdb->get_results($wpdb->prepare(
        "SELECT oi.order_item_id, oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
         JOIN {$wpdb->prefix}woocommerce_order_itemmeta m ON m.order_item_id = oi.order_item_id AND m.meta_key = '_product_id'
         WHERE oi.order_item_type = 'line_item' AND m.meta_value = %d ORDER BY oi.order_id ASC",
        $id
    ));

    // Rótulos dos campos antigos (para inscrições feitas antes do formulário Zoe).
    $antigos = array();
    $wooccm  = get_option('wooccm_billing');
    if (is_array($wooccm)) {
        foreach ($wooccm as $f) {
            if (!empty($f['name']) && !empty($f['label'])) {
                $antigos['_billing_' . $f['name']] = $f['label'];
            }
        }
    }

    $linhas  = array();
    $colunas = array();
    $validos = array('completed', 'processing', 'on-hold');
    foreach ($itens as $r) {
        $order = wc_get_order($r->order_id);
        if (!$order || !in_array($order->get_status(), $validos, true)) {
            continue;
        }
        $item = $order->get_item($r->order_item_id);
        if (!$item) {
            continue;
        }
        $base = array(
            'Pedido'   => $order->get_order_number(),
            'Data'     => $order->get_date_created() ? $order->get_date_created()->date_i18n('d/m/Y H:i') : '',
            'Status'   => wc_get_order_status_name($order->get_status()),
            'Pagador'  => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'E-mail'   => $order->get_billing_email(),
            'Telefone' => $order->get_billing_phone(),
            'Valor'    => wc_format_localized_price($item->get_total()),
        );
        $insc = $item->get_meta('_zoe_inscricoes');
        if (is_array($insc) && $insc) {
            foreach ($insc as $n => $dados) {
                $linha = $base + array('Inscrição' => ($n + 1) . ' de ' . count($insc));
                foreach ((array) $dados as $rot => $val) {
                    $linha[$rot] = $val;
                    $colunas[$rot] = true;
                }
                $linhas[] = $linha;
            }
        } else {
            $linha = $base + array('Inscrição' => 'Qtd. ' . $item->get_quantity());
            foreach ($antigos as $mk => $rot) {
                $val = $order->get_meta($mk);
                if (is_array($val)) {
                    $val = implode(', ', $val);
                }
                if ($val !== '' && $val !== null && $val !== 'Selecione') {
                    $linha[$rot] = $val;
                    $colunas[$rot] = true;
                }
            }
            $linhas[] = $linha;
        }
    }

    $cab = array_merge(array('Pedido', 'Data', 'Status', 'Pagador', 'E-mail', 'Telefone', 'Valor', 'Inscrição'), array_keys($colunas));
    $arq = sanitize_file_name('inscritos-' . ($prod ? $prod->get_slug() : $id) . '-' . date('Y-m-d') . '.csv');
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $arq . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // acentos corretos no Excel
    fputcsv($out, $cab, ';');
    foreach ($linhas as $l) {
        $row = array();
        foreach ($cab as $c) {
            $row[] = isset($l[$c]) ? $l[$c] : '';
        }
        fputcsv($out, $row, ';');
    }
    fclose($out);
    exit;
});
