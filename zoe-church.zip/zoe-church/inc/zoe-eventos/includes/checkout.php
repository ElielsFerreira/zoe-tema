<?php
/**
 * Checkout organizado: um bloco por evento e por vaga, só com os campos daquele evento.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Itens do carrinho que usam formulário Zoe: [cart_key => [item, form, campos, vagas]]. */
function zoe_ev_itens_carrinho()
{
    $out = array();
    if (!function_exists('WC') || !WC()->cart) {
        return $out;
    }
    foreach (WC()->cart->get_cart() as $key => $item) {
        $form = zoe_ev_get_form($item['product_id']);
        if (!$form) {
            continue;
        }
        $campos = zoe_ev_campos_do_form($form);
        if (!$campos) {
            continue;
        }
        $vagas = !empty($form['por_vaga']) ? min(20, max(1, (int) $item['quantity'])) : 1;
        $out[$key] = array('item' => $item, 'form' => $form, 'campos' => $campos, 'vagas' => $vagas);
    }
    return $out;
}

/** O carrinho tem só eventos Zoe? */
function zoe_ev_carrinho_so_eventos()
{
    if (!function_exists('WC') || !WC()->cart || WC()->cart->is_empty()) {
        return false;
    }
    foreach (WC()->cart->get_cart() as $item) {
        if (!zoe_ev_get_form($item['product_id'])) {
            return false;
        }
    }
    return true;
}

// ---------- Desenho dos blocos ----------
add_action('woocommerce_checkout_after_customer_details', 'zoe_ev_render_blocos', 5);
function zoe_ev_render_blocos()
{
    $itens = zoe_ev_itens_carrinho();
    if (!$itens) {
        return;
    }
    $post = isset($_POST['zoe']) && is_array($_POST['zoe']) ? $_POST['zoe'] : array(); // phpcs:ignore
    echo '<div id="zoe-inscricoes"><h3>Dados das inscrições</h3>';
    foreach ($itens as $key => $d) {
        $nome = $d['item']['data']->get_name();
        for ($n = 1; $n <= $d['vagas']; $n++) {
            $titulo = $d['vagas'] > 1 ? sprintf('%s — inscrição %d de %d', $nome, $n, $d['vagas']) : $nome;
            echo '<fieldset class="zoe-bloco"><legend>' . esc_html($titulo) . '</legend>';
            foreach ($d['campos'] as $k => $def) {
                $name  = "zoe[$key][$n][$k]";
                $id    = 'zoe_' . substr(md5($key), 0, 8) . "_{$n}_{$k}";
                $value = isset($post[$key][$n][$k]) ? wp_unslash($post[$key][$n][$k]) : '';
                zoe_ev_render_campo($k, $def, $name, is_string($value) ? $value : '', $id);
            }
            echo '</fieldset>';
        }
    }
    echo '</div>';
}

add_action('wp_enqueue_scripts', function () {
    if (!function_exists('is_checkout') || !is_checkout()) {
        return;
    }
    wp_enqueue_style('zoe-ev-checkout', ZOE_EV_URL . 'assets/checkout.css', array(), ZOE_EV_VERSION);
    wp_enqueue_script('zoe-ev-checkout', ZOE_EV_URL . 'assets/checkout.js', array(), ZOE_EV_VERSION, true);
});

// ---------- Validação ----------
add_action('woocommerce_after_checkout_validation', function ($data, $errors) {
    $post = isset($_POST['zoe']) && is_array($_POST['zoe']) ? $_POST['zoe'] : array(); // phpcs:ignore
    foreach (zoe_ev_itens_carrinho() as $key => $d) {
        $nome = $d['item']['data']->get_name();
        for ($n = 1; $n <= $d['vagas']; $n++) {
            $valores = array();
            foreach ($d['campos'] as $k => $def) {
                $valores[$k] = zoe_ev_limpar($def, isset($post[$key][$n][$k]) ? $post[$key][$n][$k] : '');
            }
            $quem = $d['vagas'] > 1 ? "$nome (inscrição $n)" : $nome;
            foreach ($d['campos'] as $k => $def) {
                if (!zoe_ev_campo_ativo($def, $valores)) {
                    continue;
                }
                if (!empty($def['req']) && $valores[$k] === '') {
                    $errors->add('zoe_' . $k, sprintf('<strong>%s</strong>: preencha "%s".', esc_html($quem), esc_html($def['label'])));
                } elseif (in_array($k, array('nome_homem', 'nome_mulher', 'resp_nome'), true) && $valores[$k] !== '' && count(preg_split('/\s+/', trim($valores[$k]))) < 2) {
                    $errors->add('zoe_' . $k, sprintf('<strong>%s</strong>: escreva nome e sobrenome em "%s".', esc_html($quem), esc_html($def['label'])));
                } elseif ($k === 'sobrenome' && $valores[$k] !== '' && mb_strlen($valores[$k]) < 2) {
                    $errors->add('zoe_' . $k, sprintf('<strong>%s</strong>: confira o sobrenome.', esc_html($quem)));
                } elseif ($def['type'] === 'email' && $valores[$k] !== '' && !is_email($valores[$k])) {
                    $errors->add('zoe_' . $k, sprintf('<strong>%s</strong>: o e-mail em "%s" não é válido.', esc_html($quem), esc_html($def['label'])));
                } elseif ($def['type'] === 'tel' && $valores[$k] !== '' && strlen(preg_replace('/\D/', '', $valores[$k])) < 10) {
                    $errors->add('zoe_' . $k, sprintf('<strong>%s</strong>: confira o telefone em "%s" (com DDD).', esc_html($quem), esc_html($def['label'])));
                }
            }
        }
    }
}, 10, 2);

// ---------- Salvar no pedido (em cada item, separado por inscrição) ----------
add_action('woocommerce_checkout_create_order_line_item', function ($order_item, $cart_key, $values, $order) {
    $form = zoe_ev_get_form($values['product_id']);
    if (!$form) {
        return;
    }
    $campos_form = zoe_ev_campos_do_form($form);
    $campos = zoe_ev_campos_para_salvar($campos_form);
    $vagas  = !empty($form['por_vaga']) ? min(20, max(1, (int) $values['quantity'])) : 1;
    $post   = isset($_POST['zoe'][$cart_key]) && is_array($_POST['zoe'][$cart_key]) ? $_POST['zoe'][$cart_key] : array(); // phpcs:ignore
    $todas  = array();
    for ($n = 1; $n <= $vagas; $n++) {
        $valores = array();
        foreach ($campos_form as $k => $def) {
            $valores[$k] = zoe_ev_limpar($def, isset($post[$n][$k]) ? $post[$n][$k] : '');
        }
        $valores = zoe_ev_juntar_nome($valores);
        $linha = array();
        foreach ($campos as $k => $def) {
            if (!zoe_ev_campo_ativo($def, $valores) || $valores[$k] === '') {
                continue;
            }
            $linha[$def['label']] = $valores[$k];
            $rotulo = $vagas > 1 ? "Inscrição $n · {$def['label']}" : $def['label'];
            $order_item->add_meta_data($rotulo, $valores[$k]);
        }
        $todas[] = $linha;
    }
    $order_item->add_meta_data('_zoe_inscricoes', $todas);
}, 10, 4);

// ---------- Cobrança simplificada quando o carrinho só tem eventos ----------
add_filter('woocommerce_checkout_fields', function ($fields) {
    if (!zoe_ev_setting('simplificar', 1) || !zoe_ev_carrinho_so_eventos()) {
        return $fields;
    }
    // O nome de quem paga vem da própria inscrição (não pergunta o nome duas vezes).
    $manter = array('billing_email', 'billing_phone', 'billing_country');
    foreach (array_keys($fields['billing']) as $k) {
        if (!in_array($k, $manter, true)) {
            unset($fields['billing'][$k]); // inclui os campos antigos do Checkout Field Manager
        }
    }
    $base = array('required' => true, 'class' => array('form-row-wide'));
    $fields['billing']['billing_email']      = array_merge(isset($fields['billing']['billing_email']) ? $fields['billing']['billing_email'] : array(), $base, array('label' => 'E-mail (a confirmação chega aqui)', 'type' => 'email', 'validate' => array('email'), 'priority' => 30));
    $fields['billing']['billing_phone']      = array_merge(isset($fields['billing']['billing_phone']) ? $fields['billing']['billing_phone'] : array(), $base, array('label' => 'WhatsApp de quem está pagando', 'type' => 'tel', 'validate' => array('phone'), 'priority' => 40));
    $fields['billing']['billing_country']    = array('type' => 'hidden', 'default' => 'BR', 'required' => false, 'priority' => 90);
    if (zoe_ev_setting('pedir_cpf', 0)) {
        $fields['billing']['billing_cpf'] = array_merge($base, array('label' => 'CPF de quem está pagando', 'priority' => 50));
    }
    unset($fields['order']['order_comments']);
    return $fields;
}, 9999);

// Nome de quem paga = responsável (se houver) ou o primeiro inscrito.
add_filter('woocommerce_checkout_posted_data', function ($data) {
    if (!zoe_ev_setting('simplificar', 1) || !zoe_ev_carrinho_so_eventos() || !empty($data['billing_first_name'])) {
        return $data;
    }
    $post = isset($_POST['zoe']) && is_array($_POST['zoe']) ? wp_unslash($_POST['zoe']) : array(); // phpcs:ignore
    $nome = '';
    foreach ($post as $vagas) {
        $p = is_array($vagas) ? reset($vagas) : null;
        if (!is_array($p)) {
            continue;
        }
        if (!empty($p['resp_nome'])) {
            $nome = $p['resp_nome'];
        } elseif (!empty($p['nome'])) {
            $nome = $p['nome'] . (!empty($p['sobrenome']) ? ' ' . $p['sobrenome'] : '');
        } elseif (!empty($p['nome_homem'])) {
            $nome = $p['nome_homem'] . (!empty($p['nome_mulher']) ? ' e ' . $p['nome_mulher'] : '');
        }
        if ($nome !== '') {
            break;
        }
    }
    $nome = trim(sanitize_text_field((string) $nome));
    if ($nome === '') {
        $nome = isset($data['billing_email']) ? (string) strtok($data['billing_email'], '@') : 'Participante';
    }
    $partes = preg_split('/\s+/', $nome, 2);
    $data['billing_first_name'] = $partes[0];
    $data['billing_last_name']  = isset($partes[1]) ? $partes[1] : '';
    return $data;
});

add_action('woocommerce_after_checkout_validation', function ($data, $errors) {
    if (!zoe_ev_setting('pedir_cpf', 0) || !zoe_ev_carrinho_so_eventos()) {
        return;
    }
    $cpf = preg_replace('/\D/', '', isset($_POST['billing_cpf']) ? wp_unslash($_POST['billing_cpf']) : ''); // phpcs:ignore
    if ($cpf !== '' && !zoe_ev_cpf_valido($cpf)) {
        $errors->add('billing_cpf', '<strong>CPF</strong> inválido. Confira os números.');
    }
}, 10, 2);

add_action('woocommerce_checkout_create_order', function ($order) {
    if (isset($_POST['billing_cpf'])) { // phpcs:ignore
        $order->update_meta_data('_billing_cpf', sanitize_text_field(wp_unslash($_POST['billing_cpf']))); // phpcs:ignore
    }
});

function zoe_ev_cpf_valido($c)
{
    if (strlen($c) !== 11 || preg_match('/^(\d)\1{10}$/', $c)) {
        return false;
    }
    for ($t = 9; $t < 11; $t++) {
        $s = 0;
        for ($i = 0; $i < $t; $i++) {
            $s += (int) $c[$i] * (($t + 1) - $i);
        }
        $d = ((10 * $s) % 11) % 10;
        if ((int) $c[$t] !== $d) {
            return false;
        }
    }
    return true;
}

// Sem caixa de "observações do pedido" quando o carrinho só tem eventos
add_filter('woocommerce_enable_order_notes_field', function ($on) {
    return (zoe_ev_setting('simplificar', 1) && zoe_ev_carrinho_so_eventos()) ? false : $on;
});

// Sem o aviso "adicionado ao carrinho" quando a pessoa já vai direto para a finalização
add_filter('wc_add_to_cart_message_html', function ($msg, $products) {
    if (!zoe_ev_setting('direto_checkout', 1)) {
        return $msg;
    }
    foreach (array_keys((array) $products) as $pid) {
        if (!zoe_ev_get_form($pid)) {
            return $msg;
        }
    }
    return '';
}, 10, 2);

// ---------- Ir direto para o checkout ao se inscrever ----------
add_filter('woocommerce_add_to_cart_redirect', function ($url, $product = null) {
    if (!zoe_ev_setting('direto_checkout', 1)) {
        return $url;
    }
    $pid = $product instanceof WC_Product ? $product->get_id() : (isset($_REQUEST['add-to-cart']) ? absint($_REQUEST['add-to-cart']) : 0); // phpcs:ignore
    return ($pid && zoe_ev_get_form($pid)) ? wc_get_checkout_url() : $url;
}, 20, 2);

// ---------- Inscrições encerram sozinhas na data limite ----------
add_filter('woocommerce_is_purchasable', function ($ok, $product) {
    $id    = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
    $prazo = get_post_meta($id, '_zoe_prazo', true);
    if ($ok && $prazo && get_post_meta($id, '_zoe_evento', true)) {
        $fim = strtotime($prazo . ' 23:59:59 ' . wp_timezone_string());
        if ($fim && time() > $fim) {
            return false;
        }
    }
    return $ok;
}, 10, 2);

add_action('woocommerce_single_product_summary', function () {
    global $product;
    if ($product && get_post_meta($product->get_id(), '_zoe_evento', true) && !$product->is_purchasable()) {
        echo '<p class="zoe-encerrado"><strong>Inscrições encerradas.</strong></p>';
    }
}, 31);

// ---------- Formulário antigo: lista de células = só as ativas ----------
// Os campos do plugin antigo têm as células escritas à mão (com redes que já não existem).
// Em qualquer pergunta de escolha que liste células, ficam só as ativas em Zoe Eventos → Células
// (mais "Selecione", "Nenhuma", "Não faço parte" e parecidas).
function zoe_ev_norm($s)
{
    $s = remove_accents(mb_strtolower(trim(wp_strip_all_tags((string) $s))));
    return trim(preg_replace('/\s+/', ' ', $s));
}
function zoe_ev_filtrar_opcoes_celula($campos)
{
    if (!function_exists('zoe_ev_celulas')) {
        return $campos;
    }
    $ativas = array_map('zoe_ev_norm', zoe_ev_celulas());
    $todas  = array_map('zoe_ev_norm', zoe_ev_celulas(true));
    if (!$ativas) {
        return $campos;
    }
    $bate = function ($op, $lista) {
        $op = zoe_ev_norm($op);
        if ($op === '') {
            return false;
        }
        foreach ($lista as $c) {
            if ($op === $c || strpos($c, $op) === 0 || strpos($op, $c) === 0) {
                return true;
            }
        }
        return false;
    };
    foreach ($campos as $k => $f) {
        if (empty($f['options']) || !is_array($f['options'])) {
            continue;
        }
        $rotulo = isset($f['label']) ? zoe_ev_norm($f['label']) : '';
        $ehCelula = (bool) preg_match('/celula|rede/', $rotulo);
        if (!$ehCelula) {
            foreach ($f['options'] as $v => $txt) {
                if ($bate(is_array($txt) ? (isset($txt['label']) ? $txt['label'] : '') : $txt, $todas)) {
                    $ehCelula = true;
                    break;
                }
            }
        }
        if (!$ehCelula) {
            continue;
        }
        $novas = array();
        $sobrou = 0;
        foreach ($f['options'] as $v => $txt) {
            $t = is_array($txt) ? (isset($txt['label']) ? $txt['label'] : '') : $txt;
            $n = zoe_ev_norm($t);
            $neutra = $n === '' || preg_match('/^(selecione|escolha|nenhum|nenhuma|nao|não|sim|outra|outro|ainda nao)/', $n);
            if ($neutra || $bate($t, $ativas)) {
                $novas[$v] = $txt;
                if (!$neutra) {
                    $sobrou++;
                }
            }
        }
        if ($sobrou) { // só troca se sobrar ao menos uma célula (não quebra perguntas que não são de célula)
            $campos[$k]['options'] = $novas;
        }
    }
    return $campos;
}
add_filter('woocommerce_billing_fields', 'zoe_ev_filtrar_opcoes_celula', 99999);
add_filter('woocommerce_checkout_fields', function ($fields) {
    foreach (array('billing', 'shipping', 'order', 'additional') as $g) {
        if (!empty($fields[$g]) && is_array($fields[$g])) {
            $fields[$g] = zoe_ev_filtrar_opcoes_celula($fields[$g]);
        }
    }
    return $fields;
}, 99999);

// E-mail sempre obrigatório em qualquer compra (é para onde vai a confirmação).
add_filter('woocommerce_billing_fields', function ($campos) {
    if (isset($campos['billing_email'])) {
        $campos['billing_email']['required'] = true;
    } else {
        $campos['billing_email'] = array('label' => 'E-mail (a confirmação chega aqui)', 'type' => 'email', 'required' => true, 'validate' => array('email'), 'class' => array('form-row-wide'), 'priority' => 30);
    }
    return $campos;
}, 100000);

// Pagamento aprovado = pedido Concluído na hora. Inscrição não é encomenda:
// não existe "separar e enviar", então ninguém precisa concluir pedido à mão.
add_filter('woocommerce_payment_complete_order_status', function ($status, $order_id, $order) {
    return 'completed';
}, 20, 3);
