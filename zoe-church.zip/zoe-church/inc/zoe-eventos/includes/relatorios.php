<?php
/**
 * Relatórios de inscrições em planilha (.xlsx):
 * - Resumo por evento, por rede/célula, por mês e uma aba por evento com todos os inscritos.
 * - E-mails cadastrados recebem todo dia (WP-Cron) e o painel tem "Baixar agora" e "Enviar agora".
 */
if (!defined('ABSPATH')) {
    exit;
}

const ZOE_REL_HOOK = 'zoe_ev_relatorio_diario';

/* E-mail do próprio site: se houver uma conta SMTP configurada em Relatórios, todos os e-mails do WordPress saem por ela. */
function zoe_smtp_opcoes()
{
    $o = get_option('zoe_ev_smtp', array());
    return wp_parse_args(is_array($o) ? $o : array(), array('host' => '', 'porta' => 465, 'seg' => 'ssl', 'usuario' => '', 'senha' => '', 'nome' => ''));
}
function zoe_smtp_senha($cifrada)
{
    if ($cifrada === '' || !function_exists('openssl_decrypt')) {
        return $cifrada;
    }
    $k = hash('sha256', wp_salt('auth'), true);
    $raw = base64_decode($cifrada, true);
    if ($raw === false || strlen($raw) < 17) {
        return '';
    }
    $p = openssl_decrypt(substr($raw, 16), 'aes-256-cbc', $k, OPENSSL_RAW_DATA, substr($raw, 0, 16));
    return $p === false ? '' : $p;
}
function zoe_smtp_cifrar($plana)
{
    if ($plana === '' || !function_exists('openssl_encrypt')) {
        return $plana;
    }
    $k = hash('sha256', wp_salt('auth'), true);
    $iv = random_bytes(16);
    return base64_encode($iv . openssl_encrypt($plana, 'aes-256-cbc', $k, OPENSSL_RAW_DATA, $iv));
}
add_action('phpmailer_init', function ($m) {
    $o = zoe_smtp_opcoes();
    if (!$o['host'] || !$o['usuario']) {
        return;
    }
    $m->isSMTP();
    $m->Host = $o['host'];
    $m->Port = (int) $o['porta'];
    $m->SMTPAuth = true;
    $m->Username = $o['usuario'];
    $m->Password = zoe_smtp_senha($o['senha']);
    $m->SMTPSecure = $o['seg'] === 'none' ? '' : $o['seg'];
    $m->setFrom($o['usuario'], $o['nome'] ? $o['nome'] : get_bloginfo('name'), false);
});

function zoe_rel_opcoes()
{
    $o = get_option('zoe_ev_relatorios', array());
    return wp_parse_args(is_array($o) ? $o : array(), array(
        'emails' => array(),
        'ativo'  => 1,
        'hora'   => 7,
        'escopo' => 'recentes', // abertos | recentes | todos
    ));
}

/* ====================================================================
 * 1. DADOS
 * ==================================================================== */

/** Rótulos dos campos do plugin antigo (Checkout Field Manager), por meta key. */
function zoe_rel_rotulos_antigos()
{
    $out = array();
    $wooccm = get_option('wooccm_billing');
    if (is_array($wooccm)) {
        foreach ($wooccm as $f) {
            if (!empty($f['name']) && !empty($f['label'])) {
                $out['_billing_' . $f['name']] = trim($f['label']);
            }
        }
    }
    return $out;
}

/** "Não tem", "0", "-" e parecidos não são resposta. */
function zoe_rel_vazio($v)
{
    $v = trim((string) $v);
    return $v === '' || $v === 'Selecione' || preg_match('/^(n[ãa]o(\s+(tem|possui|se aplica))?([\s:]+\S{0,12})?|0+|-+|n\/?a|nenhum[a]?|x+|\.+)$/iu', $v);
}

/**
 * O formulário antigo criou dezenas de perguntas parecidas ao longo dos anos
 * ("Nome Completo", "Nome do aluno", "Whatsapp para contato"...). Aqui cada
 * resposta cai numa coluna só, para a planilha sair limpa. Em evento infantil,
 * o nome que vale é o da criança/teen; em evento adulto, o do inscrito.
 */
function zoe_rel_consolidar($resp, $evento)
{
    if (!is_array($resp) || !$resp) {
        return array();
    }
    $infantil = (bool) preg_match('/kids|konnect|ballet|jud[oô]|teen|celebrate|school/iu', $evento);
    $out = array();
    $pri = array();
    $nomes_orfaos = 0;
    $poe = function ($col, $v, $p) use (&$out, &$pri) {
        if (!isset($pri[$col]) || $p > $pri[$col]) {
            $out[$col] = $v;
            $pri[$col] = $p;
        }
    };
    foreach ($resp as $rot => $v) {
        $v = trim(is_array($v) ? implode(', ', $v) : (string) $v);
        if (zoe_rel_vazio($v)) {
            continue;
        }
        $lc = function_exists('mb_strtolower') ? mb_strtolower($rot) : strtolower($rot);
        if (preg_match('/maior de 16|menos de 18|^pa[ií]s$/u', $lc)) {
            continue;
        }
        if (strpos($rot, '_orfao') === 0) { // resposta sem rótulo: deduz pelo valor
            $dig = preg_replace('/\D/', '', $v);
            if (preg_match('/^(sim|n[ãa]o)$/iu', $v)) {
                continue;
            } elseif (strlen($dig) >= 8 && strlen($dig) <= 14 && strlen($dig) >= mb_strlen($v) / 2) {
                $poe('WhatsApp', $v, 3);
            } elseif (preg_match('/^\d{1,2}(\s*anos?)?$/iu', $v)) {
                $poe('Idade', $v, 4);
            } elseif (preg_match('/\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{2,4}/', $v)) {
                $poe('Data de nascimento', $v, 4);
            } elseif (preg_match('/[\p{L}]{2,}/u', $v)) {
                ++$nomes_orfaos;
                if ($nomes_orfaos === 1) {
                    $poe('Nome completo', $v, $infantil ? 8 : 3);
                } elseif ($nomes_orfaos === 2) {
                    $poe('Responsável', $v, 4);
                } else {
                    $out['Outras respostas'] = (isset($out['Outras respostas']) ? $out['Outras respostas'] . ' · ' : '') . $v;
                }
            }
            continue;
        }
        if (preg_match('/homem/u', $lc)) {
            $out['Nome do Homem'] = $v;
        } elseif (preg_match('/mulher/u', $lc)) {
            $out['Nome da Mulher'] = $v;
        } elseif (preg_match('/respons/u', $lc)) {
            preg_match('/contato|whats|telefone/u', $lc) ? $poe('Contato do responsável', $v, 5) : $poe('Responsável', $v, 5);
        } elseif (preg_match('/aluno|filho/u', $lc)) {
            if (preg_match('/contato|whats/u', $lc)) {
                $poe('WhatsApp', $v, 3);
            } elseif (preg_match('/idade/u', $lc)) {
                $poe('Idade', $v, $infantil ? 9 : 3);
            } elseif (preg_match('/nascimento/u', $lc)) {
                $poe('Data de nascimento', $v, $infantil ? 9 : 3);
            } else {
                $poe('Nome completo', $v, $infantil ? 9 : 2);
            }
        } elseif (preg_match('/nome completo/u', $lc)) {
            $poe('Nome completo', $v, $infantil ? 5 : 9);
        } elseif ($lc === 'nome') {
            $poe('Nome completo', $v, $infantil ? 7 : 4);
        } elseif (preg_match('/idade/u', $lc)) {
            $poe('Idade', $v, preg_match('/teen/u', $lc) && $infantil ? 7 : 5);
        } elseif (preg_match('/nascimento/u', $lc)) {
            $poe('Data de nascimento', $v, preg_match('/adicional/u', $lc) ? 3 : 5);
        } elseif (preg_match('/whats|telefone|celular|contato/u', $lc)) {
            $poe('WhatsApp', $v, 5);
        } elseif (preg_match('/turma/u', $lc)) {
            $poe('Turma', $v, 5);
        } elseif (preg_match('/estado civil/u', $lc)) {
            $poe('Estado Civil', $v, 5);
        } elseif (preg_match('/medicamento|restri|alergia/u', $lc)) {
            $poe('Medicamento / restrição', $v, 5);
        } elseif (preg_match('/convidou/u', $lc)) {
            $poe('Quem convidou', $v, 5);
        } else {
            $out[$rot] = $v;
        }
    }
    return $out;
}

/** Descobre rede/célula, líder e "faz parte?" a partir das respostas de um participante. */
function zoe_rel_classificar($dados)
{
    $rede = '';
    $lider = '';
    $faz = '';
    foreach ($dados as $rot => $val) {
        $r = function_exists('mb_strtolower') ? mb_strtolower($rot) : strtolower($rot);
        $v = is_array($val) ? implode(', ', $val) : trim((string) $val);
        if ($v === '' || $v === 'Selecione' || $v === 'Opção') {
            continue;
        }
        if (preg_match('/faz parte/u', $r)) {
            $faz = $v;
        } elseif (preg_match('/l[ií]der/u', $r)) {
            $lider = $v;
        } elseif (preg_match('/(c[ée]lula|\brede\b)/u', $r) || trim($r) === 'selecione') {
            // (no Encontro Teens antigo a pergunta da rede ficou com o rótulo "Selecione")
            if (preg_match('/^(nenhuma|n[ãa]o tenho|n[ãa]o participo|n[ãa]o)$/iu', $v)) {
                $faz = 'Não';
            } else {
                $rede = $v;
            }
        }
    }
    if ($rede === '') {
        $rede = (strcasecmp($faz, 'Não') === 0 || strcasecmp($faz, 'Nao') === 0) ? 'Não faz parte de célula' : 'Não informado';
    }
    return array($rede, $lider);
}

/**
 * Junta as inscrições.
 * $escopo: abertos | recentes | todos. $produto: ID para um evento só (0 = todos).
 * Retorna array(eventos => [id => [...]], periodo => texto).
 */
/** Aceita 0 (todos), um ID, "123,456" ou array de IDs. */
function zoe_rel_produtos_norm($produto)
{
    $l = is_array($produto) ? $produto : explode(',', (string) $produto);
    return array_values(array_filter(array_map('absint', $l)));
}

function zoe_rel_dados($escopo = 'recentes', $produto = 0)
{
    $produtos = zoe_rel_produtos_norm($produto);
    $args = array(
        'type'   => 'shop_order', // sem reembolsos
        'status' => array('wc-completed', 'wc-processing', 'wc-on-hold'),
        'limit'  => -1,
        'return' => 'ids',
        'orderby' => 'date',
        'order'  => 'ASC',
    );
    $periodo = 'Todas as inscrições';
    if ($escopo === 'recentes') {
        $escopo = 'd90';
    }
    if ($escopo === 'hoje') {
        $meia = new DateTime('today', wp_timezone());
        $args['date_created'] = '>=' . $meia->getTimestamp();
        $periodo = 'Inscrições de hoje (' . wp_date('d/m/Y') . ')';
    } elseif (preg_match('/^d(\d{1,3})$/', $escopo, $mm)) {
        $dias = max(1, (int) $mm[1]);
        $args['date_created'] = '>' . (time() - $dias * DAY_IN_SECONDS);
        $periodo = 'Inscrições dos últimos ' . $dias . ' dias';
    }
    $ids = wc_get_orders($args);
    if ($produtos) {
        // Só os pedidos que têm estes produtos (evita abrir milhares de pedidos).
        global $wpdb;
        $marcas = implode(',', array_fill(0, count($produtos), '%d'));
        $com = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
             JOIN {$wpdb->prefix}woocommerce_order_itemmeta im ON im.order_item_id = oi.order_item_id
             WHERE oi.order_item_type = 'line_item' AND im.meta_key = '_product_id' AND im.meta_value IN ($marcas)", // phpcs:ignore
            $produtos
        ));
        $ids = array_values(array_intersect($ids, array_map('intval', $com)));
    }
    $antigos = zoe_rel_rotulos_antigos();
    $eventos = array();
    $sem = array(); // pedidos sem itens (evento desconhecido)

    foreach ($ids as $oid) {
        $order = wc_get_order($oid);
        if (!$order || !is_a($order, 'WC_Order') || is_a($order, 'WC_Order_Refund')) {
            continue;
        }
        $criado = $order->get_date_created();
        $base = array(
            'Pedido'   => $order->get_order_number(),
            'Data'     => $criado ? $criado->date_i18n('d/m/Y H:i') : '',
            'Status'   => wc_get_order_status_name($order->get_status()),
            'Pagador'  => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'E-mail'   => $order->get_billing_email(),
            'Telefone' => $order->get_billing_phone(),
        );
        $mes = $criado ? $criado->date_i18n('Y-m') : '';
        $pago = in_array($order->get_status(), array('completed', 'processing'), true);

        // Respostas antigas ficam no pedido (valem para todos os itens dele).
        $resp_pedido = null;

        if (!$produtos && !$order->get_items() && $escopo !== 'abertos') {
            $linha = $base + array('Valor' => (float) $order->get_total());
            foreach ($antigos as $mk => $rot) {
                $val = $order->get_meta($mk);
                if (is_array($val)) {
                    $val = implode(', ', $val);
                }
                if ($val !== '' && $val !== null && $val !== 'Selecione') {
                    $linha[$rot] = $val;
                }
            }
            list($linha['Rede / célula'], $linha['Líder']) = zoe_rel_classificar($linha);
            $sem[] = $linha;
            continue;
        }

        foreach ($order->get_items() as $item) {
            $pid = $item->get_product_id();
            if (!$pid || ($produtos && !in_array((int) $pid, $produtos, true))) {
                continue;
            }
            if (!isset($eventos[$pid])) {
                $prod = wc_get_product($pid);
                $eventos[$pid] = array(
                    'id'       => $pid,
                    'nome'     => $prod ? $prod->get_name() : $item->get_name(),
                    'aberto'   => $prod ? ($prod->is_purchasable() && $prod->is_in_stock() && get_post_status($pid) === 'publish') : false,
                    'data'     => get_post_meta($pid, '_zoe_data', true),
                    'pedidos'  => array(),
                    'linhas'   => array(),
                    'colunas'  => array(),
                    'rotmap'   => array(),
                    'valor'    => 0.0,
                    'pagos'    => 0,
                    'aguard'   => 0,
                    'ultima'   => '',
                    'meses'    => array(),
                );
            }
            $ev =& $eventos[$pid];
            $ev['pedidos'][$oid] = true;
            $ev['valor'] += (float) $item->get_total();
            // Variação do produto (ex.: Kids / Konnects) vira a coluna "Turma".
            $turma_item = '';
            if ($item->get_variation_id()) {
                $pv = wc_get_product($item->get_variation_id());
                if ($pv) {
                    $turma_item = wp_strip_all_tags(wc_get_formatted_variation($pv, true, false, false));
                }
            }
            if ($criado) {
                $ev['ultima'] = $criado->date_i18n('d/m/Y');
            }

            $insc = $item->get_meta('_zoe_inscricoes');
            $grupos = array();
            if (is_array($insc) && $insc) {
                foreach ($insc as $d) {
                    $grupos[] = (array) $d;
                }
            } else {
                if ($resp_pedido === null) {
                    $resp_pedido = array();
                    foreach ($antigos as $mk => $rot) {
                        $val = $order->get_meta($mk);
                        if (is_array($val)) {
                            $val = implode(', ', $val);
                        }
                        if ($val !== '' && $val !== null && $val !== 'Selecione') {
                            $resp_pedido[$rot] = $val;
                        }
                    }
                    // Campos que foram apagados do formulário antigo: a resposta ficou no pedido, o rótulo se perdeu.
                    $orfaos = array();
                    foreach ($order->get_meta_data() as $m) {
                        $md = $m->get_data();
                        if (preg_match('/^_billing_wooccm(\d+)$/', $md['key'], $mm) && !isset($antigos[$md['key']]) && is_string($md['value'])) {
                            $orfaos[(int) $mm[1]] = $md['value'];
                        }
                    }
                    ksort($orfaos);
                    $n = 0;
                    foreach ($orfaos as $v) {
                        $resp_pedido['_orfao' . (++$n)] = $v;
                    }
                }
                // O formulário antigo guardava os dados de uma pessoa só por pedido.
                // As outras vagas do mesmo pedido entram como "vaga extra", sem repetir o nome.
                $qtd = max(1, (int) $item->get_quantity());
                $grupos[] = zoe_rel_consolidar($resp_pedido, $ev['nome']);
                for ($k = 1; $k < $qtd; $k++) {
                    $grupos[] = array('_extra' => true);
                }
            }

            $n = count($grupos);
            $rede1 = null;
            foreach ($grupos as $i => $dados) {
                if (!empty($dados['_extra'])) {
                    list($rede, $lider) = $rede1 ? $rede1 : array('Não informado', '');
                    $dados = array('Observação' => 'Vaga extra do mesmo pedido (o formulário antigo só pedia os dados de 1 pessoa)');
                } else {
                    list($rede, $lider) = zoe_rel_classificar($dados);
                    if ($rede1 === null) {
                        $rede1 = array($rede, $lider);
                    }
                }
                $linha = $base + array(
                    'Valor'        => $i === 0 ? (float) $item->get_total() : '',
                    'Inscrição'    => ($i + 1) . ' de ' . $n,
                    'Rede / célula' => $rede,
                    'Líder'        => $lider,
                );
                foreach ($dados as $rot => $val) {
                    if (preg_match('/faz parte|l[ií]der|c[ée]lula|\brede\b|^pa[ií]s$/iu', $rot)) {
                        continue; // já está nas colunas "Rede / célula" e "Líder"
                    }
                    $lc = function_exists('mb_strtolower') ? mb_strtolower($rot) : strtolower($rot);
                    if (!isset($ev['rotmap'][$lc])) {
                        $ev['rotmap'][$lc] = $rot; // "Nome completo" e "Nome Completo" viram uma coluna só
                    }
                    $rot = $ev['rotmap'][$lc];
                    $linha[$rot] = is_array($val) ? implode(', ', $val) : $val;
                    $ev['colunas'][$rot] = true;
                }
                if ($turma_item !== '' && !isset($linha['Turma'])) {
                    if (!isset($ev['rotmap']['turma'])) {
                        $ev['rotmap']['turma'] = 'Turma';
                    }
                    $linha[$ev['rotmap']['turma']] = $turma_item;
                    $ev['colunas'][$ev['rotmap']['turma']] = true;
                }
                $ev['linhas'][] = $linha;
                $pago ? $ev['pagos']++ : $ev['aguard']++;
                if ($mes) {
                    $ev['meses'][$mes] = (isset($ev['meses'][$mes]) ? $ev['meses'][$mes] : 0) + 1;
                }
            }
            unset($ev);
        }
    }

    if ($escopo === 'abertos') {
        $eventos = array_filter($eventos, function ($e) {
            return $e['aberto'];
        });
        $periodo = 'Eventos com inscrição aberta';
    }
    // Evento com formulário Zoe: só as colunas que o formulário dele pergunta
    // (mais o essencial recuperado do formulário antigo). Nada de sobra de outros eventos.
    foreach ($eventos as $pidv => &$evv) {
        $form = function_exists('zoe_ev_get_form') ? zoe_ev_get_form($pidv) : null;
        if (!$form) {
            $cru = get_post_meta($pidv, '_zoe_form', true);
            if (is_array($cru) && $cru) {
                $form = $cru;
            }
        }
        if (!$form || empty($evv['linhas'])) {
            continue;
        }
        $ok = array('nome completo' => 1, 'whatsapp' => 1, 'observação' => 1, 'observacao' => 1, 'e-mail' => 1);
        if (function_exists('zoe_ev_campos_do_form') && function_exists('zoe_ev_campos_para_salvar')) {
            foreach (zoe_ev_campos_para_salvar(zoe_ev_campos_do_form($form)) as $def) {
                if (!empty($def['label'])) {
                    $ok[mb_strtolower(trim($def['label']))] = 1;
                }
            }
        }
        if (preg_match('/kids|konnect|ballet|jud[oô]|teen|celebrate|school|music/iu', $evv['nome'])) {
            foreach (array('responsável', 'contato do responsável', 'idade', 'data de nascimento', 'turma', 'medicamento / restrição') as $c) {
                $ok[$c] = 1;
            }
        }
        foreach (array_keys($evv['colunas']) as $c) {
            if (empty($ok[mb_strtolower(trim($c))])) {
                unset($evv['colunas'][$c]);
            }
        }
    }
    unset($evv);

    // Colunas extras em ordem útil: nomes primeiro, contato depois, Observação no fim.
    foreach ($eventos as &$evv) {
        $peso = function ($c) {
            $lc = function_exists('mb_strtolower') ? mb_strtolower($c) : strtolower($c);
            if (strpos($lc, 'observa') === 0) {
                return 9;
            }
            if (preg_match('/nome/u', $lc)) {
                return preg_match('/respons|aluno|homem|mulher/u', $lc) ? 1 : 0;
            }
            if (preg_match('/idade|nascimento|turma|estado civil/u', $lc)) {
                return 2;
            }
            if (preg_match('/whats|telefone|contato|e-?mail/u', $lc)) {
                return 3;
            }
            return 5;
        };
        $cols = array_keys($evv['colunas']);
        usort($cols, function ($a, $b) use ($peso, $cols) {
            $d = $peso($a) - $peso($b);
            return $d !== 0 ? $d : array_search($a, $cols) - array_search($b, $cols);
        });
        $evv['colunas'] = array_fill_keys($cols, true);
        unset($evv['rotmap']);
    }
    unset($evv);

    // Mais recentes primeiro.
    uasort($eventos, function ($a, $b) {
        $da = $a['linhas'] ? end($a['linhas'])['Data'] : '';
        $db = $b['linhas'] ? end($b['linhas'])['Data'] : '';
        $ta = $da ? DateTime::createFromFormat('d/m/Y H:i', $da) : false;
        $tb = $db ? DateTime::createFromFormat('d/m/Y H:i', $db) : false;
        return ($tb ? $tb->getTimestamp() : 0) - ($ta ? $ta->getTimestamp() : 0);
    });
    return array('eventos' => $eventos, 'periodo' => $periodo, 'sem' => $sem);
}

/* ====================================================================
 * 2. PLANILHAS (abas)
 * ==================================================================== */

function zoe_rel_abas($dados)
{
    $eventos = $dados['eventos'];
    $abas = array();
    $gerado = date_i18n('d/m/Y H:i');

    // --- Resumo
    $rows = array(
        array('Relatório de inscrições — ' . get_bloginfo('name'), '_s' => 3),
        array('Gerado em ' . $gerado . ' · ' . $dados['periodo']),
        array(),
        array('Evento', 'Situação', 'Inscrições', 'Pagas', 'Aguardando pagamento', 'Pedidos', 'Valor (R$)', 'Última inscrição'),
    );
    $tot = array(0, 0, 0, 0, 0.0);
    foreach ($eventos as $e) {
        $q = count($e['linhas']);
        $rows[] = array($e['nome'], $e['aberto'] ? 'Inscrições abertas' : 'Encerrado', $q, $e['pagos'], $e['aguard'], count($e['pedidos']), round($e['valor'], 2), $e['ultima']);
        $tot[0] += $q;
        $tot[1] += $e['pagos'];
        $tot[2] += $e['aguard'];
        $tot[3] += count($e['pedidos']);
        $tot[4] += $e['valor'];
    }
    $rows[] = array('TOTAL', '', $tot[0], $tot[1], $tot[2], $tot[3], round($tot[4], 2), '');
    if (!empty($dados['sem'])) {
        $rows[] = array();
        $rows[] = array(count($dados['sem']) . ' pedido(s) pagos sem evento identificado no banco: veja a aba "Sem evento".');
    }
    $abas[] = array('nome' => 'Resumo', 'linhas' => $rows, 'cab' => 4, 'total' => true, 'larguras' => array(46, 18, 12, 10, 14, 10, 14, 16));

    // --- Por rede
    $geral = array();
    $porEv = array();
    foreach ($eventos as $e) {
        foreach ($e['linhas'] as $l) {
            $r = $l['Rede / célula'];
            $geral[$r] = (isset($geral[$r]) ? $geral[$r] : 0) + 1;
            $porEv[$e['nome']][$r] = (isset($porEv[$e['nome']][$r]) ? $porEv[$e['nome']][$r] : 0) + 1;
        }
    }
    arsort($geral);
    $soma = array_sum($geral);
    $rows = array(array('Total por rede / célula', '_s' => 3), array(), array('Rede / célula', 'Inscrições', '% do total'));
    foreach ($geral as $r => $q) {
        $rows[] = array($r, $q, $soma ? round($q * 100 / $soma, 1) : 0);
    }
    $rows[] = array('TOTAL', $soma, $soma ? 100 : 0);
    $rows[] = array();
    $rows[] = array('Por evento', '_s' => 3);
    $rows[] = array('Evento', 'Rede / célula', 'Inscrições', '_s' => 1);
    foreach ($porEv as $nome => $redes) {
        arsort($redes);
        foreach ($redes as $r => $q) {
            $rows[] = array($nome, $r, $q);
        }
        $rows[] = array($nome . ' — total', '', array_sum($redes));
    }
    $abas[] = array('nome' => 'Por rede', 'linhas' => $rows, 'cab' => 3, 'larguras' => array(46, 30, 12));

    // --- Por mês
    $meses = array();
    foreach ($eventos as $e) {
        foreach ($e['meses'] as $m => $q) {
            $meses[$m] = (isset($meses[$m]) ? $meses[$m] : 0) + $q;
        }
    }
    krsort($meses);
    $rows = array(array('Mês', 'Inscrições'));
    foreach ($meses as $m => $q) {
        list($y, $mm) = explode('-', $m);
        $rows[] = array($mm . '/' . $y, $q);
    }
    $abas[] = array('nome' => 'Por mês', 'linhas' => $rows, 'cab' => 1, 'larguras' => array(14, 12));

    // --- Uma aba por evento, no formato combinado com a equipe.
    //     Adultos: N, Nome, Rede, Líder, Contato, E-mail, Valor, Inscrição, Pedido, Data, Status
    //     Infantil (kids/konnects/teens...): N, Nome, Idade, Turma, Nome do responsável,
    //     WhatsApp do responsável, Rede, Líder, Valor, Inscrição, Pedido, Status
    $ja = array('Nome completo', 'Pagador', 'WhatsApp', 'Telefone', 'E-mail', 'Rede / célula', 'Líder', 'Valor', 'Inscrição', 'Pedido', 'Data', 'Status', 'Observação');
    foreach ($eventos as $e) {
        $inf = (bool) preg_match('/kids|konnect|ballet|jud[oô]|teen|celebrate|school/iu', $e['nome']);
        $ja2 = $inf ? array_merge($ja, array('Idade', 'Turma', 'Nome do responsável', 'Responsável', 'WhatsApp do responsável', 'Contato do responsável')) : $ja;
        $extras = array_values(array_diff(array_keys($e['colunas']), $ja2));
        if ($inf) {
            $cab = array_merge(array('N', 'Nome', 'Idade', 'Turma', 'Nome do responsável', 'WhatsApp do responsável', 'Rede', 'Líder', 'Valor', 'Inscrição', 'Pedido', 'Status', 'Data', 'E-mail'), $extras, array('Observação'));
        } else {
            $cab = array_merge(array('N', 'Nome', 'Rede', 'Líder', 'Contato', 'E-mail', 'Valor', 'Inscrição', 'Pedido', 'Data', 'Status'), $extras, array('Observação'));
        }
        $rows = array($cab);
        $n = 0;
        foreach ($e['linhas'] as $l) {
            $v = function () use ($l) {
                foreach (func_get_args() as $c) {
                    if (isset($l[$c]) && $l[$c] !== '') {
                        return $l[$c];
                    }
                }
                return '';
            };
            if ($inf) {
                $row = array(
                    ++$n,
                    $v('Nome completo', 'Pagador'),
                    $v('Idade'),
                    $v('Turma'),
                    $v('Nome do responsável', 'Responsável', 'Pagador'),
                    $v('WhatsApp do responsável', 'Contato do responsável', 'WhatsApp', 'Telefone'),
                    $v('Rede / célula'),
                    $v('Líder'),
                    $v('Valor'),
                    $v('Inscrição'),
                    $v('Pedido'),
                    $v('Status'),
                    $v('Data'),
                    $v('E-mail'),
                );
            } else {
                $row = array(
                    ++$n,
                    $v('Nome completo', 'Pagador'),
                    $v('Rede / célula'),
                    $v('Líder'),
                    $v('WhatsApp', 'Telefone'),
                    $v('E-mail'),
                    $v('Valor'),
                    $v('Inscrição'),
                    $v('Pedido'),
                    $v('Data'),
                    $v('Status'),
                );
            }
            foreach ($extras as $c) {
                $row[] = $v($c);
            }
            $row[] = $v('Observação');
            $rows[] = $row;
        }
        $larg = $inf ? array(5, 34, 7, 12, 30, 18, 16, 20, 9, 10, 9, 13, 16, 28) : array(5, 38, 16, 20, 16, 30, 9, 10, 9, 16, 13);
        foreach ($extras as $x) {
            $larg[] = min(40, max(14, (int) (strlen($x) * 0.9)));
        }
        $larg[] = 46;
        $abas[] = array('nome' => $e['nome'], 'linhas' => $rows, 'cab' => 1, 'larguras' => $larg);
    }
    // --- Pedidos sem evento identificado
    if (!empty($dados['sem'])) {
        $fixas2 = array('Pedido', 'Data', 'Status', 'Pagador', 'E-mail', 'Telefone', 'Valor', 'Rede / célula', 'Líder');
        $extras = array();
        foreach ($dados['sem'] as $l) {
            foreach (array_keys($l) as $k) {
                if (!in_array($k, $fixas2, true)) {
                    $extras[$k] = true;
                }
            }
        }
        $cab = array_merge($fixas2, array_keys($extras));
        $rows = array($cab);
        foreach ($dados['sem'] as $l) {
            $row = array();
            foreach ($cab as $c) {
                $row[] = isset($l[$c]) ? $l[$c] : '';
            }
            $rows[] = $row;
        }
        $abas[] = array('nome' => 'Sem evento', 'linhas' => $rows, 'cab' => 1, 'larguras' => array(9, 16, 13, 26, 28, 16, 10, 22, 20));
    }
    return $abas;
}

/* ====================================================================
 * 3. XLSX (sem bibliotecas: XML + ZipArchive)
 * ==================================================================== */

function zoe_rel_col($i)
{
    $s = '';
    for ($i++; $i > 0; $i = (int) (($i - 1) / 26)) {
        $s = chr(65 + (($i - 1) % 26)) . $s;
    }
    return $s;
}

function zoe_rel_x($v)
{
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $v);
    return htmlspecialchars($v, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function zoe_rel_nome_aba($nome, &$usados)
{
    $n = trim(preg_replace('/[\[\]\:\*\?\/\\\\]/', ' ', $nome));
    $n = function_exists('mb_substr') ? mb_substr($n, 0, 31) : substr($n, 0, 31);
    $base = $n === '' ? 'Evento' : $n;
    $k = 2;
    while (in_array(strtolower($n), $usados, true)) {
        $suf = ' (' . $k++ . ')';
        $n = (function_exists('mb_substr') ? mb_substr($base, 0, 31 - strlen($suf)) : substr($base, 0, 31 - strlen($suf))) . $suf;
    }
    $usados[] = strtolower($n);
    return $n;
}

/** Gera o .xlsx e devolve o caminho do arquivo (ou false). */
function zoe_rel_xlsx($abas, $arquivo)
{
    if (!class_exists('ZipArchive')) {
        return false;
    }
    $zip = new ZipArchive();
    if ($zip->open($arquivo, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return false;
    }
    $usados = array();
    $sheets = '';
    $rels = '';
    $ctypes = '';
    foreach ($abas as $i => $aba) {
        $n = $i + 1;
        $nome = zoe_rel_nome_aba($aba['nome'], $usados);
        $sheets .= '<sheet name="' . zoe_rel_x($nome) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
        $rels .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
        $ctypes .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';

        $cabLinha = isset($aba['cab']) ? (int) $aba['cab'] : 1;
        $linhas = $aba['linhas'];
        $maxCol = 1;
        $xml = '';
        foreach ($linhas as $r => $linha) {
            $rn = $r + 1;
            $forcado = isset($linha['_s']) ? (int) $linha['_s'] : null;
            unset($linha['_s']);
            $linha = array_values($linha);
            $maxCol = max($maxCol, count($linha));
            $total = !empty($linha) && is_string($linha[0]) && preg_match('/^TOTAL$| — total$/u', $linha[0]);
            $estilo = $forcado !== null ? $forcado : ($rn === $cabLinha ? 1 : ($total ? 2 : 0));
            $xml .= '<row r="' . $rn . '">';
            foreach ($linha as $c => $v) {
                $ref = zoe_rel_col($c) . $rn;
                $s = $estilo;
                if (is_int($v) || is_float($v)) {
                    $din = is_float($v);
                    $sn = $s === 2 ? ($din ? 6 : 2) : ($s === 0 ? ($din ? 5 : 4) : $s);
                    $xml .= '<c r="' . $ref . '" s="' . $sn . '"><v>' . $v . '</v></c>';
                } elseif ($v !== '' && $v !== null) {
                    $xml .= '<c r="' . $ref . '" t="inlineStr" s="' . $s . '"><is><t xml:space="preserve">' . zoe_rel_x($v) . '</t></is></c>';
                }
            }
            $xml .= '</row>';
        }
        $cols = '';
        if (!empty($aba['larguras'])) {
            $cols = '<cols>';
            foreach ($aba['larguras'] as $c => $w) {
                $cols .= '<col min="' . ($c + 1) . '" max="' . ($c + 1) . '" width="' . (float) $w . '" customWidth="1"/>';
            }
            $cols .= '</cols>';
        }
        $pane = '<sheetViews><sheetView workbookViewId="0"' . ($i === 0 ? ' tabSelected="1"' : '') . '><pane ySplit="' . $cabLinha . '" topLeftCell="A' . ($cabLinha + 1) . '" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>';
        $filtro = ($cabLinha === 1 && count($linhas) > 1) ? '<autoFilter ref="A1:' . zoe_rel_col($maxCol - 1) . count($linhas) . '"/>' : '';
        $zip->addFromString('xl/worksheets/sheet' . $n . '.xml',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' .
            $pane . $cols . '<sheetData>' . $xml . '</sheetData>' . $filtro . '</worksheet>');
    }
    $zip->addFromString('[Content_Types].xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' .
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' .
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' .
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' . $ctypes . '</Types>');
    $zip->addFromString('_rels/.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $sheets . '</sheets></workbook>');
    $zip->addFromString('xl/_rels/workbook.xml.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $rels .
        '<Relationship Id="rId' . (count($abas) + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
    // Estilos: 0 normal, 1 cabeçalho (negrito, fundo escuro, letra branca), 2 total (negrito, fundo claro), 3 título (negrito grande), 4 número
    $zip->addFromString('xl/styles.xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' .

        '<fonts count="4"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><name val="Calibri"/></font></fonts>' .
        '<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF141216"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEFE8F8"/><bgColor indexed="64"/></patternFill></fill></fills>' .
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' .
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' .
        '<cellXfs count="7"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' .
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>' .
        '<xf numFmtId="3" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"/>' .
        '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>' .
        '<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>' .
        '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>' .
        '<xf numFmtId="4" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"/></cellXfs>' .
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
    $zip->close();
    return $arquivo;
}

/* ====================================================================
 * 4. GERAR / ENVIAR
 * ==================================================================== */

function zoe_rel_pasta()
{
    $up = wp_upload_dir();
    $dir = trailingslashit($up['basedir']) . 'zoe-relatorios';
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
        @file_put_contents($dir . '/index.php', '<?php // silêncio');
        @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
    }
    return $dir;
}

/** Gera a planilha. Retorna array(arquivo, dados) ou false. */
function zoe_rel_gerar($escopo = 'recentes', $produto = 0)
{
    if (function_exists('set_time_limit')) {
        @set_time_limit(300);
    }
    $dados = zoe_rel_dados($escopo, $produto);
    $pp = zoe_rel_produtos_norm($produto);
    $rotulo = '';
    if (count($pp) === 1) {
        $rotulo = sanitize_title(get_the_title($pp[0])) . '-';
    } elseif (count($pp) > 1) {
        $rotulo = count($pp) . '-eventos-';
    }
    $nome = 'relatorio-inscricoes-' . $rotulo . date_i18n('Y-m-d-His') . '.xlsx';
    $arq = zoe_rel_xlsx(zoe_rel_abas($dados), zoe_rel_pasta() . '/' . $nome);
    return $arq ? array($arq, $dados) : false;
}

/** Corpo do e-mail com um resumo. */
function zoe_rel_corpo($dados)
{
    $tot = 0;
    $lin = '';
    $i = 0;
    foreach ($dados['eventos'] as $e) {
        $q = count($e['linhas']);
        $tot += $q;
        if ($i++ < 15) {
            $lin .= '<tr><td style="padding:6px 10px;border-bottom:1px solid #eee">' . esc_html($e['nome']) . '</td><td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:right"><b>' . $q . '</b></td></tr>';
        }
    }
    return '<div style="font-family:Arial,sans-serif;color:#141216;max-width:620px">' .
        '<h2 style="margin:0 0 6px">Relatório de inscrições</h2>' .
        '<p style="color:#6f6a74;margin:0 0 18px">' . esc_html(get_bloginfo('name')) . ' · ' . esc_html(date_i18n('d/m/Y H:i')) . ' · ' . esc_html($dados['periodo']) . '</p>' .
        '<p style="font-size:15px">Total: <b>' . $tot . ' inscrições</b> em <b>' . count($dados['eventos']) . ' evento(s)</b>.</p>' .
        ($lin ? '<table style="border-collapse:collapse;width:100%;font-size:14px">' . $lin . '</table>' : '<p>Nenhuma inscrição no período.</p>') .
        '<p style="margin-top:18px">A planilha completa está em anexo (abas: Resumo, Por rede, Por mês e uma aba por evento).</p>' .
        '<p style="color:#6f6a74;font-size:12px">Para parar de receber, peça para retirarem seu e-mail em Zoe Eventos → Relatórios.</p></div>';
}

/** Envia para a lista. Retorna número de e-mails aceitos pelo servidor. */
function zoe_rel_enviar($emails = null, $escopo = null)
{
    $op = zoe_rel_opcoes();
    $emails = $emails === null ? $op['emails'] : (array) $emails;
    $emails = array_values(array_filter(array_map('sanitize_email', $emails), 'is_email'));
    if (!$emails) {
        return 0;
    }
    $g = zoe_rel_gerar($escopo ? $escopo : $op['escopo']);
    if (!$g) {
        return 0;
    }
    list($arq, $dados) = $g;
    $assunto = 'Relatório de inscrições — ' . date_i18n('d/m/Y');
    $hdr = array('Content-Type: text/html; charset=UTF-8');
    $ok = 0;
    add_action('wp_mail_failed', 'zoe_rel_guardar_erro');
    foreach ($emails as $em) {
        if (wp_mail($em, $assunto, zoe_rel_corpo($dados), $hdr, array($arq))) {
            $ok++;
        }
    }
    remove_action('wp_mail_failed', 'zoe_rel_guardar_erro');
    @unlink($arq);
    update_option('zoe_ev_rel_ultimo', array('quando' => current_time('mysql'), 'ok' => $ok, 'total' => count($emails)), false);
    return $ok;
}

function zoe_rel_guardar_erro($e)
{
    update_option('zoe_ev_rel_erro', $e->get_error_message(), false);
}

/* ====================================================================
 * 5. AGENDAMENTO DIÁRIO (WP-Cron)
 * ==================================================================== */

function zoe_rel_agendar()
{
    $op = zoe_rel_opcoes();
    wp_clear_scheduled_hook(ZOE_REL_HOOK);
    if (!$op['ativo'] || !$op['emails']) {
        return;
    }
    $tz = wp_timezone();
    $prox = new DateTime('today ' . sprintf('%02d:00', (int) $op['hora']), $tz);
    if ($prox->getTimestamp() <= time()) {
        $prox->modify('+1 day');
    }
    wp_schedule_event($prox->getTimestamp(), 'daily', ZOE_REL_HOOK);
}
add_action(ZOE_REL_HOOK, function () {
    zoe_rel_enviar();
});
add_action('init', function () {
    $op = zoe_rel_opcoes();
    if ($op['ativo'] && $op['emails'] && !wp_next_scheduled(ZOE_REL_HOOK)) {
        zoe_rel_agendar();
    }
});

/* ====================================================================
 * 6. PÁGINA "RELATÓRIOS"
 * ==================================================================== */

add_action('admin_menu', function () {
    add_submenu_page('zoe-eventos', 'Relatórios', 'Relatórios', defined('ZOE_EV_CAP') ? ZOE_EV_CAP : 'edit_products', 'zoe-relatorios', 'zoe_rel_pagina');
}, 25);

function zoe_rel_pagina()
{
    $op = zoe_rel_opcoes();
    $ult = get_option('zoe_ev_rel_ultimo');
    $prox = wp_next_scheduled(ZOE_REL_HOOK);
    $url = admin_url('admin-post.php');
    $msgs = array(
        'salvo'   => 'Configurações salvas.',
        'enviado' => isset($_GET['n']) ? sprintf('Relatório enviado para %d e-mail(s).', absint($_GET['n'])) : '', // phpcs:ignore
        'falhou'  => 'O servidor não conseguiu enviar o e-mail (' . (string) get_option('zoe_ev_rel_erro', 'sem detalhe') . '). Configure "De onde o e-mail sai" abaixo.',
        'semzip'  => 'O servidor não tem a extensão ZipArchive do PHP; peça para a hospedagem ativar.',
        'vazio'   => 'Cadastre pelo menos um e-mail.',
        'testeok' => 'E-mail de teste enviado para ' . wp_get_current_user()->user_email . '. Confira a caixa de entrada (e o spam).',
        'testefalhou' => 'O teste não saiu: ' . (string) get_transient('zoe_smtp_teste_' . get_current_user_id()),
    );
    $m = isset($_GET['zoe_rel']) ? sanitize_key($_GET['zoe_rel']) : ''; // phpcs:ignore
    echo '<div class="wrap zoe-wrap"><h1>Relatórios de inscrições</h1>';
    if ($m && !empty($msgs[$m])) {
        echo '<div class="notice ' . (in_array($m, array('falhou', 'semzip', 'vazio', 'testefalhou'), true) ? 'notice-error' : 'notice-success') . ' is-dismissible"><p>' . esc_html($msgs[$m]) . '</p></div>';
    }

    // Gerar agora
    echo '<div class="zoe-card"><h2>Gerar agora</h2><p class="description">Planilha com as abas Resumo, Por rede, Por mês e uma aba por evento com todos os inscritos.</p>';
    echo '<form method="post" action="' . esc_url($url) . '" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">';
    wp_nonce_field('zoe_rel_agora');
    echo '<input type="hidden" name="action" value="zoe_rel_agora">';
    echo '<select name="produto"><option value="0">Todos os eventos</option>';
    foreach (get_posts(array('post_type' => 'product', 'post_status' => array('publish', 'draft', 'private'), 'posts_per_page' => 300, 'orderby' => 'date', 'order' => 'DESC')) as $p) {
        echo '<option value="' . (int) $p->ID . '">' . esc_html($p->post_title) . '</option>';
    }
    echo '</select><select name="escopo"><option value="todos">Todas as inscrições</option><option value="recentes">Últimos 90 dias</option><option value="abertos">Só eventos abertos</option></select>';
    echo '<button class="button button-primary" name="modo" value="baixar">Baixar agora</button>';
    if ($op['emails']) {
        echo '<button class="button" name="modo" value="enviar">Enviar agora para a lista</button>';
    }
    echo '</form></div>';

    // Lista de e-mails
    echo '<form method="post" action="' . esc_url($url) . '">';
    wp_nonce_field('zoe_rel_salvar');
    echo '<input type="hidden" name="action" value="zoe_rel_salvar">';
    echo '<div class="zoe-card"><h2>Quem recebe por e-mail</h2><p class="description">Um e-mail por linha. Cada um recebe a planilha automaticamente.</p>';
    echo '<textarea name="emails" rows="5" class="large-text" placeholder="nome@exemplo.com">' . esc_textarea(implode("\n", $op['emails'])) . '</textarea>';
    echo '<p><label><input type="checkbox" name="ativo" value="1"' . checked($op['ativo'], 1, false) . '> Enviar todo dia às </label>';
    echo '<select name="hora">';
    for ($h = 0; $h < 24; $h++) {
        echo '<option value="' . $h . '"' . selected((int) $op['hora'], $h, false) . '>' . sprintf('%02d:00', $h) . '</option>';
    }
    echo '</select> com <select name="escopo">';
    foreach (array('recentes' => 'inscrições dos últimos 90 dias', 'abertos' => 'eventos com inscrição aberta', 'todos' => 'todas as inscrições') as $k => $t) {
        echo '<option value="' . esc_attr($k) . '"' . selected($op['escopo'], $k, false) . '>' . esc_html($t) . '</option>';
    }
    echo '</select></p>';
    echo '<p class="description">' . ($prox ? 'Próximo envio: <b>' . esc_html(wp_date('d/m/Y H:i', $prox)) . '</b>. ' : '') . ($ult ? 'Último envio: ' . esc_html(mysql2date('d/m/Y H:i', $ult['quando'])) . ' (' . (int) $ult['ok'] . ' de ' . (int) $ult['total'] . ' aceitos).' : '') . '</p>';
    submit_button('Salvar', 'primary', 'submit', false);
    echo '</div></form>';

    $sm = zoe_smtp_opcoes();
    echo '<form method="post" action="' . esc_url($url) . '">';
    wp_nonce_field('zoe_smtp_salvar');
    echo '<input type="hidden" name="action" value="zoe_smtp_salvar">';
    echo '<div class="zoe-card"><h2>De onde o e-mail sai</h2><p class="description">Sem configurar nada, o site envia pelo servidor da hospedagem. Para chegar na caixa de entrada (e não no spam), use uma conta de e-mail do próprio domínio criada no cPanel (ex.: <b>relatorios@zoechurchfrg.com.br</b>). No cPanel, em <i>Contas de e-mail → Connect Devices</i>, aparecem o servidor e a porta.</p>';
    echo '<table class="form-table"><tr><th>Servidor SMTP</th><td><input type="text" name="host" value="' . esc_attr($sm['host']) . '" placeholder="mail.zoechurchfrg.com.br" class="regular-text"></td></tr>';
    echo '<tr><th>Porta / segurança</th><td><input type="number" name="porta" value="' . (int) $sm['porta'] . '" style="width:90px"> <select name="seg">';
    foreach (array('ssl' => 'SSL (465)', 'tls' => 'TLS (587)', 'none' => 'Nenhuma') as $k => $t) {
        echo '<option value="' . esc_attr($k) . '"' . selected($sm['seg'], $k, false) . '>' . esc_html($t) . '</option>';
    }
    echo '</select></td></tr>';
    echo '<tr><th>E-mail (usuário)</th><td><input type="email" name="usuario" value="' . esc_attr($sm['usuario']) . '" class="regular-text" autocomplete="off"></td></tr>';
    echo '<tr><th>Senha do e-mail</th><td><input type="password" name="senha" value="" class="regular-text" autocomplete="new-password" placeholder="' . ($sm['senha'] ? '•••••••• (guardada; deixe vazio para manter)' : '') . '"></td></tr>';
    echo '<tr><th>Nome do remetente</th><td><input type="text" name="nome" value="' . esc_attr($sm['nome']) . '" placeholder="' . esc_attr(get_bloginfo('name')) . '" class="regular-text"></td></tr></table>';
    echo '<p>';
    submit_button('Salvar envio', 'secondary', 'submit', false);
    echo ' <button class="button" name="teste" value="1">Salvar e mandar e-mail de teste para mim</button>';
    if ($sm['host']) {
        echo ' <button class="button-link-delete" name="limpar" value="1" style="margin-left:10px">Voltar ao envio padrão</button>';
    }
    echo '</p><p class="description">A senha fica guardada criptografada no banco do site. O envio diário roda quando o site recebe visitas; para horário exato, crie no cPanel uma tarefa Cron a cada hora com: <code>wget -q -O - ' . esc_html(site_url('wp-cron.php')) . ' &gt;/dev/null</code></p></div></form>';
    echo '</div>';
}

add_action('admin_post_zoe_rel_salvar', function () {
    if (!current_user_can(defined('ZOE_EV_CAP') ? ZOE_EV_CAP : 'edit_products') || !check_admin_referer('zoe_rel_salvar')) {
        wp_die('Sem permissão.');
    }
    $emails = preg_split('/[\s,;]+/', (string) wp_unslash(isset($_POST['emails']) ? $_POST['emails'] : '')); // phpcs:ignore
    $emails = array_values(array_unique(array_filter(array_map('sanitize_email', $emails), 'is_email')));
    $escopo = isset($_POST['escopo']) ? sanitize_key($_POST['escopo']) : 'recentes';
    update_option('zoe_ev_relatorios', array(
        'emails' => $emails,
        'ativo'  => empty($_POST['ativo']) ? 0 : 1,
        'hora'   => min(23, max(0, absint(isset($_POST['hora']) ? $_POST['hora'] : 7))),
        'escopo' => in_array($escopo, array('recentes', 'abertos', 'todos'), true) ? $escopo : 'recentes',
    ));
    zoe_rel_agendar();
    wp_safe_redirect(admin_url('admin.php?page=zoe-relatorios&zoe_rel=salvo'));
    exit;
});

add_action('admin_post_zoe_smtp_salvar', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('zoe_smtp_salvar')) {
        wp_die('Só o administrador do site pode mudar o envio de e-mails.');
    }
    $volta = admin_url('admin.php?page=zoe-relatorios');
    if (!empty($_POST['limpar'])) {
        delete_option('zoe_ev_smtp');
        wp_safe_redirect($volta . '&zoe_rel=salvo');
        exit;
    }
    $ant = zoe_smtp_opcoes();
    $senha = isset($_POST['senha']) ? (string) wp_unslash($_POST['senha']) : ''; // phpcs:ignore
    $seg = isset($_POST['seg']) ? sanitize_key($_POST['seg']) : 'ssl';
    update_option('zoe_ev_smtp', array(
        'host'    => sanitize_text_field(wp_unslash(isset($_POST['host']) ? $_POST['host'] : '')),
        'porta'   => absint(isset($_POST['porta']) ? $_POST['porta'] : 465),
        'seg'     => in_array($seg, array('ssl', 'tls', 'none'), true) ? $seg : 'ssl',
        'usuario' => sanitize_email(wp_unslash(isset($_POST['usuario']) ? $_POST['usuario'] : '')),
        'senha'   => $senha !== '' ? zoe_smtp_cifrar($senha) : $ant['senha'],
        'nome'    => sanitize_text_field(wp_unslash(isset($_POST['nome']) ? $_POST['nome'] : '')),
    ), false);
    if (!empty($_POST['teste'])) {
        $eu = wp_get_current_user();
        $erro = '';
        $pega = function ($e) use (&$erro) {
            $erro = $e->get_error_message();
        };
        add_action('wp_mail_failed', $pega);
        $ok = wp_mail($eu->user_email, 'Teste de envio — ' . get_bloginfo('name'), 'Se você recebeu este e-mail, o site já consegue enviar os relatórios.');
        remove_action('wp_mail_failed', $pega);
        set_transient('zoe_smtp_teste_' . $eu->ID, $ok ? 'ok' : $erro, 120);
        wp_safe_redirect($volta . '&zoe_rel=' . ($ok ? 'testeok' : 'testefalhou'));
        exit;
    }
    wp_safe_redirect($volta . '&zoe_rel=salvo');
    exit;
});

add_action('admin_post_zoe_rel_agora', function () {
    if (!current_user_can(defined('ZOE_EV_CAP') ? ZOE_EV_CAP : 'edit_products') || !check_admin_referer('zoe_rel_agora')) {
        wp_die('Sem permissão.');
    }
    $escopo = isset($_POST['escopo']) ? sanitize_key($_POST['escopo']) : 'todos';
    $produto = isset($_POST['produto']) ? absint($_POST['produto']) : 0;
    if (!empty($_POST['produtos'])) {
        $lista = zoe_rel_produtos_norm(sanitize_text_field(wp_unslash($_POST['produtos'])));
        if ($lista) {
            $produto = $lista;
        }
    }
    $volta = admin_url('admin.php?page=zoe-relatorios');
    if (!class_exists('ZipArchive')) {
        wp_safe_redirect($volta . '&zoe_rel=semzip');
        exit;
    }
    if (isset($_POST['modo']) && $_POST['modo'] === 'enviar') {
        $op = zoe_rel_opcoes();
        if (!$op['emails']) {
            wp_safe_redirect($volta . '&zoe_rel=vazio');
            exit;
        }
        $n = zoe_rel_enviar(null, $escopo);
        wp_safe_redirect($volta . ($n ? '&zoe_rel=enviado&n=' . $n : '&zoe_rel=falhou'));
        exit;
    }
    $g = zoe_rel_gerar($escopo, $produto);
    if (!$g) {
        wp_safe_redirect($volta . '&zoe_rel=semzip');
        exit;
    }
    nocache_headers();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . basename($g[0]) . '"');
    header('Content-Length: ' . filesize($g[0]));
    readfile($g[0]);
    @unlink($g[0]);
    exit;
});
