<?php
/**
 * Zoe Eventos embutido no tema: se o plugin "Zoe Eventos" não estiver instalado,
 * o tema carrega a mesma funcionalidade sozinho (um arquivo só para instalar).
 */
if (!defined('ABSPATH') || defined('ZOE_EV_VERSION') || !class_exists('WooCommerce')) {
    return;
}
define('ZOE_EV_VERSION', '1.0.0');
define('ZOE_EV_DIR', get_template_directory() . '/inc/zoe-eventos/');
define('ZOE_EV_URL', get_template_directory_uri() . '/inc/zoe-eventos/');

if (!function_exists('zoe_ev_setting')) {
    function zoe_ev_setting($key, $default = null)
    {
        $s = get_option('zoe_ev_settings', array());
        return isset($s[$key]) ? $s[$key] : $default;
    }
}
if (!function_exists('zoe_ev_celulas')) {
    /** Lista de células cadastradas (só as ativas, a menos que $todas). */
    function zoe_ev_celulas($todas = false)
    {
        $raw = (string) get_option('zoe_ev_celulas', '');
        $list = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw))));
        if ($todas) {
            return $list;
        }
        $off = (array) get_option('zoe_ev_celulas_inativas', array());
        return array_values(array_diff($list, $off));
    }
}

require_once ZOE_EV_DIR . 'includes/fields.php';
require_once ZOE_EV_DIR . 'includes/checkout.php';
require_once ZOE_EV_DIR . 'includes/relatorios.php';
if (is_admin()) {
    require_once ZOE_EV_DIR . 'includes/admin-events.php';
    require_once ZOE_EV_DIR . 'includes/admin-images.php';
    require_once ZOE_EV_DIR . 'includes/admin-settings.php';
}
