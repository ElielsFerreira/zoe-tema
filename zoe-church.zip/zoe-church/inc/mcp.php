<?php

/**
 * Conector IA (servidor MCP) — permite que assistentes de IA (Claude, ChatGPT)
 * administrem o site por conversa, mediante um link secreto revogável por pessoa.
 *
 * O que o conector PODE fazer: eventos, inscrições, pendências e baixas,
 * lembretes, confirmações, relatórios, textos do site, células, páginas e imagens.
 *
 * O que o conector NUNCA faz (por construção — as ferramentas não existem):
 *  - configurações de pagamento, Mercado Pago, chaves e credenciais;
 *  - estornos e cancelamentos de cobranças;
 *  - alterar os dados de contribuição exibidos no site (Pix, CNPJ, razão social);
 *  - criar/alterar usuários do WordPress ou instalar plugins.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_MCP_VERSAO', '2025-03-26');

/* ---------------- Conexões (tokens) ---------------- */

function zoe_mcp_conexoes()
{
    $c = get_option('zoe_mcp_conexoes', array());
    return is_array($c) ? $c : array();
}

function zoe_mcp_url($token)
{
    return rest_url('zoe-mcp/v1/conector/' . $token);
}

function zoe_mcp_validar($token)
{
    foreach (zoe_mcp_conexoes() as $id => $c) {
        if (!empty($c['ativo']) && isset($c['token']) && hash_equals($c['token'], (string) $token)) {
            return array_merge($c, array('id' => $id));
        }
    }
    return null;
}

/* Executa como o primeiro administrador do site, para os registros de autoria. */
function zoe_mcp_assumir_admin()
{
    $u = get_users(array('role' => 'administrator', 'orderby' => 'ID', 'order' => 'ASC', 'number' => 1));
    if ($u) {
        wp_set_current_user($u[0]->ID);
    }
}

/* Reusa as rotas internas já existentes do painel (mesma lógica, mesmas validações). */
function zoe_mcp_interno($metodo, $rota, $json = null)
{
    $req = new WP_REST_Request($metodo, '/zoe/v1/' . ltrim($rota, '/'));
    if ($json !== null) {
        $req->set_header('Content-Type', 'application/json');
        $req->set_body(wp_json_encode($json));
    }
    $res = rest_do_request($req);
    if ($res->is_error()) {
        $e = $res->as_error();
        return new WP_Error($e->get_error_code(), $e->get_error_message());
    }
    return $res->get_data();
}

/* ---------------- Ferramentas ---------------- */

function zoe_mcp_ferramentas()
{
    $obj = function ($props, $req = array()) {
        return array('type' => 'object', 'properties' => (object) $props, 'required' => $req);
    };
    $s = function ($d) {
        return array('type' => 'string', 'description' => $d);
    };
    $n = function ($d) {
        return array('type' => 'integer', 'description' => $d);
    };
    return array(
        'resumo_site' => array(
            'desc' => 'Visão geral do site: eventos com inscrição aberta, estatísticas e o que este conector pode fazer. Comece por aqui.',
            'schema' => $obj(array()),
        ),
        'listar_eventos' => array(
            'desc' => 'Lista todos os eventos (cursos, conferências, ministérios) com id, nome, preço, datas, vagas, inscritos e status.',
            'schema' => $obj(array()),
        ),
        'ver_evento' => array(
            'desc' => 'Detalhes completos de um evento: descrição, nota pós-compra, formulário de inscrição, imagem e situação.',
            'schema' => $obj(array('id' => $n('ID do evento')), array('id')),
        ),
        'salvar_evento' => array(
            'desc' => 'Cria um evento novo (sem id) ou edita um existente (com id). Só os campos enviados são alterados. Preço em reais (ex.: "60" ou "59,90"); datas AAAA-MM-DD; status publish ou draft; vagas vazio = ilimitado.',
            'schema' => $obj(array(
                'id' => $n('ID do evento (omita para criar um novo)'),
                'nome' => $s('Nome do evento'),
                'preco' => $s('Preço em reais; "0" = gratuito'),
                'vagas' => $s('Número de vagas; vazio = ilimitado'),
                'resumo' => $s('Resumo curto (aparece no cartão do evento)'),
                'descricao' => $s('Descrição completa'),
                'nota' => $s('Nota pós-compra (aparece no e-mail; links de grupo do WhatsApp viram botão)'),
                'data' => $s('Data de início (AAAA-MM-DD)'),
                'fim' => $s('Data de término (AAAA-MM-DD)'),
                'prazo' => $s('Prazo final de inscrição (AAAA-MM-DD)'),
                'local' => $s('Local do evento'),
                'status' => $s('publish (no ar) ou draft (rascunho)'),
            )),
        ),
        'listar_inscricoes' => array(
            'desc' => 'Todas as inscrições de um evento, consolidadas (nome, rede/célula, líder, contato, status do pedido). Para filtrar por período, use relatorio.',
            'schema' => $obj(array('evento_id' => $n('ID do evento')), array('evento_id')),
        ),
        'pendencias' => array(
            'desc' => 'Pedidos aguardando pagamento ou cancelados sem pagamento nos últimos 30 dias, com contato para cobrança.',
            'schema' => $obj(array()),
        ),
        'dar_baixa' => array(
            'desc' => 'Marca um pedido como pago (pagamento recebido fora do site: dinheiro ou Pix direto). Use só com comprovante conferido.',
            'schema' => $obj(array('pedido_id' => $n('Número do pedido')), array('pedido_id')),
        ),
        'enviar_lembrete' => array(
            'desc' => 'Envia por e-mail o lembrete de pagamento de um pedido pendente, com o link para pagar.',
            'schema' => $obj(array('pedido_id' => $n('Número do pedido')), array('pedido_id')),
        ),
        'enviar_confirmacao' => array(
            'desc' => 'Reenvia o e-mail de confirmação de inscrição de pedidos pagos (até 10 por vez).',
            'schema' => $obj(array('pedido_ids' => array('type' => 'array', 'items' => array('type' => 'integer'), 'description' => 'Números dos pedidos')), array('pedido_ids')),
        ),
        'relatorio' => array(
            'desc' => 'Relatório consolidado de inscrições. produtos: lista de IDs de eventos (vazio = todos); escopo: hoje, d7, d30, d60, d90, todos.',
            'schema' => $obj(array(
                'produtos' => array('type' => 'array', 'items' => array('type' => 'integer'), 'description' => 'IDs dos eventos (vazio = todos)'),
                'escopo' => $s('Período (padrão d90)'),
            )),
        ),
        'ver_textos_site' => array(
            'desc' => 'Todos os textos editáveis da página inicial: título, visão, pastores, ano, células, cultos, ministérios, contato e redes sociais.',
            'schema' => $obj(array()),
        ),
        'editar_textos_site' => array(
            'desc' => 'Edita textos da página inicial. Envie em dados só as chaves a alterar (veja as chaves em ver_textos_site). Asteriscos marcam a palavra destacada: "O ano do *fluir*". Os campos de contribuição (pix, cnpj, razao) não podem ser alterados por aqui.',
            'schema' => $obj(array('dados' => array('type' => 'object', 'description' => 'Pares chave: valor a alterar')), array('dados')),
        ),
        'editar_celulas' => array(
            'desc' => 'Define a lista de células que aparecem na pergunta "Qual a sua célula?" das inscrições. lista substitui a lista inteira; off esconde sem apagar.',
            'schema' => $obj(array(
                'lista' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Todas as células, na ordem'),
                'off' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Células escondidas da inscrição'),
            ), array('lista')),
        ),
        'listar_paginas' => array(
            'desc' => 'Lista as páginas e posts do site (id, título, tipo, status, link).',
            'schema' => $obj(array()),
        ),
        'ler_pagina' => array(
            'desc' => 'Conteúdo completo de uma página ou post.',
            'schema' => $obj(array('id' => $n('ID da página ou post')), array('id')),
        ),
        'salvar_pagina' => array(
            'desc' => 'Cria (sem id) ou edita (com id) uma página ou post. Conteúdo em HTML simples. status: publish ou draft.',
            'schema' => $obj(array(
                'id' => $n('ID (omita para criar)'),
                'titulo' => $s('Título'),
                'conteudo' => $s('Conteúdo em HTML'),
                'status' => $s('publish ou draft'),
                'tipo' => $s('page ou post (só ao criar; padrão page)'),
            )),
        ),
        'listar_imagens' => array(
            'desc' => 'Busca imagens já enviadas à biblioteca do site (id, título, url). Use busca para filtrar pelo nome.',
            'schema' => $obj(array('busca' => $s('Termo de busca (opcional)'))),
        ),
        'definir_imagem_evento' => array(
            'desc' => 'Define a imagem de capa de um evento usando uma imagem da biblioteca (veja listar_imagens).',
            'schema' => $obj(array('evento_id' => $n('ID do evento'), 'imagem_id' => $n('ID da imagem')), array('evento_id', 'imagem_id')),
        ),
    );
}

function zoe_mcp_executar($nome, $arg, $conexao)
{
    $arg = is_array($arg) ? $arg : array();
    switch ($nome) {
        case 'resumo_site':
            $evs = array_values(array_filter(zoe_p_eventos(), function ($e) {
                return $e['status'] === 'publish';
            }));
            return array(
                'site' => home_url('/'),
                'stats' => zoe_p_stats(),
                'eventos_no_ar' => array_map(function ($e) {
                    return array('id' => $e['id'], 'nome' => $e['nome'], 'aberto' => $e['aberto'], 'inscritos' => $e['inscritos'], 'preco' => $e['precoTxt'], 'data' => $e['data']);
                }, $evs),
                'escopo' => 'Este conector administra eventos, inscrições, baixas, lembretes, relatórios, textos do site, células, páginas e imagens. Não acessa configurações de pagamento nem Mercado Pago.',
            );

        case 'listar_eventos':
            return array_map(function ($e) {
                return array(
                    'id' => $e['id'], 'nome' => $e['nome'], 'status' => $e['status'], 'aberto' => $e['aberto'],
                    'preco' => $e['precoTxt'], 'vagas' => $e['vagas'], 'inscritos' => $e['inscritos'],
                    'data' => $e['data'], 'fim' => $e['fim'], 'prazo' => $e['prazo'], 'local' => $e['local'], 'link' => $e['link'],
                );
            }, zoe_p_eventos());

        case 'ver_evento':
            $p = wc_get_product(absint(isset($arg['id']) ? $arg['id'] : 0));
            if (!$p) {
                return new WP_Error('nao', 'Evento não encontrado');
            }
            return zoe_p_evento($p);

        case 'salvar_evento':
            $json = array_intersect_key($arg, array_flip(array('id', 'nome', 'preco', 'vagas', 'resumo', 'descricao', 'nota', 'data', 'fim', 'prazo', 'local', 'status')));
            if (empty($json['id'])) {
                unset($json['id']);
                if (!isset($json['nome'])) {
                    return new WP_Error('nome', 'Para criar um evento, informe o nome');
                }
            } elseif (!isset($json['nome'])) {
                $p = wc_get_product(absint($json['id']));
                if (!$p) {
                    return new WP_Error('nao', 'Evento não encontrado');
                }
                $json['nome'] = $p->get_name();
            }
            return zoe_mcp_interno('POST', 'evento', $json);

        case 'listar_inscricoes':
            return zoe_mcp_interno('GET', 'inscricoes/' . absint(isset($arg['evento_id']) ? $arg['evento_id'] : 0));

        case 'pendencias':
            return zoe_mcp_interno('GET', 'pendentes');

        case 'dar_baixa':
            return zoe_mcp_interno('POST', 'pendentes/' . absint(isset($arg['pedido_id']) ? $arg['pedido_id'] : 0) . '/pago', array());

        case 'enviar_lembrete':
            return zoe_mcp_interno('POST', 'pendentes/' . absint(isset($arg['pedido_id']) ? $arg['pedido_id'] : 0) . '/lembrar', array());

        case 'enviar_confirmacao':
            return zoe_mcp_interno('POST', 'confirmacao/enviar', array('ids' => array_map('absint', (array) (isset($arg['pedido_ids']) ? $arg['pedido_ids'] : array()))));

        case 'relatorio':
            $prods = implode(',', array_map('absint', (array) (isset($arg['produtos']) ? $arg['produtos'] : array())));
            $esc = isset($arg['escopo']) && preg_match('/^(todos|abertos|hoje|d\d{1,3})$/', $arg['escopo']) ? $arg['escopo'] : 'd90';
            $d = zoe_rel_dados($esc, $prods);
            $out = array('escopo' => $esc, 'eventos' => array());
            foreach ($d['eventos'] as $pid => $ev) {
                $linhas = array_slice(array_reverse($ev['linhas']), 0, 300);
                $out['eventos'][] = array(
                    'id' => $pid, 'nome' => $ev['nome'], 'pagos' => $ev['pagos'], 'aguardando' => $ev['aguard'],
                    'inscricoes' => $linhas,
                    'aviso' => count($ev['linhas']) > 300 ? 'Mostrando as 300 mais recentes de ' . count($ev['linhas']) : '',
                );
            }
            return $out;

        case 'ver_textos_site':
            $o = zoe_p_site();
            unset($o['_img']);
            return $o;

        case 'editar_textos_site':
            $dados = (array) (isset($arg['dados']) ? $arg['dados'] : array());
            $bloqueadas = array_intersect(array_keys($dados), array('pix', 'cnpj', 'razao'));
            if ($bloqueadas) {
                return new WP_Error('bloqueado', 'Os campos de contribuição (' . implode(', ', $bloqueadas) . ') não podem ser alterados pelo conector. Peça a um administrador para mudar no Painel.');
            }
            $r = zoe_mcp_interno('POST', 'site', array('dados' => $dados));
            return is_wp_error($r) ? $r : array('ok' => true, 'alteradas' => array_keys($dados));

        case 'editar_celulas':
            return zoe_mcp_interno('POST', 'celulas', array(
                'lista' => (array) (isset($arg['lista']) ? $arg['lista'] : array()),
                'off' => (array) (isset($arg['off']) ? $arg['off'] : array()),
            ));

        case 'listar_paginas':
            $posts = get_posts(array('post_type' => array('page', 'post'), 'post_status' => array('publish', 'draft', 'private'), 'numberposts' => 200, 'orderby' => 'modified', 'order' => 'DESC'));
            return array_map(function ($p) {
                return array('id' => $p->ID, 'titulo' => $p->post_title, 'tipo' => $p->post_type, 'status' => $p->post_status, 'link' => get_permalink($p), 'modificado' => $p->post_modified);
            }, $posts);

        case 'ler_pagina':
            $p = get_post(absint(isset($arg['id']) ? $arg['id'] : 0));
            if (!$p || !in_array($p->post_type, array('page', 'post'), true)) {
                return new WP_Error('nao', 'Página não encontrada');
            }
            return array('id' => $p->ID, 'titulo' => $p->post_title, 'tipo' => $p->post_type, 'status' => $p->post_status, 'conteudo' => $p->post_content, 'link' => get_permalink($p));

        case 'salvar_pagina':
            $id = absint(isset($arg['id']) ? $arg['id'] : 0);
            $dados = array();
            if ($id) {
                $p = get_post($id);
                if (!$p || !in_array($p->post_type, array('page', 'post'), true)) {
                    return new WP_Error('nao', 'Página não encontrada (só páginas e posts podem ser editados por aqui)');
                }
                $dados['ID'] = $id;
            } else {
                if (trim((string) (isset($arg['titulo']) ? $arg['titulo'] : '')) === '') {
                    return new WP_Error('titulo', 'Para criar, informe o título');
                }
                $dados['post_type'] = isset($arg['tipo']) && $arg['tipo'] === 'post' ? 'post' : 'page';
                $dados['post_status'] = 'draft';
            }
            if (isset($arg['titulo'])) {
                $dados['post_title'] = sanitize_text_field($arg['titulo']);
            }
            if (isset($arg['conteudo'])) {
                $dados['post_content'] = wp_kses_post($arg['conteudo']);
            }
            if (isset($arg['status']) && in_array($arg['status'], array('publish', 'draft'), true)) {
                $dados['post_status'] = $arg['status'];
            }
            $nid = $id ? wp_update_post($dados, true) : wp_insert_post($dados, true);
            if (is_wp_error($nid)) {
                return $nid;
            }
            do_action('litespeed_purge_all');
            $p = get_post($nid);
            return array('id' => $p->ID, 'titulo' => $p->post_title, 'status' => $p->post_status, 'link' => get_permalink($p));

        case 'listar_imagens':
            $q = array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'numberposts' => 30, 'orderby' => 'date', 'order' => 'DESC');
            if (!empty($arg['busca'])) {
                $q['s'] = sanitize_text_field($arg['busca']);
            }
            return array_map(function ($p) {
                return array('id' => $p->ID, 'titulo' => $p->post_title, 'url' => wp_get_attachment_image_url($p->ID, 'large'));
            }, get_posts($q));

        case 'definir_imagem_evento':
            return zoe_mcp_interno('POST', 'evento/' . absint(isset($arg['evento_id']) ? $arg['evento_id'] : 0) . '/flag', array('imgId' => absint(isset($arg['imagem_id']) ? $arg['imagem_id'] : 0)));
    }
    return new WP_Error('nao_existe', 'Ferramenta desconhecida: ' . $nome);
}

/* ---------------- Protocolo MCP (JSON-RPC sobre HTTP) ---------------- */

function zoe_mcp_rpc($msg, $conexao)
{
    $id = isset($msg['id']) ? $msg['id'] : null;
    $metodo = isset($msg['method']) ? (string) $msg['method'] : '';
    $par = isset($msg['params']) && is_array($msg['params']) ? $msg['params'] : array();
    $ok = function ($result) use ($id) {
        return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $result);
    };
    $erro = function ($cod, $txt) use ($id) {
        return array('jsonrpc' => '2.0', 'id' => $id, 'error' => array('code' => $cod, 'message' => $txt));
    };

    // Notificações (sem id) não têm resposta.
    if ($id === null && strpos($metodo, 'notifications/') === 0) {
        return null;
    }

    switch ($metodo) {
        case 'initialize':
            $pv = isset($par['protocolVersion']) ? (string) $par['protocolVersion'] : '';
            return $ok(array(
                'protocolVersion' => in_array($pv, array('2024-11-05', '2025-03-26', '2025-06-18'), true) ? $pv : ZOE_MCP_VERSAO,
                'capabilities' => array('tools' => (object) array()),
                'serverInfo' => array('name' => 'Zoe Church', 'version' => ZOE_TEMA_V),
                'instructions' => 'Administração do site da Zoe Church (zoechurchfrg.com.br): eventos, inscrições, pendências e baixas, lembretes, confirmações, relatórios, textos da página inicial, células, páginas e imagens. Este conector NÃO acessa configurações de pagamento nem Mercado Pago, e não altera os dados de contribuição (Pix/CNPJ). Conexão de: ' . $conexao['nome'] . '. Comece com resumo_site.',
            ));

        case 'ping':
            return $ok((object) array());

        case 'tools/list':
            $tools = array();
            foreach (zoe_mcp_ferramentas() as $nome => $f) {
                $tools[] = array('name' => $nome, 'description' => $f['desc'], 'inputSchema' => $f['schema']);
            }
            return $ok(array('tools' => $tools));

        case 'tools/call':
            $nome = isset($par['name']) ? (string) $par['name'] : '';
            if (!array_key_exists($nome, zoe_mcp_ferramentas())) {
                return $erro(-32602, 'Ferramenta desconhecida: ' . $nome);
            }
            $r = zoe_mcp_executar($nome, isset($par['arguments']) ? $par['arguments'] : array(), $conexao);
            if (is_wp_error($r)) {
                return $ok(array('content' => array(array('type' => 'text', 'text' => 'Erro: ' . $r->get_error_message())), 'isError' => true));
            }
            return $ok(array('content' => array(array('type' => 'text', 'text' => wp_json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)))));

        case 'resources/list':
            return $ok(array('resources' => array()));

        case 'prompts/list':
            return $ok(array('prompts' => array()));
    }
    return $erro(-32601, 'Método não suportado: ' . $metodo);
}

function zoe_mcp_http($q)
{
    $conexao = zoe_mcp_validar($q['token']);
    if (!$conexao) {
        return new WP_REST_Response(array('erro' => 'Conexão inválida ou revogada'), 404);
    }

    if ($q->get_method() === 'GET') {
        // Sem fluxo SSE: o cliente usa só POST (resposta JSON direta).
        return new WP_REST_Response(null, 405);
    }
    if ($q->get_method() === 'DELETE') {
        return new WP_REST_Response(null, 200);
    }

    $corpo = json_decode($q->get_body(), true);
    if ($corpo === null) {
        return new WP_REST_Response(array('jsonrpc' => '2.0', 'id' => null, 'error' => array('code' => -32700, 'message' => 'JSON inválido')), 400);
    }

    zoe_mcp_assumir_admin();

    // Registra o último uso (no máximo uma vez por minuto, para não pesar).
    $todas = zoe_mcp_conexoes();
    if (isset($todas[$conexao['id']]) && time() - (int) (isset($todas[$conexao['id']]['uso']) ? $todas[$conexao['id']]['uso'] : 0) > 60) {
        $todas[$conexao['id']]['uso'] = time();
        update_option('zoe_mcp_conexoes', $todas, false);
    }

    $lote = isset($corpo[0]) && is_array($corpo[0]) ? $corpo : array($corpo);
    $respostas = array();
    foreach ($lote as $msg) {
        $r = zoe_mcp_rpc(is_array($msg) ? $msg : array(), $conexao);
        if ($r !== null) {
            $respostas[] = $r;
        }
    }
    if (!$respostas) {
        return new WP_REST_Response(null, 202);
    }
    $saida = isset($corpo[0]) && is_array($corpo[0]) ? $respostas : $respostas[0];
    return new WP_REST_Response($saida, 200);
}

/* ---------------- Rotas ---------------- */

add_action('rest_api_init', function () {
    register_rest_route('zoe-mcp/v1', '/conector/(?P<token>[A-Za-z0-9]{24,64})', array(
        'methods' => array('GET', 'POST', 'DELETE'),
        'callback' => 'zoe_mcp_http',
        'permission_callback' => '__return_true',
    ));

    // Gestão das conexões — só administradores do WordPress.
    $admin = function () {
        return current_user_can('manage_options');
    };
    register_rest_route('zoe/v1', '/conexoes', array(
        array(
            'methods' => 'GET',
            'permission_callback' => $admin,
            'callback' => function () {
                $out = array();
                foreach (zoe_mcp_conexoes() as $id => $c) {
                    $out[] = array(
                        'id' => $id,
                        'nome' => $c['nome'],
                        'criado' => date_i18n('d/m/Y', $c['criado']),
                        'uso' => !empty($c['uso']) ? date_i18n('d/m/Y H:i', $c['uso']) : '',
                        'url' => zoe_mcp_url($c['token']),
                    );
                }
                return $out;
            },
        ),
        array(
            'methods' => 'POST',
            'permission_callback' => $admin,
            'callback' => function ($q) {
                $d = $q->get_json_params();
                $nome = trim(sanitize_text_field((string) (isset($d['nome']) ? $d['nome'] : '')));
                if ($nome === '') {
                    return new WP_Error('nome', 'Dê um nome à conexão (ex.: o nome da pessoa)', array('status' => 400));
                }
                $todas = zoe_mcp_conexoes();
                $id = 'c' . time() . wp_rand(100, 999);
                $todas[$id] = array(
                    'token' => wp_generate_password(40, false, false),
                    'nome' => $nome,
                    'criado' => time(),
                    'uso' => 0,
                    'ativo' => 1,
                );
                update_option('zoe_mcp_conexoes', $todas, false);
                return array('id' => $id, 'nome' => $nome, 'url' => zoe_mcp_url($todas[$id]['token']));
            },
        ),
    ));
    register_rest_route('zoe/v1', '/conexoes/(?P<id>[a-z0-9]+)', array(
        'methods' => 'DELETE',
        'permission_callback' => $admin,
        'callback' => function ($q) {
            $todas = zoe_mcp_conexoes();
            if (!isset($todas[$q['id']])) {
                return new WP_Error('nao', 'Conexão não encontrada', array('status' => 404));
            }
            unset($todas[$q['id']]);
            update_option('zoe_mcp_conexoes', $todas, false);
            return array('ok' => true);
        },
    ));
});
