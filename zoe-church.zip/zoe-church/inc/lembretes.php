<?php
/**
 * Pagamentos não concluídos: o Mercado Pago confirma sozinho os que são pagos.
 * Aqui cuidamos de quem começou a inscrição e não pagou:
 *  - 1 hora depois, o site manda um e-mail com o link para terminar o pagamento;
 *  - no Painel aparece a lista "Aguardando pagamento", com botão de WhatsApp e link de pagamento.
 */
if (!defined('ABSPATH') || !class_exists('WooCommerce')) {
    return;
}

define('ZOE_LEMBRETE_HOOK', 'zoe_lembrete_pagamento');

/** Nome, telefone e e-mail de quem fez o pedido (também no formulário antigo). */
function zoe_pend_contato($order)
{
    $nome  = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
    $tel   = (string) $order->get_billing_phone();
    $email = (string) $order->get_billing_email();
    $rot   = function_exists('zoe_rel_rotulos_antigos') ? zoe_rel_rotulos_antigos() : array();
    foreach ($rot as $mk => $label) {
        $v = $order->get_meta($mk);
        if (!is_string($v) || trim($v) === '' || $v === 'Selecione') {
            continue;
        }
        if ($nome === '' && preg_match('/nome/i', $label) && !preg_match('/respons|homem|mulher/i', $label)) {
            $nome = trim($v);
        }
        if ($tel === '' && preg_match('/whats|telefone|celular|contato/i', $label) && preg_match('/\d{8,}/', preg_replace('/\D/', '', $v))) {
            $tel = trim($v);
        }
        if ($email === '' && is_email(trim($v))) {
            $email = trim($v);
        }
    }
    foreach ($order->get_items() as $it) {
        $insc = $it->get_meta('_zoe_inscricoes');
        if ($nome === '' && is_array($insc) && $insc) {
            $p = (array) reset($insc);
            foreach (array('Nome completo', 'Nome do responsável') as $k) {
                if (!empty($p[$k])) {
                    $nome = $p[$k];
                    break;
                }
            }
        }
    }
    return array('nome' => $nome, 'tel' => $tel, 'email' => $email);
}

function zoe_pend_eventos($order)
{
    $n = array();
    foreach ($order->get_items() as $it) {
        $n[] = $it->get_name() . ($it->get_quantity() > 1 ? ' (' . $it->get_quantity() . ' vagas)' : '');
    }
    return implode(', ', $n);
}

/* ---------- e-mail de lembrete, 1 hora depois ---------- */
add_action('init', function () {
    if (!wp_next_scheduled(ZOE_LEMBRETE_HOOK)) {
        wp_schedule_event(time() + 300, 'hourly', ZOE_LEMBRETE_HOOK);
    }
});
add_action(ZOE_LEMBRETE_HOOK, 'zoe_pend_enviar_lembretes');

function zoe_pend_enviar_lembretes()
{
    $ids = wc_get_orders(array(
        'type'         => 'shop_order',
        'status'       => array('wc-pending'),
        'date_created' => (time() - 20 * HOUR_IN_SECONDS) . '...' . (time() - HOUR_IN_SECONDS),
        'limit'        => 50,
        'return'       => 'ids',
    ));
    foreach ($ids as $id) {
        $o = wc_get_order($id);
        if (!$o || $o->get_meta('_zoe_lembrete')) {
            continue;
        }
        $o->update_meta_data('_zoe_lembrete', time());
        $c = zoe_pend_contato($o);
        if ($c['email'] && zoe_pend_email($o, $c)) {
            $o->add_order_note('Lembrete de pagamento enviado por e-mail para ' . $c['email'] . '.');
        }
        $o->save();
    }
}

function zoe_pend_email($o, $c)
{
    $link  = $o->get_checkout_payment_url();
    $ev    = zoe_pend_eventos($o);
    $nome  = $c['nome'] ? strtok($c['nome'], ' ') : '';
    $site  = get_bloginfo('name');
    $corpo = '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#141216;max-width:520px">'
        . '<p>Olá' . ($nome ? ', ' . esc_html($nome) : '') . '!</p>'
        . '<p>Vimos que você começou a inscrição em <b>' . esc_html($ev) . '</b>, mas o pagamento ainda não foi concluído.</p>'
        . '<p>Para garantir sua vaga, é só terminar o pagamento pelo link abaixo (Pix ou cartão):</p>'
        . '<p><a href="' . esc_url($link) . '" style="display:inline-block;background:#141216;color:#fff;padding:13px 24px;border-radius:999px;text-decoration:none;font-weight:bold">Concluir pagamento</a></p>'
        . '<p style="color:#6f6a74;font-size:13px">Pedido nº ' . esc_html($o->get_order_number()) . ' · ' . wp_strip_all_tags(wc_price($o->get_total())) . '. Se você já pagou, pode ignorar esta mensagem.</p>'
        . '<p>' . esc_html($site) . '</p></div>';
    return wp_mail($c['email'], 'Falta pouco: conclua sua inscrição em ' . $ev, $corpo, array('Content-Type: text/html; charset=UTF-8'));
}

/* ---------- lista para o Painel ---------- */
function zoe_pend_lista()
{
    $ids = wc_get_orders(array(
        'type'         => 'shop_order',
        'status'       => array('wc-pending', 'wc-on-hold', 'wc-cancelled', 'wc-failed'),
        'date_created' => '>' . (time() - 30 * DAY_IN_SECONDS),
        'limit'        => 100,
        'return'       => 'ids',
        'orderby'      => 'date',
        'order'        => 'DESC',
    ));
    $out = array();
    foreach ($ids as $id) {
        $o = wc_get_order($id);
        if (!$o || !is_a($o, 'WC_Order')) {
            continue;
        }
        $c = zoe_pend_contato($o);
        $d = $o->get_date_created();
        $tel = preg_replace('/\D/', '', $c['tel']);
        if ($tel && strlen($tel) <= 11) {
            $tel = '55' . $tel;
        }
        if (in_array($o->get_status(), array('cancelled', 'failed'), true) && (float) $o->get_total() <= 0) {
            continue; // cancelado sem valor não é inscrição perdida
        }
        $out[] = array(
            'id'       => $o->get_id(),
            'numero'   => $o->get_order_number(),
            'status'   => wc_get_order_status_name($o->get_status()),
            'st'       => $o->get_status(),
            'quando'   => $d ? $d->date_i18n('d/m H:i') : '',
            'nome'     => $c['nome'],
            'tel'      => $c['tel'],
            'whats'    => $tel,
            'email'    => $c['email'],
            'eventos'  => zoe_pend_eventos($o),
            'total'    => html_entity_decode(wp_strip_all_tags(wc_price($o->get_total())), ENT_QUOTES, 'UTF-8'),
            'link'     => $o->get_checkout_payment_url(),
            'lembrete' => (bool) $o->get_meta('_zoe_lembrete'),
            'editWp'   => admin_url('post.php?post=' . $o->get_id() . '&action=edit'),
        );
    }
    return $out;
}

add_action('rest_api_init', function () {
    register_rest_route('zoe/v1', '/pendentes', array(
        'methods'             => 'GET',
        'callback'            => function () {
            return array('pendentes' => zoe_pend_lista());
        },
        'permission_callback' => function () {
            return current_user_can('edit_products');
        },
    ));
    register_rest_route('zoe/v1', '/pendentes/(?P<id>\d+)/pago', array(
        'methods'             => 'POST',
        'callback'            => function ($q) {
            $o = wc_get_order((int) $q['id']);
            if (!$o || !is_a($o, 'WC_Order')) {
                return new WP_Error('nao', 'Pedido não encontrado', array('status' => 404));
            }
            if (!in_array($o->get_status(), array('pending', 'on-hold', 'cancelled', 'failed'), true)) {
                return new WP_Error('ja', 'Esse pedido já está pago ou concluído.', array('status' => 400));
            }
            $u = wp_get_current_user();
            $o->update_meta_data('_zoe_baixa', time());
            // cancelado -> pago: o WooCommerce desconta as vagas de novo e manda o e-mail de confirmação sozinho
            $o->set_status('completed', 'Pagamento recebido fora do site (dinheiro ou Pix direto). Baixa dada no Painel por ' . $u->display_name . '.');
            $o->save();
            return array('ok' => true, 'status' => wc_get_order_status_name($o->get_status()));
        },
        'permission_callback' => function () {
            return current_user_can('manage_woocommerce');
        },
    ));
    register_rest_route('zoe/v1', '/pendentes/(?P<id>\d+)/lembrar', array(
        'methods'             => 'POST',
        'callback'            => function ($q) {
            $o = wc_get_order((int) $q['id']);
            if (!$o || $o->get_status() !== 'pending') {
                return new WP_Error('nao', 'Pedido não está aguardando pagamento', array('status' => 400));
            }
            $c = zoe_pend_contato($o);
            if (!$c['email']) {
                return new WP_Error('sem', 'Esse pedido não tem e-mail. Use o WhatsApp.', array('status' => 400));
            }
            $ok = zoe_pend_email($o, $c);
            if ($ok) {
                $o->update_meta_data('_zoe_lembrete', time());
                $o->add_order_note('Lembrete de pagamento enviado por e-mail para ' . $c['email'] . ' (pelo Painel).');
                $o->save();
            }
            return array('ok' => (bool) $ok);
        },
        'permission_callback' => function () {
            return current_user_can('edit_products');
        },
    ));
});
