<?php
/**
 * Ao ativar o tema: configura tudo sozinho e oferece desligar, com um clique,
 * os plugins que o tema já substitui.
 */
if (!defined('ABSPATH')) {
    exit;
}

function zoe_plugins_dispensaveis()
{
    return array(
        'header-footer-elementor/header-footer-elementor.php' => 'Elementor Header & Footer (o tema já tem cabeçalho e rodapé)',
        'xpro-theme-builder/xpro-theme-builder.php'           => 'Xpro Theme Builder (o tema já monta as páginas)',
        'shopengine/shopengine.php'                           => 'ShopEngine (o tema já tem a página do evento)',
        'templately/templately.php'                           => 'Templately (biblioteca de modelos, não usada)',
        'unique-headers/index.php'                            => 'Unique Headers (o tema não usa)',
    );
}

function zoe_plugins_ativos_dispensaveis()
{
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    return array_filter(zoe_plugins_dispensaveis(), function ($k) {
        return is_plugin_active($k);
    }, ARRAY_FILTER_USE_KEY);
}

add_action('after_switch_theme', function () {
    if (get_option('zoe_ev_celulas') === false) {
        add_option('zoe_ev_celulas', "Conexão Zoe\nRede Vida\nDesperte Z\nImpacto Zoe\nOhana\nPropósito Zoe");
    }
    if (get_option('zoe_ev_settings') === false) {
        add_option('zoe_ev_settings', array('direto_checkout' => 1, 'simplificar' => 1, 'pedir_cpf' => 0));
    }
    set_transient('zoe_boas_vindas', 1, DAY_IN_SECONDS);
    do_action('litespeed_purge_all');
});

add_action('admin_notices', function () {
    if (!current_user_can('activate_plugins')) {
        return;
    }
    $sobra = zoe_plugins_ativos_dispensaveis();
    $boas  = get_transient('zoe_boas_vindas');
    if (!$boas && !$sobra) {
        return;
    }
    echo '<div class="notice notice-success" style="padding:14px 16px"><p style="font-size:15px;margin:0 0 8px"><strong>Tema Zoe Church ativado!</strong> O site novo já está no ar.</p>';
    if ($sobra) {
        $url = wp_nonce_url(admin_url('admin-post.php?action=zoe_otimizar'), 'zoe_otimizar');
        echo '<p style="margin:0 0 10px">Para deixar o site mais rápido, desligue os plugins que o tema já substitui:</p><ul style="margin:0 0 12px 18px;list-style:disc">';
        foreach ($sobra as $nome) {
            echo '<li>' . esc_html($nome) . '</li>';
        }
        echo '</ul><p style="margin:0"><a class="button button-primary button-hero" href="' . esc_url($url) . '">Deixar o site rápido (1 clique)</a> &nbsp; <a href="' . esc_url(admin_url('admin.php?page=zoe-site')) . '">Editar textos e fotos do site</a></p>';
    } else {
        echo '<p style="margin:0"><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=zoe-site')) . '">Editar textos e fotos do site</a> &nbsp; <a href="' . esc_url(admin_url('admin.php?page=zoe-eventos')) . '">Criar um evento</a></p>';
        delete_transient('zoe_boas_vindas');
    }
    echo '</div>';
});

add_action('admin_post_zoe_otimizar', function () {
    if (!current_user_can('activate_plugins') || !check_admin_referer('zoe_otimizar')) {
        wp_die('Sem permissão.');
    }
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    deactivate_plugins(array_keys(zoe_plugins_ativos_dispensaveis()));
    do_action('litespeed_purge_all');
    if (class_exists('\Elementor\Plugin')) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
    wp_safe_redirect(admin_url('themes.php?zoe_otimizado=1'));
    exit;
});

add_action('admin_notices', function () {
    if (!empty($_GET['zoe_otimizado'])) { // phpcs:ignore
        echo '<div class="notice notice-success is-dismissible"><p>Pronto! Plugins desnecessários desligados e cache limpo. Se precisar, dá para reativá-los em Plugins.</p></div>';
    }
});
