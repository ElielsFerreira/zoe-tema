<?php
/**
 * Painel Zoe: administração no estilo do protótipo, em zoechurchfrg.com.br/painel/.
 * Só para quem faz login no WordPress e pode editar produtos. Mexe nos dados reais
 * (produtos do WooCommerce, pedidos, opções do tema) por uma API própria (zoe/v1).
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WooCommerce') || !function_exists('zoe_ev_biblioteca')) {
    return;
}
define('ZOE_PAINEL_CAP', 'edit_products');

/** Funções do editor de eventos (ficam no arquivo do admin, que não carrega na API). */
function zoe_p_carregar_admin()
{
    if (!function_exists('zoe_ev_preco') && defined('ZOE_EV_DIR')) {
        require_once ZOE_EV_DIR . 'includes/admin-events.php';
    }
}

/* ---------------- endereço /painel/ ---------------- */
add_action('init', function () {
    add_rewrite_rule('^painel/?$', 'index.php?zoe_painel=1', 'top');
    if (get_option('zoe_painel_rw') !== ZOE_TEMA_V) {
        flush_rewrite_rules(false);
        update_option('zoe_painel_rw', ZOE_TEMA_V, false);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'zoe_painel';
    return $v;
});
add_filter('redirect_canonical', function ($r) {
    return get_query_var('zoe_painel') ? false : $r;
});

/* Atalho "Painel Zoe" na barra do topo do WordPress */
add_action('admin_bar_menu', function ($bar) {
    if (current_user_can(ZOE_PAINEL_CAP)) {
        $bar->add_node(array('id' => 'zoe-painel', 'title' => 'Painel Zoe', 'href' => zoe_url_painel()));
    }
}, 35);

function zoe_url_painel($rota = '')
{
    return home_url('/painel/') . ($rota ? '#/' . ltrim($rota, '/') : '');
}

add_action('template_redirect', function () {
    if (!get_query_var('zoe_painel')) {
        return;
    }
    nocache_headers();
    if (!is_user_logged_in()) {
        wp_safe_redirect(wp_login_url(zoe_url_painel()));
        exit;
    }
    if (!current_user_can(ZOE_PAINEL_CAP)) {
        wp_die('Sua conta não tem acesso à administração do site.', 'Sem acesso', array('response' => 403));
    }
    $v   = ZOE_TEMA_V;
    $uri = get_template_directory_uri() . '/assets/';
    $boot = wp_json_encode(zoe_p_boot());
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex');
    ?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<meta name="theme-color" content="#141216">
<title>Zoe · Administração</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo esc_url($uri . 'painel.css?ver=' . $v); ?>">
</head>
<body class="painel">
<div id="app"><p style="padding:40px;text-align:center;color:#6f6a74">Carregando…</p></div>
<div class="toast" id="toast"></div>
<input type="file" id="arquivo" accept="image/*" hidden>
<script>window.ZP=<?php echo $boot; // phpcs:ignore ?>;</script>
<script src="<?php echo esc_url($uri . 'painel.js?ver=' . $v); ?>"></script>
</body>
</html><?php
    exit;
}, 1);

/* ---------------- dados ---------------- */
function zoe_p_texto($html)
{
    $t = preg_replace('~<br\s*/?>~i', "\n", (string) $html);
    $t = preg_replace('~</p>\s*~i', "\n\n", $t);
    return trim(html_entity_decode(wp_strip_all_tags($t), ENT_QUOTES, 'UTF-8'));
}

function zoe_p_img($v, $size = 'large')
{
    if (is_numeric($v) && (int) $v > 0) {
        $u = wp_get_attachment_image_url((int) $v, $size);
        return $u ? $u : '';
    }
    return (string) $v;
}

function zoe_p_evento($p)
{
    $id   = $p->get_id();
    $simp = $p->is_type('simple');
    $form = function_exists('zoe_ev_get_form') ? zoe_ev_get_form($id) : null;
    $pos  = (string) get_post_meta($id, '_zoe_img_pos', true);
    return array(
        'id'        => $id,
        'nome'      => $p->get_name(),
        'img'       => $p->get_image_id() ? (string) wp_get_attachment_image_url($p->get_image_id(), 'medium_large') : '',
        'imgId'     => (int) $p->get_image_id(),
        'pos'       => preg_match('/^\d{1,3}% \d{1,3}%$/', $pos) ? $pos : '50% 50%',
        'data'      => (string) get_post_meta($id, '_zoe_data', true),
        'prazo'     => (string) get_post_meta($id, '_zoe_prazo', true),
        'fim'       => (string) get_post_meta($id, '_zoe_data_fim', true),
        'local'     => (string) get_post_meta($id, '_zoe_local', true),
        'simples'   => $simp,
        'preco'     => $simp ? wc_format_localized_price($p->get_regular_price()) : '',
        'precoTxt'  => html_entity_decode(wp_strip_all_tags(wc_price($p->get_price())), ENT_QUOTES, 'UTF-8'),
        'vagas'     => $simp && $p->get_manage_stock() ? (string) $p->get_stock_quantity() : '',
        'status'    => $p->get_status(),
        'resumo'    => zoe_p_texto($p->get_short_description()),
        'descricao' => zoe_p_texto($p->get_description()),
        'nota'      => zoe_p_texto($p->get_purchase_note()),
        'aberto'    => $p->is_purchasable() && $p->is_in_stock() && $p->get_status() === 'publish',
        'inscritos' => (int) $p->get_total_sales(),
        'zoe'       => (bool) get_post_meta($id, '_zoe_evento', true),
        'form'      => $form ? array('blocos' => array_values((array) $form['blocos']), 'opcionais' => array_values((array) $form['opcionais']), 'custom' => array_values((array) $form['custom']), 'porVaga' => !empty($form['por_vaga'])) : null,
        'destaque'  => $p->is_featured(),
        'visivel'   => $p->get_catalog_visibility() !== 'hidden',
        'link'      => get_permalink($id),
        'editWp'    => admin_url('post.php?post=' . $id . '&action=edit'),
    );
}

function zoe_p_eventos()
{
    $prods = wc_get_products(array('status' => array('publish', 'draft', 'pending', 'private'), 'limit' => 300, 'orderby' => 'date', 'order' => 'DESC', 'type' => array('simple', 'variable')));
    return array_map('zoe_p_evento', $prods);
}

function zoe_p_site()
{
    $out = array();
    foreach (array_keys(zoe_padroes()) as $k) {
        $out[$k] = zoe_opt($k);
    }
    $out['pos'] = (array) zoe_opt('pos');
    // URLs das imagens guardadas como ID do anexo
    $out['_img'] = array();
    foreach (array('logo', 'cel_img', 'ano_img', 'vida_img') as $k) {
        $out['_img'][$k] = zoe_p_img($out[$k]);
    }
    $out['_img']['hero'] = array_map('zoe_p_img', array_values((array) $out['hero']));
    $out['_img']['pastores'] = array_map(function ($p) {
        return zoe_p_img(isset($p['img']) ? $p['img'] : '', 'medium_large');
    }, array_values((array) $out['pastores']));
    return $out;
}

function zoe_p_stats()
{
    $ids = wc_get_orders(array('type' => 'shop_order', 'status' => array('wc-completed', 'wc-processing'), 'date_created' => '>' . (time() - 30 * DAY_IN_SECONDS), 'limit' => -1, 'return' => 'ids'));
    $insc = 0;
    $valor = 0.0;
    foreach ($ids as $oid) {
        $o = wc_get_order($oid);
        if (!$o || !is_a($o, 'WC_Order')) {
            continue;
        }
        $valor += (float) $o->get_total();
        foreach ($o->get_items() as $it) {
            $insc += (int) $it->get_quantity();
        }
    }
    return array('insc30' => $insc, 'valor30' => html_entity_decode(wp_strip_all_tags(wc_price($valor)), ENT_QUOTES, 'UTF-8'), 'pedidos30' => count($ids));
}

function zoe_p_boot()
{
    $lib = array();
    foreach (zoe_ev_biblioteca() as $k => $b) {
        $lib[$k] = array('t' => $b['titulo'], 'd' => isset($b['desc']) ? $b['desc'] : '', 'campos' => array_map(function ($c) {
            return array('l' => $c['label'], 'tp' => $c['type'], 'r' => !empty($c['req']), 'op' => isset($c['options']) ? array_values((array) $c['options']) : null, 'dep' => isset($c['dep']) ? $c['dep'] : null);
        }, $b['campos']));
    }
    $u = wp_get_current_user();
    return array(
        'api'      => esc_url_raw(rest_url('zoe/v1/')),
        'nonce'    => wp_create_nonce('wp_rest'),
        'relNonce' => wp_create_nonce('zoe_rel_agora'),
        'adminPost' => admin_url('admin-post.php'),
        'site'     => home_url('/'),
        'wpAdmin'  => admin_url(),
        'sair'     => wp_logout_url(home_url('/')),
        'usuario'  => $u->display_name,
        'podeSite' => current_user_can('edit_pages'),
        'admin'    => current_user_can('manage_options'),
        'eventos'  => zoe_p_eventos(),
        'opc'      => zoe_p_site(),
        'celulas'  => zoe_ev_celulas(true),
        'celulasOff' => array_values((array) get_option('zoe_ev_celulas_inativas', array())),
        'bib'      => $lib,
        'tipos'    => zoe_ev_tipos(),
        'rel'      => zoe_rel_opcoes(),
        'stats'    => zoe_p_stats(),
        'specs'    => zoe_img_specs(),
    );
}

/* ---------------- API ---------------- */
add_action('rest_api_init', function () {
    zoe_p_carregar_admin();
    $pode = function () {
        return current_user_can(ZOE_PAINEL_CAP);
    };
    $podeSite = function () {
        return current_user_can('edit_pages');
    };
    $r = function ($rota, $metodo, $cb, $perm) {
        register_rest_route('zoe/v1', $rota, array('methods' => $metodo, 'callback' => $cb, 'permission_callback' => $perm));
    };
    $r('/eventos', 'GET', function () {
        return array('eventos' => zoe_p_eventos(), 'stats' => zoe_p_stats());
    }, $pode);
    $r('/evento', 'POST', 'zoe_p_salvar_evento', $pode);
    $r('/evento/(?P<id>\d+)/flag', 'POST', function ($q) {
        $p = wc_get_product((int) $q['id']);
        if (!$p) {
            return new WP_Error('nao', 'Evento não encontrado', array('status' => 404));
        }
        $d = $q->get_json_params();
        if (isset($d['destaque'])) {
            $p->set_featured(!empty($d['destaque']));
        }
        if (isset($d['visivel'])) {
            $p->set_catalog_visibility(!empty($d['visivel']) ? 'visible' : 'hidden');
        }
        if (isset($d['imgId'])) {
            $p->set_image_id(absint($d['imgId']));
        }
        $p->save();
        if (isset($d['pos'])) {
            update_post_meta($p->get_id(), '_zoe_img_pos', zoe_pos_limpa($d['pos']));
        }
        zoe_ev_limpar_cache();
        return zoe_p_evento(wc_get_product($p->get_id()));
    }, $pode);
    $r('/evento/(?P<id>\d+)/duplicar', 'POST', 'zoe_p_duplicar', $pode);
    $r('/evento/(?P<id>\d+)', 'DELETE', function ($q) {
        $id = (int) $q['id'];
        if (get_post_type($id) !== 'product') {
            return new WP_Error('nao', 'Evento não encontrado', array('status' => 404));
        }
        wp_trash_post($id);
        zoe_ev_limpar_cache();
        return array('ok' => true);
    }, $pode);
    $r('/inscricoes/(?P<id>\d+)', 'GET', function ($q) {
        $id = (int) $q['id'];
        $d = zoe_rel_dados('todos', $id);
        $ev = isset($d['eventos'][$id]) ? $d['eventos'][$id] : null;
        if (!$ev) {
            return array('linhas' => array(), 'cols' => array());
        }
        $fixas = array('Pedido', 'Data', 'Status', 'Pagador', 'Telefone', 'Rede / célula', 'Líder');
        $cols = array_values(array_unique(array_merge($fixas, array_keys($ev['colunas']))));
        return array('linhas' => array_reverse($ev['linhas']), 'cols' => $cols, 'pagos' => $ev['pagos'], 'aguard' => $ev['aguard']);
    }, $pode);
    $r('/upload', 'POST', function ($q) {
        if (empty($_FILES['arquivo'])) {
            return new WP_Error('sem', 'Nenhum arquivo enviado', array('status' => 400));
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $id = media_handle_upload('arquivo', 0);
        if (is_wp_error($id)) {
            return new WP_Error('falhou', $id->get_error_message(), array('status' => 400));
        }
        $m = wp_get_attachment_metadata($id);
        return array('id' => $id, 'url' => wp_get_attachment_image_url($id, 'large'), 'w' => isset($m['width']) ? (int) $m['width'] : 0, 'h' => isset($m['height']) ? (int) $m['height'] : 0);
    }, $pode);
    $r('/site', 'POST', function ($q) {
        $d = $q->get_json_params();
        $atual = array();
        foreach (array_keys(zoe_padroes()) as $k) {
            $atual[$k] = zoe_opt($k);
        }
        $atual['pos'] = (array) zoe_opt('pos');
        foreach ((array) (isset($d['dados']) ? $d['dados'] : array()) as $k => $v) {
            $limpo = zoe_p_limpar_site($k, $v);
            if ($limpo !== null) {
                $atual[$k] = $limpo;
            }
        }
        update_option('zoe_site', $atual);
        do_action('litespeed_purge_all');
        return array('ok' => true, 'opc' => zoe_p_site());
    }, $podeSite);
    $r('/celulas', 'POST', function ($q) {
        $d = $q->get_json_params();
        $lista = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) (isset($d['lista']) ? $d['lista'] : array())))));
        $off = array_values(array_intersect(array_map('sanitize_text_field', (array) (isset($d['off']) ? $d['off'] : array())), $lista));
        update_option('zoe_ev_celulas', implode("\n", $lista));
        update_option('zoe_ev_celulas_inativas', $off);
        return array('ok' => true);
    }, $pode);
    $r('/rel', 'POST', function ($q) {
        $d = $q->get_json_params();
        $emails = array_values(array_unique(array_filter(array_map('sanitize_email', (array) (isset($d['emails']) ? $d['emails'] : array())), 'is_email')));
        $esc = isset($d['escopo']) ? sanitize_key($d['escopo']) : 'recentes';
        update_option('zoe_ev_relatorios', array(
            'emails' => $emails,
            'ativo'  => empty($d['ativo']) ? 0 : 1,
            'hora'   => min(23, max(0, absint(isset($d['hora']) ? $d['hora'] : 7))),
            'escopo' => preg_match('/^(todos|abertos|recentes|hoje|d\d{1,3})$/', $esc) ? $esc : 'd90',
        ));
        zoe_rel_agendar();
        return array('ok' => true, 'rel' => zoe_rel_opcoes());
    }, $pode);
    $r('/rel/enviar', 'POST', function ($q) {
        $d = $q->get_json_params();
        $esc = isset($d['escopo']) ? sanitize_key($d['escopo']) : null;
        delete_option('zoe_ev_rel_erro');
        $n = zoe_rel_enviar(null, in_array($esc, array('recentes', 'abertos', 'todos'), true) ? $esc : null);
        return array('n' => $n, 'erro' => (string) get_option('zoe_ev_rel_erro', ''));
    }, $pode);
});

function zoe_p_limpar_site($k, $v)
{
    $img = function ($x) {
        return is_numeric($x) ? absint($x) : esc_url_raw((string) $x);
    };
    $texto = array('titulo', 'subtitulo', 'cnpj', 'pix', 'razao', 'endereco', 'ano_titulo', 'ano_ref', 'ano_frase', 'vida_titulo', 'vida_verso', 'vida_ref', 'cel_verso', 'cel_ref');
    $area = array('frase', 'faixa', 'visao_titulo', 'visao', 'ano_verso', 'ano_itens', 'vida_texto', 'reuniao', 'cultos', 'cultos_txt', 'cel_txt', 'contrib_txt', 'contato_txt');
    if (in_array($k, $texto, true)) {
        return sanitize_text_field((string) $v);
    }
    if (in_array($k, $area, true)) {
        return sanitize_textarea_field((string) $v);
    }
    if (in_array($k, array('instagram', 'youtube', 'facebook', 'whatsapp'), true)) {
        return esc_url_raw((string) $v);
    }
    if ($k === 'email') {
        return sanitize_email((string) $v);
    }
    if (in_array($k, array('logo', 'cel_img', 'ano_img', 'vida_img'), true)) {
        return $img($v);
    }
    if ($k === 'hero') {
        return array_values(array_map($img, (array) $v));
    }
    if ($k === 'pos') {
        $o = array();
        foreach ((array) $v as $s => $p) {
            $o[sanitize_key($s)] = zoe_pos_limpa($p);
        }
        return $o;
    }
    if ($k === 'pastores') {
        $o = array();
        foreach ((array) $v as $p) {
            if (is_array($p) && trim((string) (isset($p['nome']) ? $p['nome'] : '')) !== '') {
                $o[] = array('nome' => sanitize_text_field($p['nome']), 'cargo' => sanitize_text_field(isset($p['cargo']) ? $p['cargo'] : ''), 'img' => $img(isset($p['img']) ? $p['img'] : ''), 'pos' => zoe_pos_limpa(isset($p['pos']) ? $p['pos'] : ''));
            }
        }
        return $o;
    }
    if ($k === 'ministerios') {
        $o = array();
        foreach ((array) $v as $m) {
            if (is_array($m) && trim((string) (isset($m['nome']) ? $m['nome'] : '')) !== '') {
                $o[] = array('nome' => sanitize_text_field($m['nome']), 'txt' => sanitize_textarea_field(isset($m['txt']) ? $m['txt'] : ''), 'link' => sanitize_text_field(isset($m['link']) ? $m['link'] : ''));
            }
        }
        return $o;
    }
    if ($k === 'redes') {
        $o = array();
        foreach ((array) $v as $r) {
            if (!is_array($r) || trim((string) (isset($r['nome']) ? $r['nome'] : '')) === '') {
                continue;
            }
            $o[] = array(
                'nome'     => sanitize_text_field($r['nome']),
                'lider'    => sanitize_text_field(isset($r['lider']) ? $r['lider'] : ''),
                'dia'      => sanitize_text_field(isset($r['dia']) ? $r['dia'] : ''),
                'bairro'   => sanitize_text_field(isset($r['bairro']) ? $r['bairro'] : ''),
                'contatos' => sanitize_textarea_field(isset($r['contatos']) ? $r['contatos'] : ''),
                'desc'     => sanitize_textarea_field(isset($r['desc']) ? $r['desc'] : ''),
                'ativa'    => !isset($r['ativa']) || !empty($r['ativa']) ? 1 : 0,
            );
        }
        return $o;
    }
    return null;
}

function zoe_p_salvar_evento($q)
{
    $d    = $q->get_json_params();
    $id   = absint(isset($d['id']) ? $d['id'] : 0);
    $novo = !$id;
    $prod = $id ? wc_get_product($id) : new WC_Product_Simple();
    if (!$prod) {
        return new WP_Error('nao', 'Evento não encontrado', array('status' => 404));
    }
    $nome = trim(sanitize_text_field(isset($d['nome']) ? $d['nome'] : ''));
    if ($nome === '') {
        return new WP_Error('nome', 'Dê um nome ao evento', array('status' => 400));
    }
    $prod->set_name($nome);
    if (isset($d['status'])) {
        $prod->set_status(in_array($d['status'], array('publish', 'draft'), true) ? $d['status'] : 'draft');
    }
    if (array_key_exists('resumo', $d)) {
        $prod->set_short_description(wpautop(sanitize_textarea_field((string) $d['resumo'])));
    }
    if (array_key_exists('descricao', $d)) {
        $prod->set_description(wpautop(sanitize_textarea_field((string) $d['descricao'])));
    }
    if (array_key_exists('nota', $d)) {
        $prod->set_purchase_note(sanitize_textarea_field((string) $d['nota']));
    }
    if (isset($d['imgId'])) {
        $prod->set_image_id(absint($d['imgId']));
    }
    if ($prod->is_type('simple')) {
        if ($novo) {
            $prod->set_virtual(true);
            $prod->set_catalog_visibility('visible');
        }
        if (array_key_exists('preco', $d)) {
            $prod->set_regular_price(zoe_ev_preco((string) $d['preco']));
        }
        if (array_key_exists('vagas', $d)) {
            if ((string) $d['vagas'] !== '') {
                $prod->set_manage_stock(true);
                $prod->set_stock_quantity(absint($d['vagas']));
                $prod->set_stock_status(absint($d['vagas']) > 0 ? 'instock' : 'outofstock');
            } else {
                $prod->set_manage_stock(false);
                $prod->set_stock_status('instock');
            }
        }
    }
    foreach (array('data' => '_zoe_data', 'fim' => '_zoe_data_fim', 'prazo' => '_zoe_prazo') as $k => $mk) {
        if (array_key_exists($k, $d)) {
            $prod->update_meta_data($mk, zoe_ev_data_valida($d[$k]));
        }
    }
    if (array_key_exists('local', $d)) {
        $prod->update_meta_data('_zoe_local', sanitize_text_field((string) $d['local']));
    }
    // Formulário: só vale para eventos novos, já no formulário Zoe, ou quando a pessoa escolhe trocar.
    $usa_zoe = $novo || ($id && get_post_meta($id, '_zoe_evento', true)) || !empty($d['usarZoe']);
    if ($usa_zoe && isset($d['form']) && is_array($d['form'])) {
        $f      = $d['form'];
        $lib    = array_keys(zoe_ev_biblioteca());
        $custom = array();
        foreach ((array) (isset($f['custom']) ? $f['custom'] : array()) as $c) {
            if (!is_array($c) || trim((string) (isset($c['label']) ? $c['label'] : '')) === '') {
                continue;
            }
            $custom[] = array(
                'label'   => sanitize_text_field($c['label']),
                'type'    => isset($c['type']) && array_key_exists($c['type'], zoe_ev_tipos()) ? $c['type'] : 'text',
                'options' => sanitize_text_field(isset($c['options']) ? $c['options'] : ''),
                'req'     => !empty($c['req']) ? 1 : 0,
            );
        }
        $prod->update_meta_data('_zoe_evento', '1');
        $prod->update_meta_data('_zoe_form', array(
            'blocos'    => array_values(array_intersect($lib, (array) (isset($f['blocos']) ? $f['blocos'] : array()))),
            'opcionais' => array_values(array_intersect($lib, (array) (isset($f['opcionais']) ? $f['opcionais'] : array()))),
            'custom'    => $custom,
            'por_vaga'  => !empty($f['porVaga']) ? 1 : 0,
        ));
    }
    $nid = $prod->save();
    if (isset($d['pos'])) {
        update_post_meta($nid, '_zoe_img_pos', zoe_pos_limpa($d['pos']));
    }
    zoe_ev_limpar_cache();
    return zoe_p_evento(wc_get_product($nid));
}

function zoe_p_duplicar($q)
{
    $orig = wc_get_product((int) $q['id']);
    if (!$orig) {
        return new WP_Error('nao', 'Evento não encontrado', array('status' => 404));
    }
    if ($orig->is_type('simple')) {
        $novo = new WC_Product_Simple();
        $novo->set_regular_price($orig->get_regular_price());
        $novo->set_sale_price($orig->get_sale_price());
        $novo->set_virtual(true);
        if ($orig->get_manage_stock()) {
            $novo->set_manage_stock(true);
            $novo->set_stock_quantity((int) $orig->get_stock_quantity() + (int) $orig->get_total_sales());
        }
    } else {
        if (!class_exists('WC_Admin_Duplicate_Product')) {
            include_once WC_ABSPATH . 'includes/admin/class-wc-admin-duplicate-product.php';
        }
        $dup  = new WC_Admin_Duplicate_Product();
        $novo = $dup->product_duplicate($orig);
    }
    $novo->set_name($orig->get_name() . ' (cópia)');
    $novo->set_status('draft');
    $novo->set_description($orig->get_description());
    $novo->set_short_description($orig->get_short_description());
    $novo->set_image_id($orig->get_image_id());
    $novo->set_category_ids($orig->get_category_ids());
    $novo->set_catalog_visibility('visible');
    $novo->set_total_sales(0);
    foreach (array('_zoe_evento', '_zoe_form', '_zoe_local', '_zoe_img_pos') as $k) {
        $novo->update_meta_data($k, $orig->get_meta($k));
    }
    $novo->update_meta_data('_zoe_data', '');
    $novo->update_meta_data('_zoe_prazo', '');
    $novo->update_meta_data('_zoe_data_fim', '');
    $nid = $novo->save();
    return zoe_p_evento(wc_get_product($nid));
}
