<?php
/**
 * Página "Site Zoe": textos, imagens, cultos, redes de células e contato — sem mexer em código.
 */
if (!defined('ABSPATH')) {
    exit;
}

function zoe_padroes()
{
    $u = content_url('uploads/');
    return array(
        'titulo'      => 'Nossa mensagem é *Jesus*',
        'subtitulo'   => 'Zoe Church · Fazenda Rio Grande',
        'frase'       => 'Uma igreja em células, simples e apaixonada, que vive o amor de Cristo em Fazenda Rio Grande.',
        'hero'        => array($u . '2025/01/nossa-mensagem.jpg', $u . '2025/01/nossa-paixao.jpg', $u . '2025/01/nossa-cultura.jpg'),
        'faixa'       => "Nossa mensagem é Jesus\nA nossa paixão são pessoas\nNossa cultura é amar e servir\nIgreja em células",
        'visao_titulo' => 'Nós somos a Zoe Church de Fazenda Rio Grande. Uma igreja em células, simples e apaixonada, que vive o amor de *Cristo*.',
        'visao'       => "Uma igreja que está se tornando muito conhecida. Fazemos parte da Rede Zoe de igrejas, e estamos nessa comissão para levar o evangelho a todas as pessoas, transformando-as em discípulos de Jesus.\n\nA palavra “vida” possui duas definições: Bios, no grego, usada para definir a vida biológica, no sentido natural, e Zoe, que se refere à vida no espírito. Ou seja, uma vida abundante. É desta vida que falamos, que o Senhor preparou para nós, com grandes propósitos.\n\nCremos na Palavra onde Jesus diz que obras maiores faríamos, e para isso contamos com mais de 50 líderes de célula levando a Zoe de Deus através das nossas células.\n\nVenha fazer parte da nossa família Zoe!",
        'pastores'    => array(
            array('nome' => 'Fábio Andrade e Ana Paula', 'cargo' => 'Pastores', 'img' => $u . '2024/01/fotor-20240130131344.png'),
            array('nome' => 'Clayton e Mislayne', 'cargo' => 'Pastores auxiliares', 'img' => $u . '2025/01/fotor-20250121175318.png'),
            array('nome' => 'Samir e Roseneia', 'cargo' => 'Pastores auxiliares', 'img' => $u . '2025/01/fotor-20250121175527.png'),
        ),
        'ano_titulo'  => '2026, o ano do *fluir*',
        'ano_verso'   => '“Quem crer em mim, como diz a Escritura, do seu interior fluirão rios de água viva.”',
        'ano_ref'     => 'João 7:38',
        'ano_itens'   => "Fluir na presença\nFluir na obediência\nFluir na intimidade com Cristo",
        'ano_frase'   => 'Não por força ou esforço humano, mas por conexão com a Fonte.',
        'ano_img'     => $u . '2026/01/2026-logotipo_pdf_page-0001.jpg',
        'vida_titulo' => 'Ninguém caminha *sozinho*',
        'vida_texto'  => "Na Zoe, a vida com Deus não acontece só no domingo. Durante a semana, nos encontramos em células: grupos pequenos que se reúnem nas casas para orar, abrir a Bíblia e cuidar uns dos outros.\n\nÉ ali que amizades viram família e cada pessoa é conhecida pelo nome. Seja você novo na fé ou caminhando com Jesus há anos, tem um lugar esperando por você.",
        'vida_verso'  => '“Como é bom e agradável quando os irmãos convivem em união!”',
        'vida_ref'    => 'Salmos 133:1',
        'vida_img'    => $u . '2024/01/WhatsApp-Image-2024-01-27-at-21.00.56-scaled.jpeg',
        'reuniao'     => "Lanche e comunhão\nQuebra-gelo\nLouvor\nEstudo\nOração\nDesafio",
        'cel_verso'   => '“Todos os dias, no templo e de casa em casa, não deixavam de ensinar e proclamar que Jesus é o Cristo.”',
        'cel_ref'     => 'Atos 5:42',
        'ministerios' => array(
            array('nome' => 'Encontro com Deus', 'txt' => 'Três dias de busca profunda por uma conexão mais íntima com Jesus. Vidas transformadas, corações renovados e uma nova vida que começa.', 'link' => 'eventos'),
            array('nome' => 'Reencontro com Deus', 'txt' => 'Para quem já fez o Encontro com Deus e quer dar mais um passo na jornada com o Senhor.', 'link' => '2534'),
            array('nome' => 'Escola de Discípulos', 'txt' => 'Três módulos EAD (Casa sobre a Rocha, Caráter Cristão, Permanecer e Frutificar) para aprender a ser um seguidor de Jesus.', 'link' => '2164'),
            array('nome' => 'Zoe Music', 'txt' => 'Formação de músicos que sirvam ao Senhor com excelência, sensibilidade e compromisso. Turmas de violão com vagas limitadas.', 'link' => '6011'),
            array('nome' => 'Zoe Ballet', 'txt' => 'Ballet e expressão cristã: arte, movimento e princípios bíblicos para formar uma nova geração. Turmas aos sábados.', 'link' => '6788'),
            array('nome' => 'Zoe Judô', 'txt' => 'Esporte que forma vidas, com disciplina, respeito, perseverança e domínio próprio. Aulas às segundas.', 'link' => '6847'),
        ),
        'contato_txt' => 'Fale com a gente pelo WhatsApp ou mande um e-mail, respondemos o mais breve possível. Acompanhe também as nossas redes sociais!',
        'cultos'      => "09h30|Culto da manhã\n18h30|Culto da noite",
        'cultos_txt'  => 'Um ambiente acolhedor para você e sua família viverem momentos únicos na presença de Deus.',
        'cel_img'     => $u . '2024/01/362665253_972721857393259_6471418983242794303_n-1.jpeg',
        'cel_txt'     => 'Somos uma igreja em células! Cada célula é como uma pequena família dentro da igreja, onde nos encontramos em casas, locais de trabalho ou outros ambientes descontraídos. Nossa igreja tem 4 redes de células, lideradas pelos nossos pastores de rede.',
        'redes'       => array(
            array('nome' => 'Rede Samir e Roseneia', 'lider' => 'Pastores Samir e Roseneia', 'dia' => 'Quarta, 20h', 'bairro' => 'Gralha Azul', 'contatos' => "Samir — (42) 98883-4584\nRose — (42) 99919-1025", 'desc' => ''),
            array('nome' => 'Rede Clayton e Mislayne', 'lider' => 'Pastores Clayton e Mislayne', 'dia' => 'Quarta, 20h', 'bairro' => 'Gralha Azul', 'contatos' => "Clayton — (41) 99620-6760\nMislayne — (41) 99517-5209", 'desc' => ''),
            array('nome' => 'Rede Leonardo e Jessica', 'lider' => 'Pastores Leonardo e Jessica', 'dia' => 'Quinta, 20h', 'bairro' => 'Eucaliptos / Greenfield', 'contatos' => "Leonardo — (41) 99620-0107\nJessica — (41) 99669-5123", 'desc' => ''),
            array('nome' => 'Rede Claudio e Carla', 'lider' => 'Pastores Claudio e Carla', 'dia' => 'Quinta, 20h', 'bairro' => 'Gralha Azul', 'contatos' => "Cláudio — (41) 99239-9225\nCarla — (41) 99625-2243", 'desc' => ''),
        ),
        'contrib_txt' => 'Ofertar é um ato de fé e confiança em Deus. Sua contribuição sustenta a missão da Zoe em Fazenda Rio Grande.',
        'cnpj'        => '29.828.778/0001-75',
        'pix'         => '29828778000175',
        'razao'       => 'Associação da Comunidade Zoe de Fazenda Rio Grande',
        'endereco'    => 'Av. Brasil 3171 — Nações, Fazenda Rio Grande, PR · CEP 83824-109',
        'email'       => 'contato@zoechurchfrg.com.br',
        'whatsapp'    => 'https://w.app/prt1sx',
        'instagram'   => 'https://www.instagram.com/zoechurchfrg/',
        'facebook'    => 'https://www.facebook.com/zoefazendariogrande/',
        'youtube'     => 'https://www.youtube.com/channel/UCHUwjGXL3uxPblMA6O8LbEQ',
        'logo'        => $u . '2024/01/cropped-cropped-output-onlinepngtools1.png',
    );
}

function zoe_opt($k)
{
    $o = get_option('zoe_site', array());
    $p = zoe_padroes();
    if (is_array($o) && array_key_exists($k, $o)) {
        return $o[$k]; // depois de salvo, vale o que a pessoa deixou (mesmo vazio)
    }
    return isset($p[$k]) ? $p[$k] : '';
}

/** Linhas de um textarea, sem vazias. */
function zoe_linhas($txt)
{
    return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $txt))));
}

add_action('admin_menu', function () {
    add_menu_page('Site Zoe', 'Site Zoe', 'edit_pages', 'zoe-site', 'zoe_pagina_opcoes', 'dashicons-admin-home', 2);
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook === 'toplevel_page_zoe-site') {
        wp_enqueue_media();
    }
});

/** Tamanho ideal de cada tipo de imagem do site. */
function zoe_img_specs()
{
    return array(
        'hero'     => array(1920, 1080, 'horizontal 16:9', 'Banner de tela cheia. No celular as laterais são cortadas: marque o ponto principal.'),
        'logo'     => array(512, 512, 'quadrado · PNG com fundo transparente', 'Cabeçalho e menu.'),
        'retrato'  => array(1200, 1500, 'vertical 4:5', 'Foto ao lado do texto. No celular aparece mais baixa.'),
        'quadrado' => array(1080, 1080, 'quadrado 1:1', 'Ao lado do texto do tema do ano.'),
        'pastor'   => array(1000, 1000, 'quadrado 1:1', 'Rosto centralizado, de preferência com fundo limpo.'),
        'evento'   => array(1080, 1080, 'quadrado 1:1 · pode ser a mesma arte do Instagram', 'Lista de eventos e página do evento.'),
    );
}

/** Posição (ponto de foco) válida: "x% y%". */
function zoe_pos_limpa($v)
{
    $v = trim((string) $v);
    return preg_match('/^\d{1,3}% \d{1,3}%$/', $v) ? $v : '50% 50%';
}

/** Atributo style com object-position, só quando não é o centro. */
function zoe_pos_attr($pos)
{
    $pos = zoe_pos_limpa($pos);
    return $pos === '50% 50%' ? '' : ' style="object-position:' . esc_attr($pos) . '"';
}

/** Posição salva para um espaço de imagem do site (hero-0, cel, ano, vida). */
function zoe_pos($slot)
{
    $p = (array) zoe_opt('pos');
    return isset($p[$slot]) ? zoe_pos_limpa($p[$slot]) : '50% 50%';
}

/**
 * Campo de imagem com: tamanho ideal, prévia no formato real e ponto de foco (tocar/arrastar).
 * $posname vazio = sem ponto de foco (ex.: logo).
 */
function zoe_campo_img($name, $valor, $rotulo, $tipo = 'quadrado', $posname = '', $pos = '50% 50%')
{
    $specs = zoe_img_specs();
    $sp = isset($specs[$tipo]) ? $specs[$tipo] : $specs['quadrado'];
    $url = zoe_img($valor, 'medium_large');
    $pos = zoe_pos_limpa($pos);
    list($px, $py) = explode(' ', $pos);
    echo '<div class="zs-img" data-w="' . (int) $sp[0] . '" data-h="' . (int) $sp[1] . '"><span class="zs-rot">' . esc_html($rotulo) . '</span>';
    echo '<div class="zs-prev' . ($posname ? ' zs-foco' : '') . '" style="aspect-ratio:' . (int) $sp[0] . '/' . (int) $sp[1] . ';background-position:' . esc_attr($pos) . ($url ? ';background-image:url(' . esc_url($url) . ')' : '') . '">' . ($posname ? '<span class="zs-ponto" style="left:' . esc_attr($px) . ';top:' . esc_attr($py) . '"></span>' : '') . '</div>';
    echo '<input type="hidden" class="zs-val" name="' . esc_attr($name) . '" value="' . esc_attr($valor) . '">';
    if ($posname) {
        echo '<input type="hidden" class="zs-pos" name="' . esc_attr($posname) . '" value="' . esc_attr($pos) . '">';
    }
    echo '<span class="zs-spec">Ideal: ' . (int) $sp[0] . ' × ' . (int) $sp[1] . ' px · ' . esc_html($sp[2]) . '</span>';
    echo '<span class="zs-onde">' . esc_html($sp[3]) . ($posname ? ' Toque na foto para marcar o ponto que sempre aparece.' : '') . '</span>';
    echo '<span class="zs-aviso"></span>';
    echo '<button type="button" class="button zs-trocar">Trocar imagem</button></div>';
}

function zoe_pagina_opcoes()
{
    $o = function ($k) {
        return zoe_opt($k);
    };
    ?>
    <div class="wrap zs">
        <h1>Site Zoe</h1>
        <p class="description">Textos e imagens da página inicial, redes de células e contato. Use <code>*palavra*</code> para deixar uma palavra em itálico elegante.</p>
        <?php if (!empty($_GET['salvo'])) { echo '<div class="notice notice-success is-dismissible"><p>Site atualizado.</p></div>'; } // phpcs:ignore ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('zoe_site'); ?><input type="hidden" name="action" value="zoe_site">

            <div class="zs-card"><h2>Topo da página inicial</h2>
                <label>Título grande<input type="text" class="large-text" name="z[titulo]" value="<?php echo esc_attr($o('titulo')); ?>"></label>
                <label>Linha acima do título<input type="text" class="large-text" name="z[subtitulo]" value="<?php echo esc_attr($o('subtitulo')); ?>"></label>
                <label>Frase (computador)<textarea class="large-text" rows="2" name="z[frase]"><?php echo esc_textarea($o('frase')); ?></textarea></label>
                <div class="zs-imgs"><?php $h = (array) $o('hero'); for ($i = 0; $i < 3; $i++) { zoe_campo_img("z[hero][$i]", isset($h[$i]) ? $h[$i] : '', 'Foto ' . ($i + 1), 'hero', "z[pos][hero-$i]", zoe_pos("hero-$i")); } ?></div>
                <label>Faixa de texto que corre (uma frase por linha)<textarea class="large-text" rows="4" name="z[faixa]"><?php echo esc_textarea($o('faixa')); ?></textarea></label>
                <div class="zs-imgs"><?php zoe_campo_img('z[logo]', $o('logo'), 'Logo', 'logo'); ?></div>
            </div>

            <div class="zs-card"><h2>Nossa visão</h2>
                <label>Frase de destaque<textarea class="large-text" rows="2" name="z[visao_titulo]"><?php echo esc_textarea($o('visao_titulo')); ?></textarea></label>
                <label>Texto (deixe uma linha em branco entre os parágrafos)<textarea class="large-text" rows="8" name="z[visao]"><?php echo esc_textarea($o('visao')); ?></textarea></label>
                <h3>Pastores</h3>
                <div id="zs-pastores"><?php foreach ((array) $o('pastores') as $i => $p) { zoe_linha_pastor($i, $p); } ?></div>
                <p><button type="button" class="button zs-add" data-tpl="zs-tpl-pastor" data-alvo="zs-pastores">+ Adicionar pastores</button></p>
                <script type="text/template" id="zs-tpl-pastor"><?php zoe_linha_pastor('__i__', array()); ?></script>
            </div>

            <div class="zs-card"><h2>Tema do ano</h2>
                <label>Título<input type="text" class="large-text" name="z[ano_titulo]" value="<?php echo esc_attr($o('ano_titulo')); ?>"></label>
                <label>Versículo<textarea class="large-text" rows="2" name="z[ano_verso]"><?php echo esc_textarea($o('ano_verso')); ?></textarea></label>
                <label>Referência<input type="text" name="z[ano_ref]" value="<?php echo esc_attr($o('ano_ref')); ?>"></label>
                <label>Destaques (um por linha)<textarea class="large-text" rows="3" name="z[ano_itens]"><?php echo esc_textarea($o('ano_itens')); ?></textarea></label>
                <label>Frase<input type="text" class="large-text" name="z[ano_frase]" value="<?php echo esc_attr($o('ano_frase')); ?>"></label>
                <div class="zs-imgs"><?php zoe_campo_img('z[ano_img]', $o('ano_img'), 'Imagem do tema', 'quadrado', 'z[pos][ano]', zoe_pos('ano')); ?></div>
            </div>

            <div class="zs-card"><h2>Vida abundante</h2>
                <label>Título<input type="text" class="large-text" name="z[vida_titulo]" value="<?php echo esc_attr($o('vida_titulo')); ?>"></label>
                <label>Texto<textarea class="large-text" rows="6" name="z[vida_texto]"><?php echo esc_textarea($o('vida_texto')); ?></textarea></label>
                <div class="zs-g"><label>Versículo<input type="text" name="z[vida_verso]" value="<?php echo esc_attr($o('vida_verso')); ?>"></label>
                <label>Referência<input type="text" name="z[vida_ref]" value="<?php echo esc_attr($o('vida_ref')); ?>"></label></div>
                <div class="zs-imgs"><?php zoe_campo_img('z[vida_img]', $o('vida_img'), 'Foto', 'retrato', 'z[pos][vida]', zoe_pos('vida')); ?></div>
            </div>

            <div class="zs-card"><h2>Cultos</h2>
                <label>Horários (um por linha: <code>horário|descrição</code>)<textarea class="large-text" rows="3" name="z[cultos]"><?php echo esc_textarea($o('cultos')); ?></textarea></label>
                <label>Texto<textarea class="large-text" rows="2" name="z[cultos_txt]"><?php echo esc_textarea($o('cultos_txt')); ?></textarea></label>
            </div>

            <div class="zs-card"><h2>Células</h2>
                <div class="zs-imgs"><?php zoe_campo_img('z[cel_img]', $o('cel_img'), 'Foto da seção', 'retrato', 'z[pos][cel]', zoe_pos('cel')); ?></div>
                <label>Texto<textarea class="large-text" rows="3" name="z[cel_txt]"><?php echo esc_textarea($o('cel_txt')); ?></textarea></label>
                <label>O que acontece em uma reunião (um por linha)<textarea class="large-text" rows="6" name="z[reuniao]"><?php echo esc_textarea($o('reuniao')); ?></textarea></label>
                <div class="zs-g"><label>Versículo<input type="text" name="z[cel_verso]" value="<?php echo esc_attr($o('cel_verso')); ?>"></label>
                <label>Referência<input type="text" name="z[cel_ref]" value="<?php echo esc_attr($o('cel_ref')); ?>"></label></div>
                <h3>Redes de células <span class="description">(as ativas aparecem no site; tocando, mostra liderança, horário e WhatsApp)</span></h3>
                <p class="description">As células que aparecem na pergunta "Qual a sua célula?" das inscrições ficam em <a href="<?php echo esc_url(admin_url('admin.php?page=zoe-config')); ?>">Zoe Eventos → Configurações</a>.</p>
                <div id="zs-redes">
                    <?php foreach ((array) $o('redes') as $i => $r) { zoe_linha_rede($i, $r); } ?>
                </div>
                <p><button type="button" class="button zs-add" data-tpl="zs-tpl-rede" data-alvo="zs-redes">+ Adicionar rede</button></p>
                <script type="text/template" id="zs-tpl-rede"><?php zoe_linha_rede('__i__', array()); ?></script>
            </div>

            <div class="zs-card"><h2>Ministérios e projetos</h2>
                <p class="description">No campo <b>Leva para</b>, coloque o número (ID) do produto/evento, um link completo, ou <code>eventos</code> para a página de eventos. Vazio = sem link.</p>
                <div id="zs-min"><?php foreach ((array) $o('ministerios') as $i => $m) { zoe_linha_min($i, $m); } ?></div>
                <p><button type="button" class="button zs-add" data-tpl="zs-tpl-min" data-alvo="zs-min">+ Adicionar ministério</button></p>
                <script type="text/template" id="zs-tpl-min"><?php zoe_linha_min('__i__', array()); ?></script>
            </div>

            <div class="zs-card"><h2>Contribua</h2>
                <label>Texto<textarea class="large-text" rows="2" name="z[contrib_txt]"><?php echo esc_textarea($o('contrib_txt')); ?></textarea></label>
                <div class="zs-g"><label>CNPJ (exibido)<input type="text" name="z[cnpj]" value="<?php echo esc_attr($o('cnpj')); ?>"></label>
                <label>Chave PIX (copiada pelo botão)<input type="text" name="z[pix]" value="<?php echo esc_attr($o('pix')); ?>"></label></div>
                <label>Razão social<input type="text" class="large-text" name="z[razao]" value="<?php echo esc_attr($o('razao')); ?>"></label>
            </div>

            <div class="zs-card"><h2>Contato e redes sociais</h2>
                <label>Texto da seção Fale conosco<textarea class="large-text" rows="2" name="z[contato_txt]"><?php echo esc_textarea($o('contato_txt')); ?></textarea></label>
                <label>Endereço (rodapé)<input type="text" class="large-text" name="z[endereco]" value="<?php echo esc_attr($o('endereco')); ?>"></label>
                <div class="zs-g"><label>E-mail<input type="email" name="z[email]" value="<?php echo esc_attr($o('email')); ?>"></label>
                <label>WhatsApp da igreja (número ou link)<input type="text" name="z[whatsapp]" value="<?php echo esc_attr($o('whatsapp')); ?>" placeholder="(41) 99999-9999"></label></div>
                <div class="zs-g"><label>Instagram (link)<input type="url" name="z[instagram]" value="<?php echo esc_attr($o('instagram')); ?>"></label>
                <label>YouTube (link)<input type="url" name="z[youtube]" value="<?php echo esc_attr($o('youtube')); ?>"></label>
                <label>Facebook (link)<input type="url" name="z[facebook]" value="<?php echo esc_attr($o('facebook')); ?>"></label></div>
            </div>

            <p class="zs-salvar"><?php submit_button('Salvar e atualizar o site', 'primary large', 'submit', false); ?> <a class="button button-large" href="<?php echo esc_url(home_url('/')); ?>" target="_blank">Ver site</a></p>
        </form>
    </div>
    <style>
        .zs{max-width:980px}.zs-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:6px 22px 16px;margin:16px 0}
        .zs-card label{display:block;font-weight:600;margin:12px 0}.zs-card label input,.zs-card label textarea{display:block;margin-top:6px;font-weight:400;width:100%}
        .zs-g{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}@media(max-width:700px){.zs-g{grid-template-columns:1fr}}
        .zs-imgs{display:flex;flex-wrap:wrap;gap:16px;margin:10px 0}.zs-img{width:220px}.zs-rot{display:block;font-weight:600;margin-bottom:6px}
        .zs-prev{position:relative;max-height:240px;border-radius:6px;background:#f0f0f1 center/cover no-repeat;margin-bottom:6px;border:1px solid #dcdcde}
        .zs-foco{cursor:crosshair;touch-action:none;user-select:none}
        .zs-ponto{position:absolute;width:22px;height:22px;margin:-11px 0 0 -11px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 1.5px rgba(0,0,0,.55),0 2px 6px rgba(0,0,0,.3);pointer-events:none}
        .zs-spec{display:block;font-size:12px;font-weight:600;color:#1d2327}.zs-onde{display:block;font-size:12px;color:#646970;margin:2px 0 6px;line-height:1.4}
        .zs-aviso{display:none;background:#fcf0e1;color:#8a5300;border-radius:4px;padding:7px 9px;font-size:12px;line-height:1.4;margin-bottom:6px}.zs-aviso.on{display:block}
        .zs-rede{border:1px solid #e2e2e2;border-radius:6px;padding:4px 14px 12px;margin:10px 0;background:#fafafa}
        .zs-salvar{position:sticky;bottom:0;background:#f0f0f1;padding:12px 0;margin:0}
    </style>
    <script>
    jQuery(function($){
        function aviso(sw,sh,w,h){var m=[];if(!w)return '';if(w<sw*.7||h<sh*.7)m.push('A imagem tem '+w+' × '+h+' px; o ideal aqui é '+sw+' × '+sh+'. Pode ficar borrada.');var rs=sw/sh,ri=w/h;
            if(rs>1.2&&ri<.95)m.push('Ela é vertical e o espaço é horizontal: marque o ponto principal.');else if(rs<.9&&ri>1.15)m.push('Ela é horizontal e o espaço é vertical: marque o ponto principal.');else if(Math.abs(rs-1)<.05&&Math.abs(ri-1)>.3)m.push('O espaço é quadrado: parte da imagem será cortada. Marque o ponto principal.');return m.join(' ');}
        $(document).on('click','.zs-trocar',function(){var box=$(this).closest('.zs-img');var f=wp.media({title:'Escolher imagem',button:{text:'Usar esta imagem'},library:{type:'image'},multiple:false});
            f.on('select',function(){var a=f.state().get('selection').first().toJSON();box.find('.zs-val').val(a.id);box.find('.zs-prev').css({'background-image':'url('+(a.sizes&&a.sizes.medium_large?a.sizes.medium_large.url:a.url)+')','background-position':'50% 50%'});
                box.find('.zs-pos').val('50% 50%');box.find('.zs-ponto').css({left:'50%',top:'50%'});var t=aviso(+box.data('w'),+box.data('h'),a.width,a.height);box.find('.zs-aviso').text(t).toggleClass('on',!!t);});f.open()});
        // ponto de foco: tocar ou arrastar
        var arr=null;function mover(el,e){var r=el.getBoundingClientRect(),x=Math.round(Math.min(100,Math.max(0,(e.clientX-r.left)/r.width*100))),y=Math.round(Math.min(100,Math.max(0,(e.clientY-r.top)/r.height*100))),p=x+'% '+y+'%';
            $(el).css('background-position',p).find('.zs-ponto').css({left:x+'%',top:y+'%'});$(el).closest('.zs-img').find('.zs-pos').val(p);}
        $(document).on('pointerdown','.zs-foco',function(e){arr=this;this.setPointerCapture(e.originalEvent.pointerId);mover(this,e.originalEvent);});
        $(document).on('pointermove','.zs-foco',function(e){if(arr===this)mover(this,e.originalEvent);});
        $(document).on('pointerup pointercancel','.zs-foco',function(){arr=null;});
        var n=1000;
        $('.zs-add').on('click',function(){$('#'+$(this).data('alvo')).append($('#'+$(this).data('tpl')).html().replace(/__i__/g,n++))});
        $(document).on('click','.zs-del-rede',function(){$(this).closest('.zs-rede').remove()});
    });
    </script>
    <?php
}

function zoe_linha_pastor($i, $p)
{
    $p = wp_parse_args($p, array('nome' => '', 'cargo' => '', 'img' => '', 'pos' => '50% 50%'));
    $n = 'z[pastores][' . $i . ']';
    echo '<div class="zs-rede" style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">';
    zoe_campo_img($n . '[img]', $p['img'], 'Foto', 'pastor', $n . '[pos]', $p['pos']);
    echo '<div style="flex:1;min-width:220px"><label>Nome<input type="text" name="' . esc_attr($n) . '[nome]" value="' . esc_attr($p['nome']) . '"></label>';
    echo '<label>Cargo<input type="text" name="' . esc_attr($n) . '[cargo]" value="' . esc_attr($p['cargo']) . '" placeholder="Pastores"></label>';
    echo '<button type="button" class="button-link-delete zs-del-rede">Remover</button></div></div>';
}

function zoe_linha_min($i, $m)
{
    $m = wp_parse_args($m, array('nome' => '', 'txt' => '', 'link' => ''));
    $n = 'z[ministerios][' . $i . ']';
    echo '<div class="zs-rede"><div class="zs-g">';
    echo '<label>Nome<input type="text" name="' . esc_attr($n) . '[nome]" value="' . esc_attr($m['nome']) . '"></label>';
    echo '<label>Leva para<input type="text" name="' . esc_attr($n) . '[link]" value="' . esc_attr($m['link']) . '" placeholder="ID do evento, link ou eventos"></label></div>';
    echo '<label>Texto<textarea rows="2" name="' . esc_attr($n) . '[txt]">' . esc_textarea($m['txt']) . '</textarea></label>';
    echo '<button type="button" class="button-link-delete zs-del-rede">Remover</button></div>';
}

/** Resolve o link de um ministério: ID de produto publicado, URL completa ou "eventos". */
function zoe_link_min($v)
{
    $v = trim((string) $v);
    if ($v === '') {
        return '';
    }
    if ($v === 'eventos') {
        return zoe_url_eventos();
    }
    if (ctype_digit($v)) {
        return get_post_status((int) $v) === 'publish' ? get_permalink((int) $v) : '';
    }
    return esc_url_raw($v);
}

/** Link de WhatsApp a partir de um número ou de um link pronto. */
function zoe_link_whats($v)
{
    $v = trim((string) $v);
    if ($v === '') {
        return '';
    }
    return preg_match('#^https?://#', $v) ? $v : 'https://wa.me/55' . preg_replace('/\D/', '', $v);
}

/** Parágrafos separados por linha em branco. */
function zoe_paragrafos($txt)
{
    $out = '';
    foreach (preg_split('/\n\s*\n/', trim((string) $txt)) as $p) {
        if (trim($p) !== '') {
            $out .= '<p>' . nl2br(esc_html(trim($p))) . '</p>';
        }
    }
    return $out;
}

function zoe_linha_rede($i, $r)
{
    $r = wp_parse_args($r, array('nome' => '', 'lider' => '', 'dia' => '', 'bairro' => '', 'contatos' => '', 'desc' => '', 'ativa' => 1));
    $n = 'z[redes][' . $i . ']';
    echo '<div class="zs-rede"><p style="margin:8px 0 0"><label style="display:inline;font-weight:600"><input type="hidden" name="' . esc_attr($n) . '[ativa]" value="0"><input type="checkbox" name="' . esc_attr($n) . '[ativa]" value="1"' . checked(!empty($r['ativa']), true, false) . ' style="width:auto;display:inline;margin:0 6px 0 0"> Ativa (aparece no site)</label></p><div class="zs-g">';
    echo '<label>Nome da rede<input type="text" name="' . esc_attr($n) . '[nome]" value="' . esc_attr($r['nome']) . '"></label>';
    echo '<label>Liderança<input type="text" name="' . esc_attr($n) . '[lider]" value="' . esc_attr($r['lider']) . '"></label>';
    echo '<label>Dia e horário<input type="text" name="' . esc_attr($n) . '[dia]" value="' . esc_attr($r['dia']) . '"></label>';
    echo '<label>Bairro / local<input type="text" name="' . esc_attr($n) . '[bairro]" value="' . esc_attr($r['bairro']) . '"></label></div>';
    echo '<label>Contatos (um por linha: Nome — telefone)<textarea rows="2" name="' . esc_attr($n) . '[contatos]">' . esc_textarea($r['contatos']) . '</textarea></label>';
    echo '<label>Descrição (opcional)<textarea rows="2" name="' . esc_attr($n) . '[desc]">' . esc_textarea($r['desc']) . '</textarea></label>';
    echo '<button type="button" class="button-link-delete zs-del-rede" onclick="return confirm(\'Remover esta rede de vez? Para só esconder do site, desmarque Ativa.\')">Remover rede</button></div>';
}

add_action('admin_post_zoe_site', function () {
    if (!current_user_can('edit_pages') || !check_admin_referer('zoe_site')) {
        wp_die('Sem permissão.');
    }
    $in  = isset($_POST['z']) && is_array($_POST['z']) ? wp_unslash($_POST['z']) : array(); // phpcs:ignore
    $out = array();
    foreach (array('titulo', 'subtitulo', 'cnpj', 'pix', 'razao', 'endereco', 'whatsapp', 'ano_titulo', 'ano_ref', 'ano_frase', 'vida_titulo', 'vida_verso', 'vida_ref', 'cel_verso', 'cel_ref') as $k) {
        $out[$k] = isset($in[$k]) ? sanitize_text_field($in[$k]) : '';
    }
    foreach (array('frase', 'faixa', 'visao_titulo', 'visao', 'ano_verso', 'ano_itens', 'vida_texto', 'reuniao', 'cultos', 'cultos_txt', 'cel_txt', 'contrib_txt', 'contato_txt') as $k) {
        $out[$k] = isset($in[$k]) ? sanitize_textarea_field($in[$k]) : '';
    }
    $out['email']     = isset($in['email']) ? sanitize_email($in['email']) : '';
    $out['instagram'] = isset($in['instagram']) ? esc_url_raw($in['instagram']) : '';
    $out['youtube']   = isset($in['youtube']) ? esc_url_raw($in['youtube']) : '';
    $out['facebook']  = isset($in['facebook']) ? esc_url_raw($in['facebook']) : '';
    $img = function ($v) {
        return is_numeric($v) ? absint($v) : esc_url_raw((string) $v);
    };
    $out['logo']    = $img(isset($in['logo']) ? $in['logo'] : '');
    $out['cel_img'] = $img(isset($in['cel_img']) ? $in['cel_img'] : '');
    $out['ano_img'] = $img(isset($in['ano_img']) ? $in['ano_img'] : '');
    $out['vida_img'] = $img(isset($in['vida_img']) ? $in['vida_img'] : '');
    $out['pastores'] = array();
    foreach ((array) (isset($in['pastores']) ? $in['pastores'] : array()) as $p) {
        if (is_array($p) && trim((string) (isset($p['nome']) ? $p['nome'] : '')) !== '') {
            $out['pastores'][] = array('nome' => sanitize_text_field($p['nome']), 'cargo' => sanitize_text_field(isset($p['cargo']) ? $p['cargo'] : ''), 'img' => $img(isset($p['img']) ? $p['img'] : ''), 'pos' => zoe_pos_limpa(isset($p['pos']) ? $p['pos'] : ''));
        }
    }
    $out['ministerios'] = array();
    foreach ((array) (isset($in['ministerios']) ? $in['ministerios'] : array()) as $m) {
        if (is_array($m) && trim((string) (isset($m['nome']) ? $m['nome'] : '')) !== '') {
            $out['ministerios'][] = array('nome' => sanitize_text_field($m['nome']), 'txt' => sanitize_textarea_field(isset($m['txt']) ? $m['txt'] : ''), 'link' => sanitize_text_field(isset($m['link']) ? $m['link'] : ''));
        }
    }
    $out['hero']    = array_map($img, array_values((array) (isset($in['hero']) ? $in['hero'] : array())));
    $out['pos'] = array();
    foreach ((array) (isset($in['pos']) ? $in['pos'] : array()) as $k => $v) {
        $out['pos'][sanitize_key($k)] = zoe_pos_limpa($v);
    }
    $out['redes']   = array();
    foreach ((array) (isset($in['redes']) ? $in['redes'] : array()) as $r) {
        if (!is_array($r) || trim((string) (isset($r['nome']) ? $r['nome'] : '')) === '') {
            continue;
        }
        $out['redes'][] = array(
            'nome'     => sanitize_text_field($r['nome']),
            'lider'    => sanitize_text_field(isset($r['lider']) ? $r['lider'] : ''),
            'dia'      => sanitize_text_field(isset($r['dia']) ? $r['dia'] : ''),
            'bairro'   => sanitize_text_field(isset($r['bairro']) ? $r['bairro'] : ''),
            'contatos' => sanitize_textarea_field(isset($r['contatos']) ? $r['contatos'] : ''),
            'desc'     => sanitize_textarea_field(isset($r['desc']) ? $r['desc'] : ''),
            'ativa'    => !isset($r['ativa']) || !empty($r['ativa']) ? 1 : 0,
        );
    }
    update_option('zoe_site', $out);
    do_action('litespeed_purge_all');
    wp_safe_redirect(admin_url('admin.php?page=zoe-site&salvo=1'));
    exit;
});


/**
 * 1.2.8: a seção "Vida abundante" (foto do casal com a bolsa de líder de célula) passa a falar de células.
 * Só troca se o texto ainda for o antigo; se alguém já editou no painel, fica como está.
 */
add_action('init', function () {
    if (get_option('zoe_mig_vida_celulas')) {
        return;
    }
    update_option('zoe_mig_vida_celulas', 1, false);
    $o = get_option('zoe_site', array());
    if (!is_array($o)) {
        return;
    }
    $p     = zoe_padroes();
    $mudou = false;
    $antigos = array(
        'vida_titulo' => 'abundante',
        'vida_texto'  => 'vida abundante',
        'vida_verso'  => 'tenham vida',
        'vida_ref'    => 'João 10:10',
    );
    foreach ($antigos as $k => $marca) {
        if (!isset($o[$k]) || $o[$k] === '' || strpos((string) $o[$k], $marca) !== false) {
            $o[$k] = $p[$k];
            $mudou = true;
        }
    }
    if ($mudou) {
        update_option('zoe_site', $o);
        do_action('litespeed_purge_all');
    }
}, 20);
