<?php
/**
 * Inscrições em tempo real numa planilha do Google.
 *
 * Um Apps Script colado na planilha recebe as inscrições (doPost) e grava na aba
 * "Site (automático)". Aqui o site manda, assim que o pagamento é aprovado, uma linha
 * por pessoa inscrita; estorno/cancelamento manda a mudança de situação.
 * Configuração: option zoe_planilha = {url, token, eventos[], ativo}.
 */
if (!defined('ABSPATH')) {
    exit;
}

function zoe_plan_opcoes()
{
    $o = get_option('zoe_planilha', array());
    return wp_parse_args(is_array($o) ? $o : array(), array('url' => '', 'token' => '', 'eventos' => array(), 'ativo' => 0));
}

function zoe_plan_ativa()
{
    $o = zoe_plan_opcoes();
    return $o['ativo'] && $o['url'] && $o['token'];
}

/** O pedido tem algum dos eventos da planilha? */
function zoe_plan_do_pedido($order)
{
    $evs = array_map('intval', (array) zoe_plan_opcoes()['eventos']);
    foreach ($order->get_items() as $it) {
        if (is_a($it, 'WC_Order_Item_Product') && (!$evs || in_array((int) $it->get_product_id(), $evs, true))) {
            return true;
        }
    }
    return false;
}

/** Linhas (uma por pessoa) dos pedidos informados, no formato da planilha. */
function zoe_plan_linhas($ids)
{
    $o = zoe_plan_opcoes();
    $GLOBALS['zoe_rel_so_pedidos'] = array_map('intval', (array) $ids);
    $d = zoe_rel_dados('todos', $o['eventos'] ? array_map('intval', $o['eventos']) : 0);
    $GLOBALS['zoe_rel_so_pedidos'] = null;
    // Nomes dos ingressos (inclui os nomes dados depois pela equipe às vagas sem nome).
    $nomesIng = array();
    if (function_exists('zoe_ci_ingressos')) {
        foreach ((array) $ids as $oid) {
            $ord = wc_get_order($oid);
            if ($ord) {
                foreach (zoe_ci_ingressos($ord) as $i) {
                    $nomesIng[$ord->get_order_number() . '|' . $i['pid'] . '|' . $i['vaga']] = $i['nome'];
                }
            }
        }
    }
    $out = array();
    foreach ($d['eventos'] as $ev) {
        foreach ($ev['linhas'] as $l) {
            $vaga = (int) strtok((string) $l['Inscrição'], ' ');
            $k = $l['Pedido'] . '|' . $ev['id'] . '|' . $vaga;
            $nome = isset($l['Nome completo']) ? trim((string) $l['Nome completo']) : '';
            if (isset($nomesIng[$k]) && ($nome === '' || strpos($nomesIng[$k], 'Vaga ') !== 0)) {
                $nome = $nomesIng[$k];
            }
            if ($nome === '') {
                $nome = 'Vaga ' . $l['Inscrição'] . ' · pedido de ' . ($l['Pagador'] ? $l['Pagador'] : $l['Pedido']);
            }
            $contato = '';
            foreach (array('WhatsApp', 'WhatsApp do responsável', 'Contato do responsável', 'Telefone') as $c) {
                if (!empty($l[$c]) && preg_match('/\d{8,}/', preg_replace('/\D/', '', (string) $l[$c]))) {
                    $contato = (string) $l[$c];
                    break;
                }
            }
            $resp = '';
            foreach (array('Nome do responsável', 'Responsável') as $c) {
                if (!empty($l[$c])) {
                    $resp = (string) $l[$c];
                    break;
                }
            }
            $evNome = $ev['nome'] . (!empty($l['Turma']) ? ' · ' . $l['Turma'] : '');
            $out[] = array(
                'chave'   => $k,
                'data'    => $l['Data'],
                'evento'  => $evNome,
                'nome'    => $nome,
                'rede'    => isset($l['Rede / célula']) ? (string) $l['Rede / célula'] : '',
                'lider'   => isset($l['Líder']) ? (string) $l['Líder'] : '',
                'contato' => $contato,
                'email'   => (string) $l['E-mail'],
                'pedido'  => (string) $l['Pedido'],
                'vaga'    => (string) $l['Inscrição'],
                'idade'   => isset($l['Idade']) ? (string) $l['Idade'] : '',
                'resp'    => $resp,
                'status'  => (string) $l['Status'],
            );
        }
    }
    // Vagas extras do formulário antigo: contato e e-mail de quem fez o pedido.
    $prim = array();
    foreach ($out as $r) {
        foreach (array('email', 'contato') as $c) {
            if ($r[$c] !== '' && !isset($prim[$r['pedido']][$c])) {
                $prim[$r['pedido']][$c] = $r[$c];
            }
        }
    }
    foreach ($out as &$r) {
        foreach (array('email', 'contato') as $c) {
            if ($r[$c] === '' && isset($prim[$r['pedido']][$c])) {
                $r[$c] = $prim[$r['pedido']][$c];
            }
        }
    }
    unset($r);
    return $out;
}

/** Manda para o Apps Script. Retorna array com ok e a resposta. */
function zoe_plan_post($dados)
{
    $o = zoe_plan_opcoes();
    if (!$o['url'] || !$o['token']) {
        return array('ok' => false, 'erro' => 'Planilha não configurada');
    }
    $dados['token'] = $o['token'];
    $r = wp_remote_post($o['url'], array(
        'timeout' => 25,
        'redirection' => 5,
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode($dados),
    ));
    if (is_wp_error($r)) {
        return array('ok' => false, 'erro' => $r->get_error_message());
    }
    $cod = (int) wp_remote_retrieve_response_code($r);
    $res = json_decode(wp_remote_retrieve_body($r), true);
    if ($cod >= 200 && $cod < 400 && is_array($res) && !empty($res['ok'])) {
        return array('ok' => true) + $res;
    }
    return array('ok' => false, 'erro' => 'HTTP ' . $cod . ': ' . mb_substr(wp_strip_all_tags(wp_remote_retrieve_body($r)), 0, 200));
}

/** Fila de envios que falharam (tenta de novo no próximo envio). */
function zoe_plan_fila_add($item)
{
    $f = get_option('zoe_planilha_fila', array());
    $f = is_array($f) ? $f : array();
    $f[] = $item;
    update_option('zoe_planilha_fila', array_slice($f, -200), false);
}

function zoe_plan_processar($pedidos)
{
    $fila = get_option('zoe_planilha_fila', array());
    $fila = is_array($fila) ? $fila : array();
    delete_option('zoe_planilha_fila');
    foreach ($fila as $f) {
        $pedidos[(int) $f['pedido']] = $f['tipo'];
    }
    foreach ($pedidos as $oid => $tipo) {
        $o = wc_get_order($oid);
        if (!$o) {
            continue;
        }
        if ($tipo === 'pago') {
            $linhas = zoe_plan_linhas(array($oid));
            $r = $linhas ? zoe_plan_post(array('acao' => 'linhas', 'linhas' => $linhas)) : array('ok' => true);
        } else {
            $r = zoe_plan_post(array('acao' => 'status', 'pedido' => (string) $o->get_order_number(), 'status' => wc_get_order_status_name($o->get_status())));
        }
        if (empty($r['ok'])) {
            zoe_plan_fila_add(array('pedido' => $oid, 'tipo' => $tipo));
            update_option('zoe_planilha_erro', array('t' => time(), 'msg' => isset($r['erro']) ? $r['erro'] : 'erro'), false);
        }
    }
}

// Pagamento aprovado / estorno / cancelamento: guarda e manda no fim da requisição
// (depois de responder ao Mercado Pago, para não atrasar a confirmação do pagamento).
add_action('woocommerce_order_status_changed', function ($oid, $de, $para, $order) {
    if (!zoe_plan_ativa() || !is_a($order, 'WC_Order') || !zoe_plan_do_pedido($order)) {
        return;
    }
    $pagos = array('processing', 'completed');
    if (in_array($para, $pagos, true) && !in_array($de, $pagos, true)) {
        $tipo = 'pago';
    } elseif (in_array($para, array('refunded', 'cancelled', 'failed'), true) && in_array($de, array_merge($pagos, array('on-hold')), true)) {
        $tipo = 'status';
    } else {
        return;
    }
    static $registrado = false;
    $GLOBALS['zoe_plan_pend'][(int) $oid] = $tipo;
    if (!$registrado) {
        $registrado = true;
        add_action('shutdown', function () {
            if (function_exists('litespeed_finish_request')) {
                litespeed_finish_request();
            } elseif (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            zoe_plan_processar((array) $GLOBALS['zoe_plan_pend']);
        }, 99);
    }
}, 20, 4);

/** Manda todas as inscrições pagas atuais (sem destaque: são as que já existiam). */
function zoe_plan_sincronizar($offset = 0, $lote = 40)
{
    $o = zoe_plan_opcoes();
    $args = array('type' => 'shop_order', 'status' => array('wc-completed', 'wc-processing'), 'limit' => -1, 'return' => 'ids', 'orderby' => 'date', 'order' => 'DESC');
    $ids = wc_get_orders($args);
    if ($o['eventos']) {
        global $wpdb;
        $evs = array_map('intval', $o['eventos']);
        $marcas = implode(',', array_fill(0, count($evs), '%d'));
        $com = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
             JOIN {$wpdb->prefix}woocommerce_order_itemmeta im ON im.order_item_id = oi.order_item_id
             WHERE oi.order_item_type = 'line_item' AND im.meta_key = '_product_id' AND im.meta_value IN ($marcas)", // phpcs:ignore
            $evs
        ));
        $ids = array_values(array_intersect($ids, array_map('intval', $com)));
    }
    // Só a edição atual de cada evento (data de início do check-in, quando houver).
    $ids = array_values(array_filter($ids, function ($id) {
        $ord = wc_get_order($id);
        return $ord && (!function_exists('zoe_ci_ingressos') || zoe_ci_ingressos($ord) || !zoe_ci_eventos_ativos());
    }));
    $parte = array_slice($ids, $offset, $lote);
    $linhas = $parte ? zoe_plan_linhas($parte) : array();
    // Mais recentes primeiro (a planilha acrescenta as já existentes embaixo, nessa ordem).
    usort($linhas, function ($a, $b) {
        return ((int) $b['pedido'] - (int) $a['pedido']) ?: strnatcmp($a['vaga'], $b['vaga']);
    });
    $r = $linhas ? zoe_plan_post(array('acao' => 'linhas', 'inicial' => true, 'linhas' => $linhas)) : array('ok' => true);
    return array('ok' => !empty($r['ok']), 'pedidos' => count($parte), 'linhas' => count($linhas), 'proximo' => $offset + $lote < count($ids) ? $offset + $lote : null, 'total_pedidos' => count($ids), 'resposta' => $r);
}
