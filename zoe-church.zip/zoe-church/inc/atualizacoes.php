<?php
/**
 * Atualização automática do tema, estilo loja oficial do WordPress.
 *
 * O site confere ~2x por dia o arquivo tema.json no GitHub da igreja
 * (repositório público zoe-tema). Se a versão de lá for mais nova,
 * o WordPress baixa o zip e instala sozinho, sem ninguém enviar arquivo.
 * Para conferir na hora: Painel do WordPress → Atualizações → "Verificar novamente".
 */
if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_TEMA_JSON', 'https://raw.githubusercontent.com/ElielsFerreira/zoe-tema/main/tema.json');

/**
 * Lê o tema.json do GitHub (guardado por 5 min para não pesar).
 * Com $fresca = true, ignora qualquer cache (o nosso e o do GitHub):
 * busca com um carimbo único na URL e grava o resultado por cima.
 */
function zoe_atual_info($fresca = false)
{
    if (!$fresca) {
        $info = get_site_transient('zoe_tema_info');
        if (is_array($info)) {
            return $info;
        }
    }
    $r = null;
    if ($fresca) {
        // A API do GitHub responde sempre com o arquivo atual (o endereço "raw" fica até 5 min em cache).
        $r = wp_remote_get('https://api.github.com/repos/ElielsFerreira/zoe-tema/contents/tema.json?ref=main', array(
            'timeout' => 10,
            'headers' => array('Accept' => 'application/vnd.github.raw', 'User-Agent' => 'zoe-church'),
        ));
        if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) {
            $r = null; // limite da API atingido ou fora do ar: usa o endereço normal
        }
    }
    if ($r === null) {
        $r = wp_remote_get(ZOE_TEMA_JSON, array('timeout' => 10));
    }
    if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) {
        set_site_transient('zoe_tema_info', array(), 5 * MINUTE_IN_SECONDS); // tenta de novo em 5 min
        return array();
    }
    $info = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($info) || empty($info['version']) || empty($info['package'])) {
        $info = array();
    }
    set_site_transient('zoe_tema_info', $info, 5 * MINUTE_IN_SECONDS);
    return $info;
}

// O WordPress chama este filtro quando confere atualizações de temas
// (o nome vem do domínio do "Update URI" no style.css).
add_filter('update_themes_raw.githubusercontent.com', function ($update, $theme_data, $stylesheet) {
    if ($stylesheet !== 'zoe-church') {
        return $update;
    }
    $info = zoe_atual_info();
    if (!$info) {
        return $update;
    }
    return array(
        'theme'        => 'zoe-church',
        'new_version'  => $info['version'],
        'url'          => isset($info['url']) ? $info['url'] : 'https://github.com/ElielsFerreira/zoe-tema',
        'package'      => $info['package'],
        'requires'     => isset($info['requires']) ? $info['requires'] : '6.1',
        'requires_php' => isset($info['requires_php']) ? $info['requires_php'] : '7.4',
    );
}, 10, 3);

// Instala sozinho, sem esperar ninguém clicar.
add_filter('auto_update_theme', function ($update, $item) {
    if (is_object($item) && isset($item->theme) && $item->theme === 'zoe-church') {
        return true;
    }
    return $update;
}, 10, 2);

// Ao trocar de versão, limpa os caches para o site já servir o tema novo.
add_action('upgrader_process_complete', function ($upgrader, $extra) {
    if (isset($extra['type']) && 'theme' === $extra['type']) {
        delete_site_transient('zoe_tema_info');
        if (function_exists('do_action')) {
            do_action('litespeed_purge_all');
        }
    }
}, 10, 2);
