/* Painel Zoe — administração no estilo do protótipo, ligada aos dados reais do site (API zoe/v1). */
(function () {
'use strict';
var E = ZP.eventos, O = ZP.opc, C = ZP.celulas, COFF = ZP.celulasOff, R = ZP.rel, ST = ZP.stats;

/* ---------- utilidades ---------- */
var $ = function (s, c) { return (c || document).querySelector(s); };
var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
var dataBR = function (d) { return d ? d.split('-').reverse().join('/') : '—'; };
var lin = function (t) { return String(t || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean); };
var ICONES = {"painel": "<rect x=\"3.5\" y=\"3.5\" width=\"7\" height=\"9\" rx=\"1.5\"/><rect x=\"13.5\" y=\"3.5\" width=\"7\" height=\"5\" rx=\"1.5\"/><rect x=\"13.5\" y=\"11.5\" width=\"7\" height=\"9\" rx=\"1.5\"/><rect x=\"3.5\" y=\"15.5\" width=\"7\" height=\"5\" rx=\"1.5\"/>", "calendario": "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"15.5\" rx=\"2\"/><path d=\"M3.5 10h17M8 3v4M16 3v4\"/>", "mais": "<path d=\"M12 5v14M5 12h14\"/>", "pessoas": "<circle cx=\"9\" cy=\"8.5\" r=\"3.2\"/><path d=\"M3.5 19.5c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5\"/><path d=\"M15.5 5.6a3 3 0 0 1 0 5.8M17.5 14.8c1.7.6 2.7 2.2 3 4.7\"/>", "imagem": "<rect x=\"3.5\" y=\"4.5\" width=\"17\" height=\"15\" rx=\"2\"/><circle cx=\"9\" cy=\"10\" r=\"1.6\"/><path d=\"m4 18 5-5 4 4 2.5-2.5L20 19\"/>", "planilha": "<path d=\"M6 3.5h8.5L19 8v12.5H6z\"/><path d=\"M14.5 3.5V8H19\"/><path d=\"M9.5 17v-3M12.5 17v-5M15.5 17v-2\"/>", "texto": "<path d=\"M5 7V5h14v2M12 5v14M9.5 19h5\"/>", "casa": "<path d=\"M4 10.5 12 4l8 6.5\"/><path d=\"M6 9v11h12V9\"/><path d=\"M10 20v-5.5h4V20\"/>", "externo": "<path d=\"M14 4h6v6M20 4l-9 9\"/><path d=\"M18 14v5.5H4.5V6H10\"/>", "sair": "<path d=\"M14 4.5H6.5v15H14\"/><path d=\"M10.5 12H20M16.5 8.5 20 12l-3.5 3.5\"/>", "lapis": "<path d=\"M4.5 19.5 5.5 15 15.8 4.7a2 2 0 0 1 2.8 0l.7.7a2 2 0 0 1 0 2.8L9 18.5z\"/><path d=\"m13.5 7 3.5 3.5\"/>", "baixar": "<path d=\"M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19.5h14\"/>", "envelope": "<rect x=\"3.5\" y=\"5.5\" width=\"17\" height=\"13\" rx=\"2\"/><path d=\"m4 7 8 6 8-6\"/>", "camera": "<path d=\"M4 8.5h3.5L9 6h6l1.5 2.5H20v11H4z\"/><circle cx=\"12\" cy=\"13.5\" r=\"3.3\"/>", "olho": "<path d=\"M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z\"/><circle cx=\"12\" cy=\"12\" r=\"2.8\"/>", "fechar": "<path d=\"M6 6l12 12M18 6 6 18\"/>", "menu": "<path d=\"M4 8h16M4 16h16\"/>", "check": "<path d=\"m5 12.5 4.5 4.5L19 7.5\"/>", "lista": "<path d=\"M9 6.5h11M9 12h11M9 17.5h11M4.5 6.5h.5M4.5 12h.5M4.5 17.5h.5\"/>", "estrela": "<path d=\"m12 3.8 2.5 5.1 5.6.8-4 3.9 1 5.6-5.1-2.7-5 2.7 1-5.6-4.1-3.9 5.6-.8z\"/>", "engrenagem": "<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8\"/>"};
var ic = function (n) { return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (ICONES[n] || '') + '</svg>'; };
var fallback = "this.onerror=null;this.style.visibility='hidden'";
var img = function (src, cls, pos) { return src ? '<img src="' + esc(src) + '" class="' + (cls || '') + '" alt="" loading="lazy"' + (pos && pos !== '50% 50%' ? ' style="object-position:' + esc(pos) + '"' : '') + ' onerror="' + fallback + '">' : '<span class="' + (cls || '') + ' sem-img"></span>'; };
function toast(m) { var t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove('on'); }, 2800); }
function api(path, opt) {
  opt = opt || {};
  var o = { credentials: 'same-origin', method: opt.method || (opt.json !== undefined || opt.body ? 'POST' : 'GET'), headers: { 'X-WP-Nonce': ZP.nonce } };
  if (opt.json !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opt.json); }
  if (opt.body) o.body = opt.body;
  return fetch(ZP.api + path, o).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.message || 'Não deu certo. Tente de novo.'); return j; });
  });
}
var erro = function (e) { toast(e && e.message ? e.message : 'Não deu certo. Tente de novo.'); };
var getEv = function (id) { return E.filter(function (e) { return e.id == id; })[0]; };
var trocaEv = function (ev) { var i = E.findIndex(function (x) { return x.id == ev.id; }); if (i >= 0) E[i] = ev; else E.unshift(ev); };
var SPEC = function (k) { var s = ZP.specs[k]; return { w: s[0], h: s[1], f: s[2], onde: s[3] }; };

/* ---------- campos do formulário (prévia) ---------- */
function camposDoForm(f) {
  var out = [];
  (f.blocos || []).forEach(function (b) {
    var B = ZP.bib[b]; if (!B) return;
    Object.keys(B.campos).forEach(function (k) {
      var d = B.campos[k], c = { k: k, l: d.l, tp: d.tp, r: d.r, op: k === 'celula' ? C.filter(function (x) { return COFF.indexOf(x) < 0; }) : d.op, dep: d.dep };
      if ((f.opcionais || []).indexOf(b) >= 0 && !d.dep) c.r = false;
      out.push(c);
    });
  });
  (f.custom || []).forEach(function (c, i) { if (!c.label) return; out.push({ k: 'p' + (i + 1), l: c.label, tp: c.type, r: !!+c.req, op: c.type === 'select' ? String(c.options || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean) : null }); });
  return out;
}
function campoHTML(c, name) {
  var dep = c.dep ? ' data-dep="' + c.dep[0] + '" data-val="' + esc(c.dep[1]) + '"' : '';
  var lab = '<label>' + esc(c.l) + ' ' + (c.r ? '<span class="req">*</span>' : '<span class="opc">(opcional)</span>') + '</label>', inp;
  if (c.tp === 'textarea') inp = '<textarea name="' + name + '" rows="2"></textarea>';
  else if (c.tp === 'select') inp = '<select name="' + name + '"><option value="">Selecione…</option>' + (c.op || []).map(function (o) { return '<option>' + esc(o) + '</option>'; }).join('') + '</select>';
  else if (c.tp === 'simnao') inp = '<div class="radios">' + ['Sim', 'Não'].map(function (o) { return '<label><input type="radio" name="' + name + '" value="' + o + '"> ' + o + '</label>'; }).join('') + '</div>';
  else inp = '<input type="' + (['tel', 'email', 'number', 'date'].indexOf(c.tp) >= 0 ? c.tp : 'text') + '" name="' + name + '">';
  return '<div class="campo" data-k="' + c.k + '"' + dep + '>' + lab + inp + '</div>';
}
function ligarDeps(root) {
  var upd = function (bl) { $$('[data-dep]', bl).forEach(function (d) { var src = $('[data-k="' + d.dataset.dep + '"]', bl), v = ''; if (src) { var r = $('input:checked', src); v = r ? r.value : (($('select,input,textarea', src) || {}).value || ''); } d.style.display = v === d.dataset.val ? '' : 'none'; }); };
  $$('.grupo-dep', root).forEach(function (bl) { upd(bl); bl.addEventListener('change', function () { upd(bl); }); });
}

/* ---------- imagens: escolher, enviar, ponto de foco ---------- */
function escolherImg(max, png, cb) {
  var f = $('#arquivo'); f.value = '';
  f.onchange = function () {
    var a = f.files[0]; if (!a) return;
    var rd = new FileReader();
    rd.onload = function () {
      var im = new Image();
      im.onload = function () {
        var s = Math.min(1, max / Math.max(im.width, im.height)), cv = document.createElement('canvas');
        cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s);
        cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
        var tipo = png || a.type === 'image/png' ? 'image/png' : 'image/jpeg';
        cv.toBlob(function (blob) {
          var fd = new FormData(); fd.append('arquivo', blob, (a.name || 'imagem').replace(/\.[^.]+$/, '') + (tipo === 'image/png' ? '.png' : '.jpg'));
          toast('Enviando imagem…');
          api('upload', { body: fd }).then(function (r) { cb(r, im.width, im.height); }).catch(erro);
        }, tipo, 0.86);
      };
      im.src = rd.result;
    };
    rd.readAsDataURL(a);
  };
  f.click();
}
function avisoTamanho(sp, w, h) {
  if (!sp || !w) return ''; var m = [];
  if (w < sp.w * .7 || h < sp.h * .7) m.push('A foto enviada tem ' + w + ' × ' + h + ' px. O ideal aqui é ' + sp.w + ' × ' + sp.h + ': ela pode ficar borrada.');
  var rs = sp.w / sp.h, ri = w / h;
  if (rs > 1.2 && ri < .95) m.push('Esta foto é vertical e aqui o espaço é horizontal: parte de cima e de baixo será cortada. Marque o ponto principal.');
  else if (rs < .9 && ri > 1.15) m.push('Esta foto é horizontal e aqui o espaço é vertical: as laterais serão cortadas. Marque o ponto principal.');
  else if (Math.abs(rs - 1) < .05 && Math.abs(ri - 1) > .3) m.push('Aqui o espaço é quadrado: parte da foto será cortada. Marque o ponto principal.');
  return m.join(' ');
}
function focoHTML(src, pos, ratio, id) {
  pos = pos || '50% 50%'; var xy = pos.split(' ');
  return '<div class="foco" id="' + id + '" style="aspect-ratio:' + ratio + ';' + (src ? "background-image:url('" + esc(src).replace(/'/g, '%27') + "');" : '') + 'background-position:' + pos + '"><span class="ponto" style="left:' + xy[0] + ';top:' + xy[1] + '"></span></div>';
}
function ligarFoco(id, salvarPos) {
  var el = document.getElementById(id); if (!el) return; var arr = false;
  var mv = function (ev) { var r = el.getBoundingClientRect(); var x = Math.round(Math.min(100, Math.max(0, (ev.clientX - r.left) / r.width * 100))), y = Math.round(Math.min(100, Math.max(0, (ev.clientY - r.top) / r.height * 100))); var p = x + '% ' + y + '%'; el.style.backgroundPosition = p; var d = $('.ponto', el); d.style.left = x + '%'; d.style.top = y + '%'; return p; };
  el.addEventListener('pointerdown', function (ev) { arr = true; el.setPointerCapture(ev.pointerId); mv(ev); });
  el.addEventListener('pointermove', function (ev) { if (arr) mv(ev); });
  el.addEventListener('pointerup', function (ev) { if (!arr) return; arr = false; salvarPos(mv(ev)); });
}

/* ---------- salvar textos do site (automático) ---------- */
var pend = {}, pendT = 0;
function salvarSite(k, v, agora) {
  if (!ZP.podeSite) { toast('Sua conta não pode mudar os textos do site.'); return Promise.resolve(); }
  pend[k] = v; clearTimeout(pendT);
  var vai = function () { var d = pend; pend = {}; return api('site', { json: { dados: d } }).then(function (r) { if (r.opc) { var guarda = O; O = r.opc; Object.keys(guarda).forEach(function (kk) { if (O[kk] === undefined) O[kk] = guarda[kk]; }); } toast('Salvo'); }).catch(erro); };
  if (agora) return vai();
  pendT = setTimeout(vai, 800); return Promise.resolve();
}

/* ---------- baixar planilha (gera no servidor) ---------- */
function baixarPlanilha(produto, escopo) {
  var f = document.createElement('form'); f.method = 'post'; f.action = ZP.adminPost; f.style.display = 'none';
  var add = function (n, v) { var i = document.createElement('input'); i.type = 'hidden'; i.name = n; i.value = v; f.appendChild(i); };
  add('action', 'zoe_rel_agora'); add('_wpnonce', ZP.relNonce); add('escopo', escopo || 'todos'); add('produtos', produto || ''); add('produto', 0);
  document.body.appendChild(f); f.submit(); setTimeout(function () { f.remove(); }, 2000);
  toast('Gerando a planilha…');
}

/* ===================== ESTRUTURA ===================== */
var MENU = [['painel', 'painel', 'Painel'], ['eventos', 'calendario', 'Eventos'], ['novo', 'mais', 'Novo evento'], ['inscricoes', 'pessoas', 'Inscrições'], ['pendentes', 'envelope', 'Aguardando pagamento'], ['imagens', 'imagem', 'Imagens do site'], ['relatorios', 'planilha', 'Relatórios'], ['textos', 'texto', 'Textos do site'], ['celulas', 'casa', 'Células']];
if (ZP.admin) MENU.push(['conexoes', 'estrela', 'Conexões IA']);
function rota() {
  var p = (location.hash.slice(2) || 'painel').split('/');
  var tela = p[0], arg = p[1];
  var atual = tela === 'editar' ? 'eventos' : tela;
  var links = function () { return MENU.map(function (m) { return '<a href="#/' + m[0] + '" class="' + (atual === m[0] ? 'on' : '') + '">' + ic(m[1]) + ' ' + m[2] + '</a>'; }).join(''); };
  $('#app').innerHTML = '<div class="adm-topo"><b>Zoe · Administração</b><button class="icone-btn" style="background:rgba(255,255,255,.1);color:#fff" data-acao="menu" aria-label="Menu">' + ic('menu') + '</button></div>' +
    '<nav class="adm-abas">' + links() + '<a href="' + esc(ZP.site) + '">' + ic('externo') + ' Ver site</a></nav>' +
    '<div class="adm"><aside><a class="logo" href="#/painel" style="color:#fff">' + img(O._img.logo) + '<span>Zoe Church</span></a>' + links() +
    '<div style="margin-top:auto"></div><a href="' + esc(ZP.site) + '" target="_blank">' + ic('externo') + ' Ver site</a><a href="' + esc(ZP.wpAdmin) + '">' + ic('engrenagem') + ' Painel do WordPress</a><a href="' + esc(ZP.sair) + '">' + ic('sair') + ' Sair</a></aside><main id="adm"></main></div>';
  ({ painel: aPainel, eventos: function () { aEventos(arg); }, novo: function () { aEditor(); }, editar: function () { aEditor(arg); }, inscricoes: function () { aInscricoes(arg); }, pendentes: aPendentes, imagens: aImagens, relatorios: aRelatorios, textos: aTextos, celulas: aCelulas, conexoes: aConexoes }[tela] || aPainel)();
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', rota);
document.addEventListener('click', function (e) { var t = e.target.closest('[data-acao="menu"]'); if (t) $('aside').classList.toggle('aberto'); });

/* ===================== PAINEL ===================== */
function aPainel() {
  var abertos = E.filter(function (e) { return e.aberto; }).length;
  $('#adm').innerHTML = '<h1>Olá' + (ZP.usuario ? ', ' + esc(ZP.usuario.split(' ')[0]) : '') + '!</h1><p class="sub">O que você quer fazer hoje?</p>' +
    '<div class="stats"><a class="stat clic" href="#/eventos/abertos"><b>' + abertos + '</b><span>Eventos com inscrição aberta</span><em>Ver e editar →</em></a>' +
    '<a class="stat clic" href="#/inscricoes"><b>' + ST.insc30 + '</b><span>Inscrições pagas nos últimos 30 dias</span><em>Ver inscritos →</em></a>' +
    '<div class="stat"><b>' + esc(ST.valor30) + '</b><span>Arrecadado nos últimos 30 dias</span></div></div>' +
    '<a class="cartao pend-resumo" href="#/pendentes" id="cardPend" style="display:none"></a>' +
    '<div class="cartao"><h2>Atalhos</h2><div class="acoes"><a class="btn" href="#/novo">' + ic('mais') + ' Criar evento</a><a class="btn sec" href="#/eventos">' + ic('lista') + ' Todos os eventos</a><a class="btn sec" href="#/inscricoes">' + ic('pessoas') + ' Ver inscritos</a><a class="btn sec" href="#/relatorios">' + ic('planilha') + ' Relatórios</a><a class="btn sec" href="#/imagens">' + ic('imagem') + ' Trocar imagens</a></div></div>' +
    '<div class="cartao"><h2>Como funciona</h2><ol style="margin:0;padding-left:20px;line-height:1.9;font-size:14px"><li><b>Novo evento:</b> preencha nome, data, preço e imagem.</li><li>Marque as perguntas do formulário de inscrição.</li><li>Publique. O evento aparece no site com o formulário certo.</li><li>Acompanhe em <b>Inscrições</b> e baixe a planilha.</li><li>A <b>estrela</b> coloca o evento no topo do site.</li></ol></div>';
  carregarPendResumo();
}

/* ===================== EVENTOS ===================== */
function carregarPendResumo() {
  api('pendentes').then(function (r) {
    var c = $('#cardPend'); if (!c) return;
    var n = r.pendentes.filter(function (p) { return p.status !== 'Aguardando'; }).length;
    if (!r.pendentes.length) return;
    c.style.display = 'block';
    c.innerHTML = '<h2>' + ic('envelope') + ' Aguardando pagamento</h2><p class="sub" style="margin:0"><b>' + r.pendentes.length + '</b> pessoa(s) começaram a inscrição nos últimos 3 dias e ainda não pagaram. Toque para mandar o link de pagamento pelo WhatsApp.</p>';
  }).catch(function () {});
}
function aPendentes() {
  $('#adm').innerHTML = '<h1>Aguardando pagamento</h1><p class="sub">Quem paga pelo site é confirmado <b>sozinho</b> pelo Mercado Pago: não precisa fazer nada. Aqui aparecem as inscrições dos <b>últimos 30 dias</b> que ficaram sem pagamento — inclusive as <b>canceladas</b> por passar do prazo. Se a pessoa pagou em dinheiro ou Pix direto, toque em <b>Recebi o pagamento</b>: a inscrição vale de novo e entra nos relatórios.</p><div id="listaPend"><div class="cartao vazio">Carregando…</div></div>';
  api('pendentes').then(function (r) {
    var L = r.pendentes;
    if (!L.length) { $('#listaPend').innerHTML = '<div class="cartao vazio">Ninguém aguardando pagamento agora.</div>'; return; }
    $('#listaPend').innerHTML = L.map(function (p, i) {
      var cancelado = p.st === 'cancelled' || p.st === 'failed';
      var msg = cancelado
        ? 'Olá' + (p.nome ? ', ' + p.nome.split(' ')[0] : '') + '! Aqui é da Zoe Church. Vimos que sua inscrição em ' + p.eventos + ' não teve o pagamento concluído. Se você já pagou com alguém da equipe, me avisa que a gente confirma por aqui. Se ainda não, dá para se inscrever de novo pelo site: ' + location.origin + '/eventos/'
        : 'Olá' + (p.nome ? ', ' + p.nome.split(' ')[0] : '') + '! Aqui é da Zoe Church. Vimos que sua inscrição em ' + p.eventos + ' ficou com o pagamento pendente. Para garantir sua vaga, é só concluir por este link: ' + p.link;
      return '<div class="cartao"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b style="font-size:16px">' + esc(p.nome || 'Sem nome') + '</b><br><span class="meta">' + esc(p.eventos) + ' · ' + esc(p.total) + '</span><br><span class="meta">Pedido #' + esc(p.numero) + ' · ' + esc(p.quando) + ' · ' + (cancelado ? '<span class="tag fim">' + esc(p.status) + '</span>' : '<span class="tag">' + esc(p.status) + '</span>') + (p.lembrete ? ' · e-mail de lembrete enviado' : '') + '</span>' + (p.tel ? '<br><span class="meta">' + esc(p.tel) + '</span>' : '') + '</div></div>' +
        '<div class="acoes" style="margin-top:12px">' + (p.whats ? '<a class="btn peq" target="_blank" rel="noopener" href="https://wa.me/' + p.whats + '?text=' + encodeURIComponent(msg) + '">WhatsApp</a>' : '') +
        '<button class="btn peq" data-pago="' + p.id + '">✓ Recebi o pagamento</button>' + (cancelado ? '' : '<button class="btn sec peq" data-copiar="' + i + '">Copiar link de pagamento</button>') + (p.email ? '<button class="btn sec peq" data-lembrar="' + p.id + '">Reenviar e-mail</button>' : '') + '<a class="btn sec peq" href="' + esc(p.editWp) + '">Abrir pedido</a></div></div>';
    }).join('');
    $$('[data-pago]').forEach(function (b) {
      b.onclick = function () {
        var p = L.find(function (x) { return String(x.id) === b.dataset.pago; });
        if (!confirm('Confirmar que ' + (p.nome || 'essa pessoa') + ' pagou ' + p.total + ' (' + p.eventos + ') em dinheiro ou Pix direto?\n\nA inscrição volta a valer, desconta vaga e entra nos relatórios. Se tiver e-mail, a pessoa recebe a confirmação.')) return;
        b.disabled = true;
        api('pendentes/' + p.id + '/pago', { json: {} }).then(function () { toast('Pagamento registrado'); aPendentes(); }).catch(function (e) { b.disabled = false; erro(e); });
      };
    });
    $$('[data-copiar]').forEach(function (b) { b.onclick = function () { var t = L[+b.dataset.copiar].link; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { toast('Link copiado'); }, function () { prompt('Copie o link:', t); }); }; });
    $$('[data-lembrar]').forEach(function (b) { b.onclick = function () { b.disabled = true; api('pendentes/' + b.dataset.lembrar + '/lembrar', { json: {} }).then(function () { toast('E-mail enviado'); }).catch(function (e) { b.disabled = false; erro(e); }); }; });
  }).catch(erro);
}

function statusTag(e) { return e.status === 'draft' ? '<span class="tag cinza">Rascunho</span>' : e.aberto ? '<span class="tag ok">Aberto</span>' : '<span class="tag fim">Encerrado</span>'; }
function aEventos(filtro) {
  var so = filtro === 'abertos';
  var lista = so ? E.filter(function (e) { return e.aberto; }) : E;
  $('#adm').innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><h1>' + (so ? 'Inscrições abertas' : 'Eventos') + '</h1><p class="sub">' + (so ? lista.length + ' evento(s) aceitando inscrição. Toque em <b>Editar</b> para mudar. <a href="#/eventos">Ver todos os eventos</a>' : 'Crie, duplique e acompanhe os eventos. A <b>estrela</b> põe o evento no topo do site; o <b>olho</b> mostra ou esconde da lista.') + '</p></div><a class="btn" href="#/novo">' + ic('mais') + ' Novo evento</a></div>' +
    '<div class="cartao rolagem"><table class="tb tb-ev"><thead><tr><th></th><th>Evento</th><th>Data</th><th>Preço</th><th>Inscritos</th><th>Status</th><th>Ações</th></tr></thead><tbody>' +
    (lista.length ? '' : '<tr><td colspan="7" class="vazio">Nenhum evento aqui.</td></tr>') +
    lista.map(function (e) {
      return '<tr><td class="ft">' + img(e.img, 'mini', e.pos) + '</td><td class="nm"><a href="#/editar/' + e.id + '" style="text-decoration:none"><b>' + esc(e.nome) + '</b></a>' + (e.destaque ? ' <span class="tag" title="No topo do site">★ destaque</span>' : '') + (!e.visivel ? ' <span class="tag cinza">fora da lista</span>' : '') + '<br><span class="meta">' + (e.prazo ? 'Inscrições até ' + dataBR(e.prazo) : (e.zoe ? 'Sem data limite' : 'Formulário antigo')) + '</span></td>' +
        '<td data-l="Data">' + dataBR(e.data) + '</td><td data-l="Preço">' + esc(e.precoTxt) + '</td><td data-l="Inscritos">' + e.inscritos + (e.vagas !== '' ? ' / ' + (+e.vagas + e.inscritos) : '') + '</td><td class="st">' + statusTag(e) + '</td>' +
        '<td class="ac"><div class="acoes"><a class="btn peq" href="#/editar/' + e.id + '">Editar</a><button class="btn sec peq" data-dup="' + e.id + '">Duplicar</button><a class="btn sec peq" href="#/inscricoes/' + e.id + '">Inscritos</a><a class="btn sec peq" href="' + esc(e.link) + '" target="_blank">Ver</a>' +
        '<button class="btn sec peq' + (e.destaque ? ' ativo' : '') + '" data-dest="' + e.id + '" title="Destaque (topo do site)">' + ic('estrela') + '</button><button class="btn sec peq' + (e.visivel ? '' : ' apagado') + '" data-vis="' + e.id + '" title="Mostrar na lista do site">' + ic('olho') + '</button></div></td></tr>';
    }).join('') + '</tbody></table></div>';
  $$('[data-dup]').forEach(function (b) { b.onclick = function () { b.disabled = true; api('evento/' + b.dataset.dup + '/duplicar', { json: {} }).then(function (ev) { trocaEv(ev); toast('Cópia criada como rascunho'); location.hash = '#/editar/' + ev.id; }).catch(function (e) { b.disabled = false; erro(e); }); }; });
  $$('[data-dest]').forEach(function (b) { b.onclick = function () { var e = getEv(b.dataset.dest); api('evento/' + e.id + '/flag', { json: { destaque: !e.destaque } }).then(function (ev) { trocaEv(ev); aEventos(filtro); toast(ev.destaque ? 'No topo do site' : 'Saiu do destaque'); }).catch(erro); }; });
  $$('[data-vis]').forEach(function (b) { b.onclick = function () { var e = getEv(b.dataset.vis); api('evento/' + e.id + '/flag', { json: { visivel: !e.visivel } }).then(function (ev) { trocaEv(ev); aEventos(filtro); toast(ev.visivel ? 'Aparece na lista do site' : 'Escondido da lista do site'); }).catch(erro); }; });
}

/* ---------- editor ---------- */
var ED, DIRTY;
function inp(f, l, t, ph) { return '<div class="campo"><label>' + l + '</label><input type="' + t + '" data-f="' + f + '" value="' + esc(ED[f]) + '" placeholder="' + esc(ph || '') + '"' + (t === 'number' ? ' min="0" inputmode="numeric"' : '') + '></div>'; }
function aEditor(id) {
  var e = id ? getEv(id) : null;
  if (id && !e) { location.hash = '#/eventos'; return; }
  ED = e ? JSON.parse(JSON.stringify(e)) : { id: 0, nome: '', imgId: 0, img: '', pos: '50% 50%', preco: '', data: '', prazo: '', fim: '', local: 'Zoe Church', vagas: '', status: 'publish', resumo: '', descricao: '', nota: '', simples: true, zoe: true, form: null };
  if (!ED.form) ED.form = { blocos: ['nome', 'whatsapp', 'celula'], opcionais: [], custom: [], porVaga: true };
  ED.usarZoe = false; DIRTY = {};
  var antigo = e && !e.zoe;
  var outros = E.filter(function (x) { return x.id != ED.id && x.zoe; });
  $('#adm').innerHTML = '<h1>' + (e ? 'Editar evento' : 'Novo evento') + '</h1><p class="sub">' + (e ? 'Altere o que precisar e salve.' : 'Preencha e publique. O formulário já vai junto.') + '</p>' +
    '<div class="editor-grid"><div>' +
    '<div class="cartao"><h2>1. Informações</h2>' + inp('nome', 'Nome do evento', 'text', 'Ex.: Encontro com Deus Mulheres 2027') +
    '<div class="g3">' + inp('data', 'Data do evento (1º dia)', 'date') + inp('fim', 'Último dia (se durar mais de 1)', 'date') + inp('prazo', 'Inscrições até', 'date') + '</div>' + inp('local', 'Local', 'text') +
    '<div class="g3">' + (ED.simples ? inp('preco', 'Preço (R$)', 'text', '150,00') + inp('vagas', 'Vagas restantes (vazio = sem limite)', 'number') : '<div class="campo"><label>Preço</label><p class="meta" style="margin:6px 0 0">' + esc(ED.precoTxt) + ' · este evento tem opções/lotes; preço e vagas ficam no <a href="' + esc(ED.editWp) + '">WooCommerce</a>.</p></div>') +
    '<div class="campo"><label>Status</label><select data-f="status"><option value="publish"' + (ED.status === 'publish' ? ' selected' : '') + '>Publicado</option><option value="draft"' + (ED.status !== 'publish' ? ' selected' : '') + '>Rascunho</option></select></div></div>' +
    (ED.prazo && antigo ? '' : '') +
    '<div class="campo"><label>Resumo (aparece perto do botão)</label><textarea data-f="resumo" rows="2">' + esc(ED.resumo) + '</textarea></div>' +
    '<div class="campo"><label>Descrição completa</label><textarea data-f="descricao" rows="6">' + esc(ED.descricao) + '</textarea><span class="meta">Deixe uma linha em branco entre os parágrafos.</span></div>' +
    '<div class="campo"><label>Mensagem no e-mail de confirmação (opcional)</label><textarea data-f="nota" rows="3" placeholder="Ex.: Entre no grupo do evento: https://chat.whatsapp.com/... · Chegue 30 min antes · Leve Bíblia e caderno">' + esc(ED.nota || '') + '</textarea><span class="meta">Vai no e-mail que a pessoa recebe quando o pagamento é aprovado. Links viram botão clicável.</span></div></div>' +
    '<div class="cartao"><h2>2. Imagem</h2><div style="display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap"><div style="width:180px" id="edimg">' + focoHTML(ED.img, ED.pos, '1/1', 'focoEd') + '</div>' +
    '<div style="flex:1;min-width:200px"><span class="spec" style="margin-top:0">Ideal: 1080 × 1080 px · quadrado 1:1</span><span class="spec-onde">Pode ser a mesma arte do post do Instagram. Toque na prévia para escolher o ponto que sempre aparece.</span><div class="aviso-img" id="avEd"></div>' +
    '<button class="btn sec" id="trocaImgEd">' + ic('camera') + ' Escolher imagem</button></div></div></div>' +
    '<div class="cartao"><h2>3. Formulário de inscrição</h2><div id="formArea"></div></div>' +
    '</div><div class="previa"><div class="cartao"><h2>' + ic('olho') + ' Prévia do formulário</h2><div class="tela grupo-dep" id="previa"></div></div></div></div>' +
    '<div class="barra-salvar"><button class="btn lg" id="salvarEv">' + (e ? 'Salvar' : 'Criar evento') + '</button><a class="btn sec" href="#/eventos">Cancelar</a>' + (e ? '<button class="btn perigo" style="margin-left:auto" id="excluirEv">Excluir</button>' : '') + '</div>';
  $$('[data-f]').forEach(function (el) { el.addEventListener('input', function () { ED[el.dataset.f] = el.value; DIRTY[el.dataset.f] = 1; }); el.addEventListener('change', function () { ED[el.dataset.f] = el.value; DIRTY[el.dataset.f] = 1; }); });
  ligarFoco('focoEd', function (p) { ED.pos = p; DIRTY.pos = 1; toast('Posição marcada'); });
  $('#trocaImgEd').onclick = function () {
    escolherImg(1600, false, function (r, w, h) { ED.imgId = r.id; ED.img = r.url; ED.pos = '50% 50%'; DIRTY.imgId = DIRTY.pos = 1; $('#edimg').innerHTML = focoHTML(r.url, ED.pos, '1/1', 'focoEd'); ligarFoco('focoEd', function (p) { ED.pos = p; DIRTY.pos = 1; }); var m = avisoTamanho(SPEC('evento'), w, h), a = $('#avEd'); a.textContent = m; a.classList.toggle('on', !!m); toast('Imagem pronta. Lembre de salvar.'); });
  };
  var desenharForm = function () {
    var area = $('#formArea');
    if (antigo && !ED.usarZoe) {
      area.innerHTML = '<p class="sub" style="margin:0 0 14px">Este evento ainda usa o <b>formulário antigo</b> (as perguntas que já aparecem hoje na finalização). Ele continua igual se você só mudar nome, datas, textos ou imagem.</p><button class="btn sec" id="usarZoe">Usar o formulário Zoe neste evento</button><p class="meta" style="margin-top:10px">Ao trocar, você escolhe as perguntas aqui, e a finalização deste evento passa a mostrar só elas. As inscrições já feitas não mudam.</p>';
      $('#previa').innerHTML = '<p class="vazio">Formulário antigo: a prévia aparece ao trocar para o formulário Zoe.</p>';
      $('#usarZoe').onclick = function () { if (!confirm('Trocar o formulário deste evento? As próximas inscrições vão responder as perguntas que você marcar aqui.')) return; ED.usarZoe = true; desenharForm(); };
      return;
    }
    area.innerHTML = '<p class="sub" style="margin:-6px 0 14px">Marque o que perguntar. Só isso aparece na finalização deste evento.</p>' +
      (outros.length ? '<div class="campo"><label>Copiar de outro evento</label><select id="copiar"><option value="">— escolher —</option>' + outros.map(function (o) { return '<option value="' + o.id + '">' + esc(o.nome) + '</option>'; }).join('') + '</select></div>' : '') +
      '<div class="lista-blocos" id="blocos"></div><h3 style="font-size:15px;margin:22px 0 4px">Perguntas personalizadas</h3><p class="meta" style="margin:0 0 10px">Ex.: "Turma", "Já participou antes?". Opções separadas por vírgula.</p><div id="custom"></div>' +
      '<button class="btn sec peq" id="addPerg">+ Adicionar pergunta</button>' +
      '<label style="display:flex;gap:8px;align-items:center;margin-top:18px;font-size:14px"><input type="checkbox" id="porvaga"' + (ED.form.porVaga ? ' checked' : '') + ' style="accent-color:var(--tinta)"> Pedir os dados de cada pessoa quando comprarem mais de uma vaga</label>';
    $('#porvaga').onchange = function (ev) { ED.form.porVaga = ev.target.checked; DIRTY.form = 1; };
    $('#addPerg').onclick = function () { ED.form.custom.push({ label: '', type: 'text', options: '', req: 1 }); DIRTY.form = 1; desenharCustom(); previa(); };
    if ($('#copiar')) $('#copiar').onchange = function (ev) { var o = getEv(ev.target.value); if (o && o.form && confirm('Usar o formulário de "' + o.nome + '"?')) { ED.form = JSON.parse(JSON.stringify(o.form)); DIRTY.form = 1; desenharForm(); toast('Formulário copiado'); } ev.target.value = ''; };
    desenharBlocos(); desenharCustom(); previa();
  };
  desenharForm();
  $('#salvarEv').onclick = salvarEvento;
  if ($('#excluirEv')) $('#excluirEv').onclick = function () {
    if (!confirm('Excluir este evento? Ele vai para a lixeira do WordPress. As inscrições e pedidos continuam guardados.')) return;
    api('evento/' + ED.id, { method: 'DELETE' }).then(function () { E = E.filter(function (x) { return x.id != ED.id; }); toast('Evento excluído'); location.hash = '#/eventos'; }).catch(erro);
  };
}
function desenharBlocos() {
  $('#blocos').innerHTML = Object.keys(ZP.bib).map(function (k) {
    var b = ZP.bib[k], on = ED.form.blocos.indexOf(k) >= 0, op = ED.form.opcionais.indexOf(k) >= 0;
    var sub = Object.keys(b.campos).map(function (c) { return b.campos[c].l; }).join(' · ');
    return '<label class="opt-bloco"><input type="checkbox" class="usar" data-b="' + k + '"' + (on ? ' checked' : '') + '><div><b style="font-size:14px">' + esc(b.t) + '</b><small>' + esc(sub) + '</small>' + (on ? '<span class="opc-line"><input type="checkbox" class="opcb" data-b="' + k + '"' + (op ? ' checked' : '') + '> opcional</span>' : '') + '</div></label>';
  }).join('');
  $$('#blocos .usar').forEach(function (c) { c.onchange = function () { var k = c.dataset.b; ED.form.blocos = c.checked ? Object.keys(ZP.bib).filter(function (x) { return x === k || ED.form.blocos.indexOf(x) >= 0; }) : ED.form.blocos.filter(function (x) { return x !== k; }); DIRTY.form = 1; desenharBlocos(); previa(); }; });
  $$('#blocos .opcb').forEach(function (c) { c.onclick = function (ev) { ev.stopPropagation(); }; c.onchange = function () { var k = c.dataset.b; ED.form.opcionais = c.checked ? ED.form.opcionais.concat([k]) : ED.form.opcionais.filter(function (x) { return x !== k; }); DIRTY.form = 1; previa(); }; });
}
function desenharCustom() {
  $('#custom').innerHTML = ED.form.custom.map(function (c, i) {
    return '<div class="custom-linha"><input type="text" placeholder="Pergunta" value="' + esc(c.label) + '" data-i="' + i + '" data-c="label"><select data-i="' + i + '" data-c="type">' + Object.keys(ZP.tipos).map(function (k) { return '<option value="' + k + '"' + (c.type === k ? ' selected' : '') + '>' + esc(ZP.tipos[k]) + '</option>'; }).join('') + '</select>' +
      '<input type="text" placeholder="' + (c.type === 'select' ? 'Opção 1, Opção 2' : '—') + '" value="' + esc(c.options) + '" data-i="' + i + '" data-c="options"' + (c.type === 'select' ? '' : ' disabled') + '><label style="font-size:12px;display:flex;gap:4px;align-items:center"><input type="checkbox" data-i="' + i + '" data-c="req"' + (+c.req ? ' checked' : '') + '>obrig.</label><button class="icone-btn" style="width:34px;height:34px" data-rm="' + i + '" aria-label="Remover">' + ic('fechar') + '</button></div>';
  }).join('');
  $$('#custom [data-c]').forEach(function (el) { el.addEventListener(el.type === 'checkbox' || el.tagName === 'SELECT' ? 'change' : 'input', function () { var c = ED.form.custom[el.dataset.i]; c[el.dataset.c] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value; DIRTY.form = 1; if (el.dataset.c === 'type') desenharCustom(); previa(); }); });
  $$('#custom [data-rm]').forEach(function (b) { b.onclick = function () { ED.form.custom.splice(+b.dataset.rm, 1); DIRTY.form = 1; desenharCustom(); previa(); }; });
}
function previa() {
  var cs = camposDoForm(ED.form);
  $('#previa').innerHTML = cs.length ? '<div class="bloco part" style="margin:0"><h3><span class="num">1</span>' + esc(ED.nome || 'Nome do evento') + '</h3><p class="bl-sub">Dados de quem vai participar</p>' + cs.map(function (c) { return campoHTML(c, 'pv_' + c.k); }).join('') + '</div>' : '<p class="vazio">Marque ao menos uma pergunta.</p>';
  ligarDeps($('.previa'));
}
function salvarEvento() {
  if (!String(ED.nome).trim()) { toast('Dê um nome ao evento'); $('[data-f=nome]').focus(); return; }
  if (ED.simples && String(ED.preco).trim() === '' && !ED.id) { toast('Informe o preço (0 se for gratuito)'); $('[data-f=preco]').focus(); return; }
  var usaForm = !ED.id || ED.zoe || ED.usarZoe;
  if (usaForm && !ED.form.blocos.length && !ED.form.custom.some(function (c) { return c.label; })) { toast('Marque pelo menos uma pergunta'); return; }
  var d = { id: ED.id, nome: ED.nome, status: ED.status };
  // num evento que já existe, só vai o que foi mudado (as vagas, por exemplo, mudam sozinhas a cada inscrição)
  ['data', 'fim', 'prazo', 'local', 'imgId', 'pos'].concat(ED.simples ? ['preco', 'vagas'] : []).forEach(function (k) { if (!ED.id || DIRTY[k]) d[k] = ED[k]; });
  if (!ED.id || DIRTY.resumo) d.resumo = ED.resumo;
  if (!ED.id || DIRTY.descricao) d.descricao = ED.descricao;
  if (!ED.id || DIRTY.nota) d.nota = ED.nota;
  if (usaForm) { d.form = { blocos: ED.form.blocos, opcionais: ED.form.opcionais, custom: ED.form.custom.filter(function (c) { return String(c.label).trim(); }), porVaga: ED.form.porVaga }; d.usarZoe = ED.usarZoe; }
  var b = $('#salvarEv'); b.disabled = true; b.textContent = 'Salvando…';
  api('evento', { json: d }).then(function (ev) { trocaEv(ev); toast(ED.id ? 'Evento salvo!' : 'Evento criado!'); location.hash = '#/eventos'; })
    .catch(function (e) { b.disabled = false; b.textContent = 'Salvar'; erro(e); });
}

/* ===================== INSCRIÇÕES ===================== */
function aInscricoes(id) {
  var e = id ? getEv(id) : null;
  var comInsc = E.filter(function (x) { return x.inscritos > 0 || x.aberto; });
  $('#adm').innerHTML = '<h1>Inscrições</h1><p class="sub">Escolha o evento para ver e baixar a lista.</p><div class="cartao"><select id="selEv"><option value="">— Escolha o evento —</option>' + comInsc.map(function (x) { return '<option value="' + x.id + '"' + (e && x.id == e.id ? ' selected' : '') + '>' + esc(x.nome) + ' (' + x.inscritos + ')</option>'; }).join('') + '</select></div><div id="corpoInsc"></div>';
  $('#selEv').onchange = function () { location.hash = '#/inscricoes/' + this.value; };
  if (!e) return;
  $('#corpoInsc').innerHTML = '<div class="cartao vazio">Carregando inscrições…</div>';
  api('inscricoes/' + e.id).then(function (r) {
    if (!r.linhas.length) { $('#corpoInsc').innerHTML = '<div class="cartao vazio">Ainda não há inscrições pagas ou aguardando neste evento.</div>'; return; }
    var cols = r.cols.filter(function (c) { return c !== 'E-mail'; });
    $('#corpoInsc').innerHTML = '<div class="cartao rolagem"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;gap:10px;flex-wrap:wrap"><b>' + r.linhas.length + ' inscrição(ões) · ' + r.pagos + ' paga(s)' + (r.aguard ? ' · ' + r.aguard + ' aguardando' : '') + '</b><button class="btn peq" id="baixarInsc">' + ic('baixar') + ' Baixar planilha (Excel)</button></div>' +
      '<table class="tb"><thead><tr>' + cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      r.linhas.map(function (l) { return '<tr>' + cols.map(function (c) { return '<td>' + esc(l[c] == null ? '' : l[c]) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>';
    $('#baixarInsc').onclick = function () { baixarPlanilha(e.id, 'todos'); };
  }).catch(function (er) { $('#corpoInsc').innerHTML = ''; erro(er); });
}

/* ===================== IMAGENS ===================== */
function aImagens() {
  var P = O.pos || {};
  var itens = [
    { t: 'Logo', tp: 'logo', src: O._img.logo, ratio: '1/1', png: true, troca: function (r) { return salvarSite('logo', r.id, true); } },
  ];
  (O._img.hero || []).forEach(function (src, i) {
    itens.push({ t: 'Banner ' + (i + 1) + ' da home', tp: 'hero', src: src, ratio: '16/9', max: 2400, pos: P['hero-' + i], troca: function (r) { var h = (O.hero || []).slice(); h[i] = r.id; return salvarSite('hero', h, true); }, foco: function (p) { var np = Object.assign({}, O.pos || {}); np['hero-' + i] = p; O.pos = np; return salvarSite('pos', np); } });
  });
  [['Seção Células', 'retrato', 'cel_img', 'cel', '4/5'], ['Tema do ano', 'quadrado', 'ano_img', 'ano', '1/1'], ['Vida abundante', 'retrato', 'vida_img', 'vida', '4/5']].forEach(function (a) {
    itens.push({ t: a[0], tp: a[1], src: O._img[a[2]], ratio: a[4], pos: P[a[3]], troca: function (r) { return salvarSite(a[2], r.id, true); }, foco: function (p) { var np = Object.assign({}, O.pos || {}); np[a[3]] = p; O.pos = np; return salvarSite('pos', np); } });
  });
  (O.pastores || []).forEach(function (pa, i) {
    itens.push({ t: pa.nome, tp: 'pastor', src: (O._img.pastores || [])[i], ratio: '1/1', pos: pa.pos, troca: function (r) { var l = JSON.parse(JSON.stringify(O.pastores)); l[i].img = r.id; l[i].pos = '50% 50%'; return salvarSite('pastores', l, true); }, foco: function (p) { var l = JSON.parse(JSON.stringify(O.pastores)); l[i].pos = p; O.pastores = l; return salvarSite('pastores', l); } });
  });
  E.filter(function (e) { return e.status === 'publish' && e.visivel; }).forEach(function (e) {
    itens.push({ t: e.nome, tp: 'evento', src: e.img, ratio: '1/1', pos: e.pos, troca: function (r) { return api('evento/' + e.id + '/flag', { json: { imgId: r.id, pos: '50% 50%' } }).then(function (ev) { trocaEv(ev); toast('Imagem trocada!'); }); }, foco: function (p) { return api('evento/' + e.id + '/flag', { json: { pos: p } }).then(function (ev) { trocaEv(ev); toast('Posição salva'); }); } });
  });
  window._imgs = itens;
  $('#adm').innerHTML = '<h1>Imagens do site</h1><p class="sub">Toque em <b>Trocar</b> para enviar uma foto. Depois <b>toque ou arraste sobre a prévia</b> para escolher o ponto que sempre aparece (o rosto, o centro da arte).</p><div class="galeria">' +
    itens.map(function (it, i) {
      var sp = SPEC(it.tp);
      return '<div class="img-card">' + (it.foco ? focoHTML(it.src, it.pos, it.ratio, 'foco' + i) : '<div class="ph" style="aspect-ratio:' + it.ratio + ';background:#fff">' + img(it.src) + '</div>') +
        '<div class="b"><b>' + esc(it.t) + '</b><span class="spec">Ideal: ' + sp.w + ' × ' + sp.h + ' px · ' + esc(sp.f) + '</span><span class="spec-onde">' + esc(sp.onde) + '</span><div class="aviso-img" id="av' + i + '"></div><button class="btn peq" data-troca="' + i + '">' + ic('camera') + ' Trocar</button></div></div>';
    }).join('') + '</div>';
  itens.forEach(function (it, i) { if (it.foco) ligarFoco('foco' + i, function (p) { it.foco(p); }); });
  $$('[data-troca]').forEach(function (b) {
    b.onclick = function () {
      var i = +b.dataset.troca, it = itens[i];
      escolherImg(it.max || 1600, it.png, function (r, w, h) {
        Promise.resolve(it.troca(r)).then(function () { aImagens(); var m = avisoTamanho(SPEC(it.tp), w, h); if (m) { var a = $('#av' + i); if (a) { a.textContent = m; a.classList.add('on'); } } toast('Imagem trocada!'); }).catch(erro);
      });
    };
  });
}

/* ===================== TEXTOS ===================== */
function aTextos() {
  var t = function (lab, k, rows) { var v = O[k] == null ? '' : O[k]; return '<div class="campo"><label>' + lab + '</label>' + (rows ? '<textarea rows="' + rows + '" data-k="' + k + '">' + esc(v) + '</textarea>' : '<input type="text" data-k="' + k + '" value="' + esc(v) + '">') + '</div>'; };
  var opEv = function (sel) { return '<option value="">— nenhum —</option><option value="eventos"' + (sel === 'eventos' ? ' selected' : '') + '>Página de eventos</option>' + E.filter(function (e) { return e.status === 'publish'; }).map(function (e) { return '<option value="' + e.id + '"' + (String(sel) === String(e.id) ? ' selected' : '') + '>' + esc(e.nome) + '</option>'; }).join(''); };
  $('#adm').innerHTML = '<h1>Textos do site</h1><p class="sub">Tudo salva sozinho. Use <b>*palavra*</b> para deixar em itálico elegante.</p>' +
    '<div class="cartao"><h2>Topo da página inicial</h2>' + t('Título grande', 'titulo') + t('Linha acima do título', 'subtitulo') + t('Frase ao lado (computador)', 'frase', 2) + t('Faixa que corre (uma frase por linha)', 'faixa', 4) + '</div>' +
    '<div class="cartao"><h2>Cultos</h2>' + t('Horários (um por linha: horário|descrição)', 'cultos', 3) + t('Texto', 'cultos_txt', 2) + t('Endereço', 'endereco') + '</div>' +
    '<div class="cartao"><h2>Nossa visão</h2>' + t('Frase de destaque', 'visao_titulo', 2) + t('Texto (deixe uma linha em branco entre os parágrafos)', 'visao', 8) +
    '<h3 style="font-size:14px;margin:18px 0 8px">Pastores</h3><div id="lp">' + (O.pastores || []).map(function (p, i) { return '<div class="g2" style="align-items:end"><div class="campo"><label>Nome</label><input type="text" value="' + esc(p.nome) + '" data-pas="' + i + '" data-c="nome"></div><div class="campo"><label>Cargo</label><div style="display:flex;gap:8px"><input type="text" value="' + esc(p.cargo) + '" data-pas="' + i + '" data-c="cargo"><button class="icone-btn" data-rmpas="' + i + '" aria-label="Remover">' + ic('fechar') + '</button></div></div></div>'; }).join('') + '</div>' +
    '<button class="btn sec peq" id="addPas">+ Adicionar pastores</button><p class="meta">As fotos dos pastores se trocam em Imagens do site.</p></div>' +
    '<div class="cartao"><h2>Tema do ano</h2>' + t('Título', 'ano_titulo') + t('Versículo', 'ano_verso', 2) + t('Referência', 'ano_ref') + t('Destaques (um por linha)', 'ano_itens', 3) + t('Frase', 'ano_frase') + '</div>' +
    '<div class="cartao"><h2>Vida abundante</h2>' + t('Título', 'vida_titulo') + t('Texto', 'vida_texto', 6) + t('Versículo', 'vida_verso', 2) + t('Referência', 'vida_ref') + '</div>' +
    '<div class="cartao"><h2>Células</h2>' + t('Texto da seção', 'cel_txt', 3) + t('O que acontece em uma reunião (um por linha)', 'reuniao', 6) + t('Versículo', 'cel_verso', 2) + t('Referência', 'cel_ref') + '</div>' +
    '<div class="cartao"><h2>Ministérios</h2><div id="lm">' + (O.ministerios || []).map(function (m, i) { return '<div style="border-bottom:1px solid var(--linha);padding-bottom:12px;margin-bottom:14px"><div class="g2"><div class="campo"><label>Nome</label><input type="text" value="' + esc(m.nome) + '" data-min="' + i + '" data-c="nome"></div><div class="campo"><label>Leva para</label><select data-min="' + i + '" data-c="link">' + opEv(m.link) + '</select></div></div><div class="campo"><label>Texto</label><textarea rows="2" data-min="' + i + '" data-c="txt">' + esc(m.txt) + '</textarea></div><button class="btn perigo peq" data-rmmin="' + i + '">Remover</button></div>'; }).join('') + '</div>' +
    '<button class="btn sec peq" id="addMin">+ Adicionar ministério</button></div>' +
    '<div class="cartao"><h2>Contribua</h2>' + t('Texto', 'contrib_txt', 2) + '<div class="g2">' + t('CNPJ (o que aparece)', 'cnpj') + t('Chave PIX (o que é copiado)', 'pix') + '</div>' + t('Razão social', 'razao') + '</div>' +
    '<div class="cartao"><h2>Contato e redes sociais</h2>' + t('Texto', 'contato_txt', 2) + '<div class="g2">' + t('WhatsApp (link)', 'whatsapp') + t('E-mail', 'email') + t('Instagram (link)', 'instagram') + t('Facebook (link)', 'facebook') + '</div>' + t('YouTube (link)', 'youtube') + '</div>';
  $$('#adm [data-k]').forEach(function (el) { el.addEventListener('input', function () { O[el.dataset.k] = el.value; salvarSite(el.dataset.k, el.value); }); });
  $$('[data-pas]').forEach(function (el) { el.addEventListener('input', function () { O.pastores[el.dataset.pas][el.dataset.c] = el.value; salvarSite('pastores', O.pastores); }); });
  $$('[data-rmpas]').forEach(function (b) { b.onclick = function () { if (!confirm('Remover estes pastores do site?')) return; O.pastores.splice(+b.dataset.rmpas, 1); salvarSite('pastores', O.pastores, true).then(aTextos); }; });
  $('#addPas').onclick = function () { O.pastores = (O.pastores || []).concat([{ nome: 'Novo casal', cargo: 'Pastores', img: '', pos: '50% 50%' }]); salvarSite('pastores', O.pastores, true).then(aTextos); };
  $$('[data-min]').forEach(function (el) { el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', function () { O.ministerios[el.dataset.min][el.dataset.c] = el.value; salvarSite('ministerios', O.ministerios, el.tagName === 'SELECT'); }); });
  $$('[data-rmmin]').forEach(function (b) { b.onclick = function () { if (!confirm('Remover este ministério do site?')) return; O.ministerios.splice(+b.dataset.rmmin, 1); salvarSite('ministerios', O.ministerios, true).then(aTextos); }; });
  $('#addMin').onclick = function () { O.ministerios = (O.ministerios || []).concat([{ nome: 'Novo ministério', txt: '', link: '' }]); salvarSite('ministerios', O.ministerios, true).then(aTextos); };
}

/* ===================== CÉLULAS ===================== */
function salvarCelulas(msg) { return api('celulas', { json: { lista: C, off: COFF } }).then(function () { toast(msg || 'Salvo'); }).catch(erro); }
function aCelulas() {
  var redes = O.redes || [];
  $('#adm').innerHTML = '<h1>Células</h1><p class="sub">As redes ativas aparecem no site (com WhatsApp dos líderes). As células marcadas aparecem na pergunta "Qual a sua célula?" das inscrições.</p>' +
    '<div class="cartao"><h2>Redes de células (site)</h2><div id="lr">' + redes.map(function (r, i) {
      var f = function (lab, c, area) { return '<div class="campo"><label>' + lab + '</label>' + (area ? '<textarea rows="2" data-rede="' + i + '" data-c="' + c + '">' + esc(r[c]) + '</textarea>' : '<input type="text" value="' + esc(r[c]) + '" data-rede="' + i + '" data-c="' + c + '">') + '</div>'; };
      return '<div style="border-bottom:1px solid var(--linha);padding:6px 0 14px;margin-bottom:14px"><div class="g2">' + f('Nome da rede', 'nome') + f('Liderança', 'lider') + '</div><div class="g2">' + f('Dia e horário', 'dia') + f('Bairro / local', 'bairro') + '</div>' + f('Contatos (um por linha: Nome — telefone)', 'contatos', 1) + f('Descrição (opcional)', 'desc', 1) +
        '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><label style="display:flex;gap:8px;align-items:center;font-size:14px;font-weight:600"><input type="checkbox"' + (r.ativa === 0 || r.ativa === false ? '' : ' checked') + ' data-ativa="' + i + '" style="accent-color:var(--tinta)"> Ativa (aparece no site)</label><button class="btn perigo peq" data-rmrede="' + i + '">Remover</button></div></div>';
    }).join('') + '</div><button class="btn peq" id="addRede">+ Adicionar rede</button><p class="meta" style="margin-top:10px">Salvo automaticamente.</p></div>' +
    '<div class="cartao"><h2>Células (opções da inscrição)</h2><p class="meta" style="margin:-8px 0 12px">Desmarque para esconder uma célula da pergunta "Qual a sua célula?" sem apagar.</p><div id="lc">' + C.map(function (c, i) {
      var off = COFF.indexOf(c) >= 0;
      return '<div style="display:flex;gap:8px;margin-bottom:8px;align-items:center"><input type="checkbox" title="Aparece na inscrição"' + (off ? '' : ' checked') + ' data-cel="' + i + '" style="accent-color:var(--tinta);width:20px;height:20px;flex:none"><input type="text" value="' + esc(c) + '" data-rencel="' + i + '"' + (off ? ' style="opacity:.5"' : '') + '><button class="icone-btn" data-rmcel="' + i + '" aria-label="Apagar">' + ic('fechar') + '</button></div>';
    }).join('') + '</div><div style="display:flex;gap:8px;margin-top:14px"><input type="text" id="nc" placeholder="Nova célula"><button class="btn" id="addCel">Adicionar</button></div></div>';
  $$('[data-rede]').forEach(function (el) { el.addEventListener('input', function () { O.redes[el.dataset.rede][el.dataset.c] = el.value; salvarSite('redes', O.redes); }); });
  $$('[data-ativa]').forEach(function (el) { el.onchange = function () { O.redes[el.dataset.ativa].ativa = el.checked ? 1 : 0; salvarSite('redes', O.redes, true).then(function () { toast(el.checked ? 'Rede ativa: aparece no site' : 'Rede desativada: some do site'); }); }; });
  $$('[data-rmrede]').forEach(function (b) { b.onclick = function () { if (!confirm('Remover esta rede de vez? Para só esconder, desmarque Ativa.')) return; O.redes.splice(+b.dataset.rmrede, 1); salvarSite('redes', O.redes, true).then(aCelulas); }; });
  $('#addRede').onclick = function () { O.redes = (O.redes || []).concat([{ nome: 'Nova rede', lider: '', dia: '', bairro: '', contatos: '', desc: '', ativa: 1 }]); salvarSite('redes', O.redes, true).then(aCelulas); };
  $$('[data-cel]').forEach(function (el) { el.onchange = function () { var c = C[+el.dataset.cel]; COFF = COFF.filter(function (x) { return x !== c; }); if (!el.checked) COFF.push(c); salvarCelulas(el.checked ? 'Célula aparece na inscrição' : 'Célula escondida da inscrição').then(aCelulas); }; });
  $$('[data-rencel]').forEach(function (el) { el.onchange = function () { var i = +el.dataset.rencel, ant = C[i], v = el.value.trim(); if (!v) { el.value = ant; return; } C[i] = v; COFF = COFF.map(function (x) { return x === ant ? v : x; }); salvarCelulas('Nome salvo'); }; });
  $$('[data-rmcel]').forEach(function (b) { b.onclick = function () { if (!confirm('Apagar esta célula da lista?')) return; var c = C.splice(+b.dataset.rmcel, 1)[0]; COFF = COFF.filter(function (x) { return x !== c; }); salvarCelulas('Célula apagada').then(aCelulas); }; });
  $('#addCel').onclick = function () { var v = $('#nc').value.trim(); if (!v) return; if (C.indexOf(v) < 0) C.push(v); salvarCelulas('Célula adicionada').then(aCelulas); };
}

/* ===================== RELATÓRIOS ===================== */
function salvarRel(msg) { return api('rel', { json: R }).then(function (r) { R = r.rel; toast(msg || 'Salvo'); }).catch(erro); }
function aRelatorios() {
  $('#adm').innerHTML = '<h1>Relatórios</h1><p class="sub">Planilha completa: resumo por evento, por rede de células, por mês e uma aba por evento com todos os inscritos.</p>' +
    '<div class="cartao"><h2>Gerar agora</h2><div class="campo"><label>Eventos</label><div class="caixa-evs" id="relEvs"><label class="ev-todos"><input type="checkbox" id="relTodos" checked> <b>Todos os eventos</b></label>' + E.filter(function (e) { return e.inscritos > 0; }).map(function (e) { return '<label><input type="checkbox" class="relEv" value="' + e.id + '"> ' + esc(e.nome) + '</label>'; }).join('') + '</div><span class="meta">Marque um ou mais eventos para sair tudo na mesma planilha (uma aba por evento).</span></div><div class="g3"><div class="campo" style="grid-column:1/-1">' +
    '<div class="campo"><label>Período</label><select id="relEscopo"><option value="hoje">Hoje</option><option value="d7">Últimos 7 dias</option><option value="d30">Últimos 30 dias</option><option value="d60">Últimos 60 dias</option><option value="d90" selected>Últimos 90 dias</option><option value="todos">Todas as inscrições (desde o começo)</option><option value="abertos">Só eventos abertos</option></select></div></div>' +
    '<div class="acoes"><button class="btn" id="relBaixar">' + ic('baixar') + ' Baixar planilha agora</button>' + (R.emails.length ? '<button class="btn sec" id="relEnviar">' + ic('envelope') + ' Enviar agora para a lista</button>' : '') + '</div></div>' +
    '<div class="cartao"><h2>Quem recebe por e-mail</h2><p class="sub" style="margin:-6px 0 14px">Cada e-mail cadastrado recebe a planilha automaticamente. O próprio site envia, pela conta de e-mail do domínio.</p>' +
    '<div id="relLista">' + (R.emails.map(function (m, i) { return '<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px"><input type="text" value="' + esc(m) + '" readonly><button class="icone-btn" data-rmmail="' + i + '" aria-label="Remover">' + ic('fechar') + '</button></div>'; }).join('') || '<p class="meta">Nenhum e-mail cadastrado ainda.</p>') + '</div>' +
    '<div style="display:flex;gap:8px;margin-top:10px"><input type="email" id="relNovo" placeholder="nome@exemplo.com"><button class="btn" id="relAdd">Adicionar</button></div>' +
    '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:18px;font-size:14px"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="relAtivo"' + (+R.ativo ? ' checked' : '') + ' style="accent-color:var(--tinta)"> Enviar todo dia às</label>' +
    '<select style="width:auto" id="relHora">' + Array.from({ length: 24 }, function (_, h) { return '<option value="' + h + '"' + (h == R.hora ? ' selected' : '') + '>' + String(h).padStart(2, '0') + ':00</option>'; }).join('') + '</select>' +
    '<span>com</span><select style="width:auto" id="relEsc">' + [['hoje', 'inscrições de hoje'], ['d7', 'inscrições dos últimos 7 dias'], ['d30', 'inscrições dos últimos 30 dias'], ['d60', 'inscrições dos últimos 60 dias'], ['d90', 'inscrições dos últimos 90 dias'], ['recentes', 'inscrições dos últimos 90 dias'], ['abertos', 'eventos com inscrição aberta'], ['todos', 'todas as inscrições']].map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === R.escopo ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></div></div>';
  var marcados = function () { return $$('.relEv:checked').map(function (c) { return c.value; }); };
  $('#relTodos').onchange = function () { if (this.checked) $$('.relEv').forEach(function (c) { c.checked = false; }); };
  $$('.relEv').forEach(function (c) { c.onchange = function () { $('#relTodos').checked = !marcados().length; }; });
  $('#relBaixar').onclick = function () { baixarPlanilha($('#relTodos').checked ? '' : marcados().join(','), $('#relEscopo').value); };
  if ($('#relEnviar')) $('#relEnviar').onclick = function () { var b = this; b.disabled = true; toast('Enviando…'); api('rel/enviar', { json: { escopo: $('#relEscopo').value } }).then(function (r) { b.disabled = false; toast(r.n ? 'Planilha enviada para ' + r.n + ' e-mail(s)' : 'Não foi possível enviar' + (r.erro ? ': ' + r.erro : '. Confira o e-mail do site no Painel do WordPress.')); }).catch(function (e) { b.disabled = false; erro(e); }); };
  $('#relAdd').onclick = function () { var v = $('#relNovo').value.trim().toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { toast('E-mail inválido'); return; } if (R.emails.indexOf(v) < 0) R.emails.push(v); salvarRel('E-mail adicionado').then(aRelatorios); };
  $$('[data-rmmail]').forEach(function (b) { b.onclick = function () { R.emails.splice(+b.dataset.rmmail, 1); salvarRel('E-mail removido').then(aRelatorios); }; });
  $('#relAtivo').onchange = function () { R.ativo = this.checked ? 1 : 0; salvarRel(); };
  $('#relHora').onchange = function () { R.hora = +this.value; salvarRel(); };
  $('#relEsc').onchange = function () { R.escopo = this.value; salvarRel(); };
}

/* ===================== CONEXÕES IA ===================== */
function aConexoes() {
  $('#adm').innerHTML = '<h1>Conexões IA</h1><p class="sub">Cada conexão é um link secreto que permite a um assistente de IA (Claude ou ChatGPT) administrar o site conversando: eventos, inscrições, baixas, relatórios, textos e páginas. <b>Pagamentos e Mercado Pago ficam de fora</b> — o conector não tem essas ferramentas.</p><div id="cxLista"><p class="meta">Carregando…</p></div>' +
    '<div class="cartao"><h2>Nova conexão</h2><p class="meta" style="margin:-6px 0 12px">Crie uma por pessoa. Se precisar cortar o acesso de alguém, é só revogar a conexão dela — as outras continuam funcionando.</p><div style="display:flex;gap:8px"><input type="text" id="cxNome" placeholder="Nome de quem vai usar (ex.: Eliel)"><button class="btn" id="cxCriar">Criar</button></div></div>' +
    '<div class="cartao"><h2>Como conectar</h2><p class="meta" style="line-height:1.7"><b>No Claude:</b> Configurações → Conectores → Adicionar conector personalizado → cole o link.<br><b>No ChatGPT:</b> Configurações → Apps e conectores → Criar → cole o link (exige plano com conectores MCP).<br>Depois é só conversar: “liste as pendências do START”, “crie um evento…”, “mude o texto da página inicial…”.</p></div>';
  function lista() {
    api('conexoes').then(function (cs) {
      $('#cxLista').innerHTML = '<div class="cartao"><h2>Conexões ativas</h2>' + (cs.length ? cs.map(function (c) {
        return '<div style="border-bottom:1px solid var(--linha);padding:10px 0"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><b style="flex:1">' + esc(c.nome) + '</b><span class="meta">criada em ' + esc(c.criado) + (c.uso ? ' · último uso ' + esc(c.uso) : ' · nunca usada') + '</span><button class="btn sec peq" data-cxcopia="' + esc(c.url) + '">Copiar link</button><button class="btn perigo peq" data-cxrev="' + esc(c.id) + '">Revogar</button></div></div>';
      }).join('') : '<p class="meta">Nenhuma conexão criada ainda.</p>') + '</div>';
      $$('[data-cxcopia]').forEach(function (b) { b.onclick = function () { navigator.clipboard.writeText(b.dataset.cxcopia).then(function () { toast('Link copiado! Trate como uma senha.'); }); }; });
      $$('[data-cxrev]').forEach(function (b) { b.onclick = function () { if (!confirm('Revogar esta conexão? O link dela deixa de funcionar na hora.')) return; api('conexoes/' + b.dataset.cxrev, { method: 'DELETE' }).then(function () { toast('Conexão revogada'); lista(); }).catch(erro); }; });
    }).catch(erro);
  }
  lista();
  $('#cxCriar').onclick = function () {
    var nome = $('#cxNome').value.trim();
    if (!nome) { toast('Dê um nome à conexão'); return; }
    api('conexoes', { json: { nome: nome } }).then(function (c) {
      $('#cxNome').value = '';
      navigator.clipboard.writeText(c.url).then(function () { toast('Conexão criada e link copiado!'); }, function () { toast('Conexão criada'); });
      lista();
    }).catch(erro);
  };
}

/* recarrega a lista quando o painel volta a ficar visível (outra pessoa pode ter mudado algo) */
document.addEventListener('visibilitychange', function () {
  if (document.visibilityState !== 'visible') return;
  var tela = (location.hash.slice(2) || 'painel').split('/')[0];
  if (['painel', 'eventos', 'inscricoes'].indexOf(tela) < 0) return;
  api('eventos').then(function (r) { E = r.eventos; ST = r.stats; rota(); }).catch(function () {});
});

rota();
})();
