/* Tema Zoe Church — interações (sem dependências) */
(function () {
  var d = document, b = d.body;
  var $ = function (s, c) { return (c || d).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };

  /* menu em tela cheia */
  function abrirMenu() { var m = $('#menuFull'); if (!m) return; m.classList.add('on'); m.setAttribute('aria-hidden', 'false'); $$('nav a', m).forEach(function (a, i) { a.style.transitionDelay = (0.15 + i * 0.06) + 's'; }); b.style.overflow = 'hidden'; }
  function fecharMenu() { var m = $('#menuFull'); if (!m) return; m.classList.remove('on'); m.setAttribute('aria-hidden', 'true'); $$('nav a', m).forEach(function (a) { a.style.transitionDelay = '0s'; }); b.style.overflow = ''; }
  /* carrinho lateral */
  function abrirCarrinho() { var g = $('#gaveta'), v = $('#veu'); if (!g) { location.href = (window.wc_cart_fragments_params && wc_cart_fragments_params.cart_url) || '/carrinho/'; return; } g.classList.add('on'); v && v.classList.add('on'); g.setAttribute('aria-hidden', 'false'); }
  function fecharCarrinho() { var g = $('#gaveta'), v = $('#veu'); g && g.classList.remove('on'); v && v.classList.remove('on'); g && g.setAttribute('aria-hidden', 'true'); }

  d.addEventListener('click', function (e) {
    var t = e.target.closest('[data-abrir],[data-fechar],[data-copiar],.rede-cab,#menuFull nav a');
    if (!t) return;
    if (t.matches('#menuFull nav a')) { fecharMenu(); return; }
    if (t.dataset.abrir === 'menu') abrirMenu();
    if (t.dataset.abrir === 'carrinho') abrirCarrinho();
    if (t.dataset.fechar === 'menu') fecharMenu();
    if (t.dataset.fechar === 'carrinho') fecharCarrinho();
    if (t.dataset.copiar !== undefined) {
      var txt = t.dataset.copiar, ok = function () { var o = t.textContent; t.textContent = 'Copiado'; setTimeout(function () { t.textContent = o; }, 1800); };
      if (navigator.clipboard) navigator.clipboard.writeText(txt).then(ok, ok); else ok();
    }
    if (t.classList.contains('rede-cab')) { var r = t.parentElement; r.classList.toggle('aberta'); t.setAttribute('aria-expanded', r.classList.contains('aberta')); }
  });
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape') { fecharMenu(); fecharCarrinho(); } });

  /* aviso rápido no rodapé da tela */
  function toast(m) { var t = $('#toast'); if (!t) return; t.textContent = m; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove('on'); }, 2600); }

  /* página do evento: "Inscrever-se" adiciona sem recarregar e abre o carrinho lateral
     (eventos com "ir direto para a finalização" continuam indo para a finalização) */
  var fc = $('form.cart'), L = window.zoeLoja;
  if (fc && L && window.fetch && window.FormData && window.DOMParser) {
    fc.addEventListener('submit', function (e) {
      var btn = e.submitter || $('.single_add_to_cart_button', fc);
      if (btn && btn.classList.contains('disabled')) return; // o WooCommerce avisa que falta escolher a opção
      e.preventDefault();
      var fd = new FormData(fc);
      if (btn && btn.name && !fd.has(btn.name)) fd.append(btn.name, btn.value);
      if (btn) { btn.classList.add('carregando'); btn.disabled = true; }
      var fim = function () { if (btn) { btn.classList.remove('carregando'); btn.disabled = false; } };
      fetch(fc.getAttribute('action') || location.href, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.text().then(function (h) { return { url: r.url, html: h }; }); })
        .then(function (res) {
          if (res.url && res.url.indexOf(L.checkout) === 0) { location.href = res.url; return; }
          var doc = new DOMParser().parseFromString(res.html, 'text/html');
          var err = doc.querySelector('.woocommerce-error');
          if (err) { fim(); toast(err.textContent.replace(/\s+/g, ' ').trim()); return; }
          return fetch(L.fragments, { method: 'POST', credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (data) {
            if (data && data.fragments) {
              Object.keys(data.fragments).forEach(function (sel) {
                $$(sel).forEach(function (el) { var tmp = d.createElement('div'); tmp.innerHTML = data.fragments[sel]; if (tmp.firstElementChild) el.replaceWith(tmp.firstElementChild); });
              });
            }
            if (window.jQuery) jQuery(d.body).trigger('wc_fragment_refresh');
            fim(); abrirCarrinho(); toast('Adicionado ao carrinho');
          });
        })
        .catch(function () { fim(); fc.submit(); });
    });
  }

  /* WooCommerce: abre o carrinho ao adicionar via AJAX */
  if (window.jQuery) jQuery(d.body).on('added_to_cart', function () { abrirCarrinho(); });

  /* topo transparente sobre a foto da home */
  if (b.classList.contains('sobre-hero')) {
    var rolar = function () { b.classList.toggle('rolou', window.scrollY > window.innerHeight * 0.6); };
    window.addEventListener('scroll', rolar, { passive: true }); rolar();
  }

  /* fotos do topo trocando */
  var ims = $$('.hero .bgs img');
  if (ims.length > 1) { var i = 0; setInterval(function () { ims[i].classList.remove('on'); i = (i + 1) % ims.length; ims[i].classList.add('on'); }, 6000); }

  /* elementos aparecem ao rolar */
  var rv = $$('.rv');
  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }); }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    rv.forEach(function (el) { io.observe(el); });
  } else { b.classList.add('sem-anim'); }

  /* foto flutuante ao passar o mouse nos eventos (computador) */
  var pf = $('#prevFlut');
  if (pf && matchMedia('(hover:hover)').matches) {
    $$('.ev-linha[data-img]').forEach(function (l) {
      l.addEventListener('mouseenter', function () { $('img', pf).src = l.dataset.img; pf.classList.add('on'); });
      l.addEventListener('mouseleave', function () { pf.classList.remove('on'); });
      l.addEventListener('mousemove', function (e) { pf.style.left = e.clientX + 'px'; pf.style.top = e.clientY + 'px'; });
    });
  }
})();

/* Logo do tema do ano com fundo branco (JPG): recorta o espaço vazio e mostra o logo direto no fundo escuro. */
(function () {
  var im = document.querySelector('.ano-img img');
  if (!im) return;
  function go() {
    try {
      var W = im.naturalWidth, H = im.naturalHeight;
      if (!W || im.dataset.zoeOk) return;
      im.dataset.zoeOk = 1;
      var s = Math.min(1, 600 / W), c = document.createElement('canvas');
      c.width = Math.round(W * s); c.height = Math.round(H * s);
      var x = c.getContext('2d'); x.drawImage(im, 0, 0, c.width, c.height);
      var d = x.getImageData(0, 0, c.width, c.height).data, b = 0, n = 0, x0 = c.width, y0 = c.height, x1 = 0, y1 = 0;
      for (var y = 0; y < c.height; y += 2) for (var i = 0; i < c.width; i += 2) {
        var k = (y * c.width + i) * 4; n++;
        if (d[k] > 232 && d[k + 1] > 232 && d[k + 2] > 232) b++;
        else { if (i < x0) x0 = i; if (i > x1) x1 = i; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      }
      if (b / n < 0.6 || x1 <= x0) return; // é foto, não logo: deixa como está
      var m = Math.round(c.width * 0.05);
      x0 = Math.max(0, x0 - m); y0 = Math.max(0, y0 - m); x1 = Math.min(c.width, x1 + m); y1 = Math.min(c.height, y1 + m);
      var o = document.createElement('canvas');
      o.width = Math.round((x1 - x0) / s); o.height = Math.round((y1 - y0) / s);
      o.getContext('2d').drawImage(im, x0 / s, y0 / s, o.width, o.height, 0, 0, o.width, o.height);
      im.removeAttribute('style');
      im.src = o.toDataURL('image/png');
      im.parentNode.classList.add('sem-fundo');
    } catch (e) {}
  }
  if (im.complete) go(); else im.addEventListener('load', go, { once: true });
})();
