<?php
/**
 * Confirmação da inscrição (HTML). Usado no lugar de "Processando pedido" e "Pedido concluído".
 * O conteúdo fica em inc/emails.php.
 *
 * @var WC_Order $order
 */
if (!defined('ABSPATH')) {
    exit;
}
if (isset($order) && is_a($order, 'WC_Order') && function_exists('zoe_conf_html')) {
    echo zoe_conf_html($order); // phpcs:ignore
}
