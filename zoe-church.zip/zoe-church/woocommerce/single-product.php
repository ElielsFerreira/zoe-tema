<?php
/* Página do evento (produto do WooCommerce) no estilo do tema. */
defined('ABSPATH') || exit;
get_header();
while (have_posts()) :
    the_post();
    global $product;
    if (!$product instanceof WC_Product) {
        $product = wc_get_product(get_the_ID());
    }
    $id    = $product->get_id();
    $data  = get_post_meta($id, '_zoe_data', true);
    $prazo = get_post_meta($id, '_zoe_prazo', true);
    $local = get_post_meta($id, '_zoe_local', true);
    $img   = wp_get_attachment_image_url($product->get_image_id(), 'large');
    $ok    = $product->is_purchasable() && $product->is_in_stock();
    ?>
    <div class="wrap">
        <?php woocommerce_output_all_notices(); ?>
        <div class="ev-hero"><a href="<?php echo esc_url(zoe_url_eventos()); ?>" class="link-sub" style="font-size:14px;border:0">← Eventos</a>
            <h1><?php the_title(); ?></h1>
            <?php if ($data || $local || $prazo) : ?>
            <div class="ev-meta">
                <?php if ($data) : ?><div><span>Data</span><b><?php echo esc_html(zoe_data_br($data)); ?></b></div><?php endif; ?>
                <?php if ($local) : ?><div><span>Local</span><b><?php echo esc_html($local); ?></b></div><?php endif; ?>
                <?php if ($prazo) : ?><div><span>Inscrições até</span><b><?php echo esc_html(zoe_data_br($prazo)); ?></b></div><?php endif; ?>
            </div>
            <?php else : ?><div style="height:clamp(22px,4vw,40px)"></div><?php endif; ?>
        </div>
        <div class="ev-corpo">
            <div>
                <?php if ($img) : ?><div class="capa"><img src="<?php echo esc_url($img); ?>" alt="<?php the_title_attribute(); ?>"<?php echo zoe_pos_attr(get_post_meta($id, '_zoe_img_pos', true)); // phpcs:ignore ?> fetchpriority="high"></div><?php endif; ?>
                <?php if ($product->get_short_description()) : ?><div class="desc" style="margin-top:28px;font-size:19px;font-weight:500;color:var(--tinta)"><?php echo wp_kses_post(wpautop($product->get_short_description())); ?></div><?php endif; ?>
                <?php if (!post_password_required($id)) : ?><div class="desc entry"><?php the_content(); ?></div><?php endif; ?>
            </div>
            <div class="caixa-compra">
                <?php if (post_password_required($id)) : ?>
                    <span class="eyebrow">Inscrição com senha</span>
                    <p class="meta" style="margin:8px 0 14px">Esta inscrição é só para alunos/participantes. Digite a senha que você recebeu da equipe.</p>
                    <?php echo get_the_password_form($id); // phpcs:ignore ?>
                <?php elseif ($ok) : ?>
                    <span class="eyebrow">Investimento</span>
                    <div class="preco" style="margin:10px 0 20px"><?php echo wp_kses_post($product->get_price_html()); ?></div>
                    <?php woocommerce_template_single_add_to_cart(); ?>
                    <p class="meta" style="text-align:center;margin:14px 0 0">Pagamento por PIX ou cartão</p>
                <?php else : ?>
                    <span class="eyebrow">Status</span>
                    <p class="zoe-encerrado">Inscrições encerradas</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if (current_user_can('edit_products')) : ?><a class="btn edit-flut" href="<?php echo esc_url(function_exists('zoe_url_painel') ? zoe_url_painel('editar/' . $id) : get_edit_post_link($id)); ?>"><?php echo zoe_ic('lapis'); // phpcs:ignore ?> Editar este evento</a><?php endif; ?>
<?php endwhile;
get_footer();
