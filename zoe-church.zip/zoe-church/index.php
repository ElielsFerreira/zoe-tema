<?php
get_header();
$loja = function_exists('is_checkout') && (is_cart() || is_checkout() || is_account_page());
?>
<div class="conteudo-pagina"><div class="wrap">
<?php if ($loja) : ?>
    <?php if (is_checkout() && !is_wc_endpoint_url('order-received')) : ?><div class="passos"><span>Carrinho</span>/<b>Dados</b>/<span>Pagamento</span></div><?php endif; ?>
    <h1 class="pag-titulo"><?php
        if (is_wc_endpoint_url('order-received')) { echo 'Inscrição <span class="serif">recebida</span>'; }
        elseif (is_checkout()) { echo 'Finalizar <span class="serif">inscrição</span>'; }
        elseif (is_cart()) { echo 'Carrinho'; }
        else { echo 'Minhas <span class="serif">inscrições</span>'; } ?></h1>
    <div class="woocommerce-page-zoe" style="margin-top:24px"><?php
        // ignora o conteúdo antigo da página (Elementor) e usa direto o WooCommerce
        if (is_checkout()) { echo do_shortcode('[woocommerce_checkout]'); }
        elseif (is_cart()) { echo do_shortcode('[woocommerce_cart]'); }
        else { echo do_shortcode('[woocommerce_my_account]'); } ?></div>
<?php elseif (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class(); ?>>
            <?php if (!(defined('ELEMENTOR_VERSION') && get_post_meta(get_the_ID(), '_elementor_edit_mode', true) === 'builder')) : ?>
                <h1 class="pag-titulo"><?php echo zoe_serif(get_the_title()); // phpcs:ignore ?></h1>
                <?php if (has_post_thumbnail() && !is_page()) { echo '<div style="margin:24px 0">'; the_post_thumbnail('large'); echo '</div>'; } ?>
            <?php endif; ?>
            <div class="entry"><?php the_content(); ?></div>
        </article>
    <?php endwhile; ?>
    <?php if (!is_singular()) { the_posts_pagination(); } ?>
<?php else : ?>
    <h1 class="pag-titulo">Página não <span class="serif">encontrada</span></h1>
    <p class="sub" style="margin-top:16px">O endereço pode ter mudado.</p>
    <a class="btn" href="<?php echo esc_url(home_url('/')); ?>">Voltar ao início <span class="seta">→</span></a>
<?php endif; ?>
</div></div>
<?php get_footer();
