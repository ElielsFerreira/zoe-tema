<?php
/**
 * E-mail de confirmação da inscrição (substitui o "Processando pedido" e o "Pedido concluído" do WooCommerce).
 *
 * - Visual da Zoe, com evento, data, local, inscritos, valor pago e a mensagem do evento
 *   (campo "Mensagem no e-mail de confirmação" do painel = nota de compra do produto).
 * - Link do grupo do WhatsApp na mensagem vira botão verde.
 * - Quem já recebeu a confirmação não recebe de novo quando o pedido é marcado como concluído.
 */
if (!defined('ABSPATH')) {
    exit;
}

/* ---------- dados ---------- */

/** Nome do participante a partir das respostas de uma inscrição (rótulo => valor). */
function zoe_conf_nome_insc($linha)
{
    if (!is_array($linha)) {
        return '';
    }
    $n = array();
    foreach ($linha as $rot => $val) {
        $n[remove_accents(mb_strtolower((string) $rot))] = trim((string) $val);
    }
    if (!empty($n['nome completo'])) {
        return $n['nome completo'];
    }
    if (!empty($n['nome do homem']) || !empty($n['nome da mulher'])) {
        return trim(implode(' e ', array_filter(array($n['nome do homem'] ?? '', $n['nome da mulher'] ?? ''))));
    }
    foreach ($n as $rot => $val) {
        if ($val !== '' && strpos($rot, 'nome') !== false && strpos($rot, 'respons') === false) {
            return $val;
        }
    }
    return '';
}

/** Itens do pedido prontos para o e-mail. */
function zoe_conf_itens($order)
{
    $out = array();
    foreach ($order->get_items() as $item) {
        if (!is_a($item, 'WC_Order_Item_Product')) {
            continue;
        }
        $pid   = (int) $item->get_product_id();
        $prod  = $item->get_product();
        $pai   = $pid ? wc_get_product($pid) : null;
        $nomes = array();
        $insc  = $item->get_meta('_zoe_inscricoes');
        if (is_array($insc)) {
            foreach ($insc as $l) {
                $nm = zoe_conf_nome_insc($l);
                if ($nm !== '') {
                    $nomes[] = $nm;
                }
            }
        }
        $opcao = '';
        if ($prod && $prod->is_type('variation')) {
            $opcao = wc_get_formatted_variation($prod, true, false, false);
        }
        $img = '';
        if ($prod && $prod->get_image_id()) {
            $img = wp_get_attachment_image_url($prod->get_image_id(), 'woocommerce_thumbnail');
        } elseif ($pai && $pai->get_image_id()) {
            $img = wp_get_attachment_image_url($pai->get_image_id(), 'woocommerce_thumbnail');
        }
        $out[] = array(
            'pid'    => $pid,
            'nome'   => $pai ? $pai->get_name() : $item->get_name(),
            'opcao'  => $opcao,
            'qtd'    => (int) $item->get_quantity(),
            'valor'  => $order->get_formatted_line_subtotal($item),
            'data'   => $pid ? (string) get_post_meta($pid, '_zoe_data', true) : '',
            'fim'    => $pid ? (string) get_post_meta($pid, '_zoe_data_fim', true) : '',
            'local'  => $pid ? (string) get_post_meta($pid, '_zoe_local', true) : '',
            'nomes'  => $nomes,
            'nota'   => $pai ? trim(wp_strip_all_tags((string) $pai->get_purchase_note())) : '',
            'img'    => $img ? $img : '',
            // quase tudo na loja é inscrição; mensalidades e ofertas são "pagamento"
            'evento' => !preg_match('/mensalidade|doa[cç][aã]o|oferta|contribui|d[ií]zimo/iu', $pai ? $pai->get_name() : $item->get_name()),
        );
    }
    return $out;
}

function zoe_conf_e_inscricao($order)
{
    foreach (zoe_conf_itens($order) as $i) {
        if ($i['evento']) {
            return true;
        }
    }
    return false;
}

function zoe_conf_nome_completo($order)
{
    if (function_exists('zoe_pend_contato')) {
        $c = zoe_pend_contato($order);
        return trim((string) $c['nome']);
    }
    return trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
}

function zoe_conf_primeiro_nome($order)
{
    $n = zoe_conf_nome_completo($order);
    return $n ? mb_convert_case(mb_strtolower(strtok($n, ' ')), MB_CASE_TITLE) : '';
}

/** Um dia ("sábado, 15 de novembro de 2026") ou vários ("de sexta a domingo, 4 a 6 de dezembro de 2026"). */
function zoe_conf_quando($ini, $fim)
{
    $a = $ini ? strtotime($ini . ' 12:00:00') : 0;
    $b = $fim ? strtotime($fim . ' 12:00:00') : 0;
    if (!$a) {
        return '';
    }
    if (!$b || $b <= $a) {
        return zoe_conf_data_longa($ini);
    }
    $dias  = array('domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado');
    $meses = array('janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro');
    $wa = $dias[(int) gmdate('w', $a)];
    $wb = $dias[(int) gmdate('w', $b)];
    $da = (int) gmdate('j', $a);
    $db = (int) gmdate('j', $b);
    $ma = $meses[(int) gmdate('n', $a) - 1];
    $mb = $meses[(int) gmdate('n', $b) - 1];
    $ya = gmdate('Y', $a);
    $yb = gmdate('Y', $b);
    $semana = 'de ' . $wa . ' a ' . $wb . ', ';
    if ($ma === $mb && $ya === $yb) {
        return $semana . $da . ' a ' . $db . ' de ' . $mb . ' de ' . $yb;
    }
    return $semana . $da . ' de ' . $ma . ($ya !== $yb ? ' de ' . $ya : '') . ' a ' . $db . ' de ' . $mb . ' de ' . $yb;
}

/** "sábado, 15 de novembro de 2026" */
function zoe_conf_data_longa($ymd)
{
    $t = $ymd ? strtotime($ymd . ' 12:00:00') : 0;
    if (!$t) {
        return '';
    }
    $dias  = array('domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado');
    $meses = array('janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro');
    return $dias[(int) gmdate('w', $t)] . ', ' . (int) gmdate('j', $t) . ' de ' . $meses[(int) gmdate('n', $t) - 1] . ' de ' . gmdate('Y', $t);
}

function zoe_conf_link_agenda($nome, $ymd, $local, $fim = '')
{
    $t = $ymd ? strtotime($ymd . ' 12:00:00') : 0;
    if (!$t) {
        return '';
    }
    $tf = $fim ? strtotime($fim . ' 12:00:00') : 0;
    $tf = $tf && $tf > $t ? $tf : $t;
    return 'https://calendar.google.com/calendar/render?action=TEMPLATE'
        . '&text=' . rawurlencode($nome)
        . '&dates=' . gmdate('Ymd', $t) . '/' . gmdate('Ymd', $tf + DAY_IN_SECONDS)
        . '&location=' . rawurlencode($local)
        . '&details=' . rawurlencode('Inscrição confirmada · ' . get_bloginfo('name'));
}

/* ---------- HTML ---------- */

function zoe_conf_botao($url, $txt, $fundo = '#141216', $cor = '#ffffff')
{
    return '<table role="presentation" border="0" cellpadding="0" cellspacing="0" style="margin:6px 0"><tr><td style="background:' . $fundo . ';border-radius:999px">'
        . '<a href="' . esc_url($url) . '" style="display:inline-block;padding:13px 24px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:bold;color:' . $cor . ';text-decoration:none;border-radius:999px">' . esc_html($txt) . '</a>'
        . '</td></tr></table>';
}

/** Texto da mensagem do evento: quebra de linha, links clicáveis e link de grupo do WhatsApp como botão. */
function zoe_conf_nota_html($txt)
{
    $grupos = array();
    $txt    = preg_replace_callback('~https?://chat\.whatsapp\.com/[A-Za-z0-9]+~', function ($m) use (&$grupos) {
        $grupos[] = $m[0];
        return '';
    }, $txt);
    $txt  = trim(preg_replace("/[ \t]*[:\-–]?[ \t]*\n/", "\n", trim($txt)));
    $html = '';
    if ($txt !== '') {
        $html .= '<p style="margin:0 0 10px">' . nl2br(make_clickable(esc_html($txt))) . '</p>';
    }
    foreach (array_unique($grupos) as $g) {
        $html .= zoe_conf_botao($g, 'Entrar no grupo do WhatsApp', '#25D366');
    }
    return $html;
}

/* ---------- visual (compartilhado com os avisos em massa) ---------- */

/** Imagem de capa do e-mail de um evento (meta _zoe_email_img: id da biblioteca ou URL). */
function zoe_conf_capa($pid)
{
    $v = $pid ? trim((string) get_post_meta($pid, '_zoe_email_img', true)) : '';
    if ($v === '') {
        return '';
    }
    if (ctype_digit($v)) {
        $u = wp_get_attachment_image_url((int) $v, 'full');
        return $u ? $u : '';
    }
    return esc_url_raw($v);
}

/** Grava (ou remove, com vazio) a capa do e-mail. Aceita id da biblioteca ou URL de imagem (é importada para a biblioteca). */
function zoe_conf_definir_capa($pid, $val)
{
    $val = trim((string) $val);
    if ($val === '') {
        delete_post_meta($pid, '_zoe_email_img');
        return 0;
    }
    if (ctype_digit($val)) {
        if (!wp_attachment_is_image((int) $val)) {
            return new WP_Error('img', 'Essa imagem não existe na biblioteca.');
        }
        update_post_meta($pid, '_zoe_email_img', (int) $val);
        return (int) $val;
    }
    if (!wp_http_validate_url($val)) {
        return new WP_Error('img', 'Endereço de imagem inválido.');
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $id = media_sideload_image($val, $pid, get_the_title($pid) . ' · e-mail', 'id');
    if (is_wp_error($id)) {
        return $id;
    }
    update_post_meta($pid, '_zoe_email_img', (int) $id);
    return (int) $id;
}

/**
 * Moldura dos e-mails da Zoe: fundo areia, cartão claro, tipografia da casa
 * (serifada itálica nos títulos), capa opcional no topo e rodapé discreto.
 */
function zoe_email_moldura($titulo, $corpo, $capa = '', $capaLink = '')
{
    $sans  = "font-family:'Inter Tight',Helvetica,Arial,sans-serif;";
    $site  = get_bloginfo('name');
    $logo  = function_exists('zoe_img') && function_exists('zoe_opt') ? zoe_img(zoe_opt('logo'), 'thumbnail') : '';
    $insta = function_exists('zoe_opt') ? (string) zoe_opt('instagram') : '';
    $whats = function_exists('zoe_opt') && function_exists('zoe_link_whats') ? zoe_link_whats(zoe_opt('whatsapp')) : '';
    $host  = wp_parse_url(home_url(), PHP_URL_HOST);
    $topo  = '';
    if ($capa) {
        $img  = '<img src="' . esc_url($capa) . '" width="560" alt="' . esc_attr($titulo) . '" style="display:block;width:100%;max-width:560px;height:auto;border:0">';
        $topo = '<tr><td style="line-height:0;font-size:0">' . ($capaLink ? '<a href="' . esc_url($capaLink) . '">' . $img . '</a>' : $img) . '</td></tr>';
    } elseif ($logo) {
        $topo = '<tr><td align="center" style="padding:32px 32px 0"><img src="' . esc_url($logo) . '" width="44" height="44" alt="Zoe" style="display:block;width:44px;height:44px;border:0;border-radius:50%"></td></tr>';
    }
    $links = array();
    if ($whats) {
        $links[] = '<a href="' . esc_url($whats) . '" style="color:#6f6a74;text-decoration:underline">WhatsApp</a>';
    }
    if ($insta) {
        $links[] = '<a href="' . esc_url($insta) . '" style="color:#6f6a74;text-decoration:underline">Instagram</a>';
    }
    $links[] = '<a href="' . esc_url(home_url('/')) . '" style="color:#6f6a74;text-decoration:underline">' . esc_html($host) . '</a>';

    return '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>' . esc_html($titulo) . '</title></head>'
        . '<body style="margin:0;padding:0;background:#f3f0ea">'
        . '<div style="display:none;max-height:0;overflow:hidden;opacity:0">' . esc_html($titulo) . '</div>'
        . '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="background:#f3f0ea"><tr><td align="center" style="padding:28px 12px 40px">'
        . '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fbfaf7">'
        . $topo
        . '<tr><td style="padding:36px 32px 32px;' . $sans . 'color:#141216">' . $corpo . '</td></tr>'
        . '</table>'
        . '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width:560px"><tr><td align="center" style="padding:22px 20px 0;' . $sans . 'font-size:12px;line-height:1.8;color:#8d8792">'
        . '<span style="letter-spacing:.18em;text-transform:uppercase;font-weight:600;color:#6f6a74">' . esc_html($site) . '</span><br>'
        . implode(' &nbsp;·&nbsp; ', $links)
        . '</td></tr></table>'
        . '</td></tr></table></body></html>';
}

/** Pedacinhos de texto do e-mail. */
function zoe_email_eyebrow($txt)
{
    return '<div style="font-size:11px;letter-spacing:.2em;text-transform:uppercase;font-weight:600;color:#6f6a74;margin:0 0 14px">' . esc_html($txt) . '</div>';
}

function zoe_email_titulo($txt)
{
    return '<h1 style="margin:0 0 14px;font-family:\'Instrument Serif\',Georgia,\'Times New Roman\',serif;font-style:italic;font-weight:400;font-size:34px;line-height:1.1;color:#141216">' . esc_html($txt) . '</h1>';
}

function zoe_conf_html($order)
{
    $itens = zoe_conf_itens($order);
    $quem  = zoe_conf_nome_completo($order);
    foreach ($itens as $n => $it) {
        if (!$it['nomes'] && $quem && $it['evento'] && $n === 0) {
            $itens[$n]['nomes'] = array($quem); // formulário antigo: só tinha os dados de quem comprou
        }
    }
    $insc    = zoe_conf_e_inscricao($order);
    $nome    = zoe_conf_primeiro_nome($order);
    $pago    = $order->is_paid();
    $titulo  = $insc ? ($pago ? 'Inscrição confirmada' : 'Inscrição recebida') : ($pago ? 'Pagamento confirmado' : 'Pedido recebido');
    $dataPed = $order->get_date_paid() ? $order->get_date_paid() : $order->get_date_created();

    // Mensagem personalizada do evento (Painel/conector), capa do evento e mensagem extra de um envio em massa.
    $msgEv = '';
    $capa  = '';
    $link  = '';
    foreach ($itens as $it) {
        if (!$it['evento'] || !$it['pid']) {
            continue;
        }
        if ($msgEv === '' && trim((string) get_post_meta($it['pid'], '_zoe_email_msg', true)) !== '') {
            $msgEv = zoe_conf_tokens((string) get_post_meta($it['pid'], '_zoe_email_msg', true), $order);
        }
        if ($capa === '') {
            $capa = zoe_conf_capa($it['pid']);
            $link = $capa ? get_permalink($it['pid']) : '';
        }
    }
    $extra = !empty($GLOBALS['zoe_conf_extra']) ? zoe_conf_tokens((string) $GLOBALS['zoe_conf_extra'], $order) : '';

    if ($insc && $pago && !empty($GLOBALS['zoe_conf_retro'])) {
        $padrao = 'Passando para lembrar: sua vaga está garantida. Seguem os detalhes.';
    } elseif ($insc && $pago) {
        $padrao = 'Sua vaga está garantida. Te esperamos!';
    } elseif ($insc) {
        $padrao = 'Recebemos sua inscrição. Assim que o pagamento for aprovado, sua vaga fica garantida.';
    } elseif ($pago) {
        $padrao = 'Recebemos seu pagamento. Obrigado!';
    } else {
        $padrao = 'Recebemos seu pedido.';
    }

    $txt  = 'font-size:16px;line-height:1.65;color:#3d3a40';
    $miud = 'font-size:14px;line-height:1.7;color:#3d3a40';
    $linha = '<div style="height:1px;line-height:1px;font-size:0;background:#e7e2da;margin:28px 0">&nbsp;</div>';

    $c  = zoe_email_eyebrow(($pago ? '✓ ' : '') . $titulo);
    $c .= zoe_email_titulo('Olá' . ($nome ? ', ' . $nome : '') . '.');
    if ($extra) {
        $c .= '<div style="' . $txt . ';border-left:2px solid #141216;padding:2px 0 2px 16px;margin:0 0 16px">' . zoe_msg_html($extra) . '</div>';
    }
    $c .= '<div style="' . $txt . '">' . ($msgEv && $pago ? zoe_msg_html($msgEv) : '<p style="margin:0">' . esc_html($padrao) . '</p>') . '</div>';

    foreach ($itens as $i) {
        $quando = zoe_conf_quando($i['data'], $i['fim']);
        if ($i['evento'] && count($i['nomes']) === 1 && $i['qtd'] > 1) {
            $i['nomes'][0] .= ' (e mais ' . ($i['qtd'] - 1) . ')';
        }
        $agenda = zoe_conf_link_agenda($i['nome'], $i['data'], $i['local'], $i['fim']);
        $c .= $linha;
        $c .= '<div style="font-size:18px;font-weight:600;line-height:1.3;color:#141216;margin:0 0 10px">' . esc_html($i['nome']) . '</div>';
        $c .= '<div style="' . $miud . '">';
        if ($i['opcao']) {
            $c .= esc_html($i['opcao']) . '<br>';
        }
        if ($quando) {
            $c .= esc_html(ucfirst($quando)) . '<br>';
        }
        if ($i['local']) {
            $c .= esc_html($i['local']) . '<br>';
        }
        if ($i['nomes']) {
            $c .= '<span style="color:#6f6a74">' . (count($i['nomes']) > 1 ? 'Inscritos: ' : 'Inscrito: ') . '</span>' . implode(', ', array_map('esc_html', $i['nomes'])) . '<br>';
        }
        $c .= '</div>';
        if ($i['nota'] && $pago) {
            $c .= '<div style="' . $miud . ';margin-top:12px">' . zoe_conf_nota_html($i['nota']) . '</div>';
        }
        if ($agenda && $pago) {
            $c .= '<div style="font-size:13px;margin-top:12px"><a href="' . esc_url($agenda) . '" style="color:#141216;font-weight:600;text-decoration:underline">Adicionar à agenda</a></div>';
        }
    }

    $c .= $linha;
    $c .= '<div style="font-size:13px;line-height:1.7;color:#6f6a74">'
        . 'Pedido nº ' . esc_html($order->get_order_number())
        . ($dataPed ? ' · ' . esc_html($dataPed->date_i18n('d/m/Y')) : '')
        . ' · ' . ($pago ? 'pago ' : 'total ') . wp_kses_post($order->get_formatted_order_total())
        . '</div>';
    if ($insc) {
        $c .= '<div style="font-size:13px;line-height:1.7;color:#6f6a74;margin-top:4px">No dia, é só dizer seu nome na recepção.</div>';
    }

    return zoe_email_moldura($titulo . ($itens ? ' · ' . $itens[0]['nome'] : ''), $c, $capa, $link);
}

/* ---------- ligação com o WooCommerce ---------- */

// Assunto e título
foreach (array('customer_processing_order', 'customer_completed_order') as $zoe_conf_id) {
    add_filter('woocommerce_email_subject_' . $zoe_conf_id, function ($assunto, $order) {
        if (!is_a($order, 'WC_Order')) {
            return $assunto;
        }
        $itens = zoe_conf_itens($order);
        if (!empty($GLOBALS['zoe_conf_assunto'])) {
            return zoe_conf_tokens((string) $GLOBALS['zoe_conf_assunto'], $order);
        }
        foreach ($itens as $it) {
            $a = $it['pid'] ? trim((string) get_post_meta($it['pid'], '_zoe_email_assunto', true)) : '';
            if ($a !== '') {
                return zoe_conf_tokens($a, $order);
            }
        }
        $nomes = implode(', ', array_unique(wp_list_pluck($itens, 'nome')));
        $tit   = zoe_conf_e_inscricao($order) ? 'Inscrição confirmada' : 'Pagamento confirmado';
        return $tit . ($nomes ? ': ' . $nomes : '');
    }, 20, 2);
}

// Usa o modelo da Zoe no lugar do modelo do WooCommerce (só na versão HTML)
add_filter('wc_get_template', function ($arquivo, $nome) {
    if (in_array($nome, array('emails/customer-processing-order.php', 'emails/customer-completed-order.php'), true)) {
        return get_template_directory() . '/woocommerce/emails/zoe-confirmacao.php';
    }
    return $arquivo;
}, 20, 2);

// Marca que a confirmação já foi enviada
add_action('woocommerce_email_sent', function ($ok, $id, $email) {
    if ($ok && in_array($id, array('customer_processing_order', 'customer_completed_order'), true) && isset($email->object) && is_a($email->object, 'WC_Order')) {
        $email->object->update_meta_data('_zoe_confirmacao', time());
        $email->object->save_meta_data();
    }
}, 10, 3);

// Não manda a mesma confirmação duas vezes (pagamento aprovado e, depois, pedido concluído)
add_filter('woocommerce_email_enabled_customer_completed_order', function ($ativo, $order) {
    // reenvio pedido de propósito pelo menu "Ações do pedido" continua funcionando
    $reenvio = isset($_POST['wc_order_action']) && 'send_email_customer_completed_order' === $_POST['wc_order_action']; // phpcs:ignore
    if ($ativo && !$reenvio && is_a($order, 'WC_Order') && $order->get_meta('_zoe_confirmacao')) {
        return false;
    }
    return $ativo;
}, 20, 2);

/* ---------- reenvio (painel / retroativo) ---------- */

/** Pedidos pagos de um produto desde N dias atrás. */
function zoe_conf_pedidos_do_produto($produto, $dias)
{
    global $wpdb;
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
         JOIN {$wpdb->prefix}woocommerce_order_itemmeta im ON im.order_item_id = oi.order_item_id
         WHERE oi.order_item_type = 'line_item' AND im.meta_key = '_product_id' AND im.meta_value = %d",
        (int) $produto
    ));
    $limite = time() - max(1, (int) $dias) * DAY_IN_SECONDS;
    $out    = array();
    foreach ($ids as $id) {
        $o = wc_get_order((int) $id);
        if (!$o || !is_a($o, 'WC_Order') || !in_array($o->get_status(), array('processing', 'completed'), true)) {
            continue;
        }
        $d = $o->get_date_paid() ? $o->get_date_paid() : $o->get_date_created();
        if (!$d || $d->getTimestamp() < $limite) {
            continue;
        }
        $out[] = $o;
    }
    usort($out, function ($a, $b) {
        return $a->get_id() - $b->get_id();
    });
    return $out;
}

function zoe_conf_email($order)
{
    $e = (string) $order->get_billing_email();
    if (!$e && function_exists('zoe_pend_contato')) {
        $c = zoe_pend_contato($order);
        $e = (string) $c['email'];
    }
    return is_email($e) ? $e : '';
}

function zoe_conf_enviar($order, $retro = false)
{
    $dest = zoe_conf_email($order);
    $mailer = WC()->mailer();
    $emails = $mailer->get_emails();
    if (empty($emails['WC_Email_Customer_Processing_Order']) || !$dest) {
        return false;
    }
    $GLOBALS['zoe_conf_retro'] = $retro;
    $em = $emails['WC_Email_Customer_Processing_Order'];
    $ok = false;
    $pega = function ($r, $id) use (&$ok) {
        if ('customer_processing_order' === $id) {
            $ok = (bool) $r;
        }
    };
    $para = function () use ($dest) {
        return $dest;
    };
    add_action('woocommerce_email_sent', $pega, 5, 2);
    add_filter('woocommerce_email_recipient_customer_processing_order', $para, 99);
    $em->trigger($order->get_id(), $order);
    remove_filter('woocommerce_email_recipient_customer_processing_order', $para, 99);
    remove_action('woocommerce_email_sent', $pega, 5);
    $GLOBALS['zoe_conf_retro'] = false;
    if ($ok) {
        $order = wc_get_order($order->get_id());
        $order->update_meta_data('_zoe_conf_reenvio', time());
        $order->save_meta_data();
        $order->add_order_note('Confirmação da inscrição enviada por e-mail para ' . $dest . ($retro ? ' (reenvio)' : '') . '.');
    }
    return $ok;
}

add_action('rest_api_init', function () {
    $pode = function () {
        return current_user_can('manage_woocommerce');
    };
    register_rest_route('zoe/v1', '/confirmacao/lista', array(
        'methods'             => 'GET',
        'permission_callback' => $pode,
        'callback'            => function ($q) {
            $out = array();
            foreach (zoe_conf_pedidos_do_produto((int) $q['produto'], (int) ($q['dias'] ? $q['dias'] : 60)) as $o) {
                $d = $o->get_date_paid() ? $o->get_date_paid() : $o->get_date_created();
                $out[] = array(
                    'id'       => $o->get_id(),
                    'numero'   => $o->get_order_number(),
                    'data'     => $d ? $d->date_i18n('d/m/Y H:i') : '',
                    'nome'     => zoe_conf_nome_completo($o),
                    'email'    => zoe_conf_email($o),
                    'novo'     => (bool) $o->get_meta('_zoe_confirmacao'),
                    'reenvio'  => (bool) $o->get_meta('_zoe_conf_reenvio'),
                );
            }
            return $out;
        },
    ));
    register_rest_route('zoe/v1', '/confirmacao/enviar', array(
        'methods'             => 'POST',
        'permission_callback' => $pode,
        'callback'            => function ($q) {
            $d   = $q->get_json_params();
            $res = array();
            foreach (array_slice(array_map('absint', (array) (isset($d['ids']) ? $d['ids'] : array())), 0, 10) as $id) {
                $o = wc_get_order($id);
                if (!$o || !is_a($o, 'WC_Order') || !$o->is_paid()) {
                    $res[$id] = 'pulado';
                    continue;
                }
                $res[$id] = zoe_conf_enviar($o, !empty($d['retro'])) ? 'ok' : 'falhou';
            }
            return $res;
        },
    ));
    // Capa do e-mail de um evento: {"evento_id": 123, "imagem": "<id da biblioteca ou URL>"} (vazio remove)
    register_rest_route('zoe/v1', '/email-imagem', array(
        'methods'             => 'POST',
        'permission_callback' => $pode,
        'callback'            => function ($q) {
            $d   = $q->get_json_params();
            $pid = absint(isset($d['evento_id']) ? $d['evento_id'] : 0);
            if (!$pid || get_post_type($pid) !== 'product') {
                return new WP_Error('nao', 'Evento não encontrado', array('status' => 404));
            }
            $r = zoe_conf_definir_capa($pid, isset($d['imagem']) ? $d['imagem'] : '');
            if (is_wp_error($r)) {
                return $r;
            }
            return array('ok' => true, 'evento' => get_the_title($pid), 'imagem_id' => $r, 'imagem' => zoe_conf_capa($pid));
        },
    ));
    register_rest_route('zoe/v1', '/confirmacao/previa/(?P<id>\d+)', array(
        'methods'             => 'GET',
        'permission_callback' => $pode,
        'callback'            => function ($q) {
            $o = wc_get_order((int) $q['id']);
            if (!$o || !is_a($o, 'WC_Order')) {
                return new WP_Error('nao', 'Pedido não encontrado', array('status' => 404));
            }
            $GLOBALS['zoe_conf_retro'] = !empty($q['retro']);
            $html = zoe_conf_html($o);
            $GLOBALS['zoe_conf_retro'] = false;
            return array('html' => $html);
        },
    ));
});
