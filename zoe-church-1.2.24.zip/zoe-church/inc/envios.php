<?php

/**
 * Mensagens personalizadas e envios de e-mail em massa para inscritos.
 *
 * - Cada evento pode ter assunto e mensagem próprios no e-mail de confirmação
 *   (metas _zoe_email_assunto e _zoe_email_msg). Aceitam {nome} e {evento}.
 * - Envio em massa: "confirmacao" reenvia a confirmação de cada pedido (com
 *   assunto/mensagem extra opcionais); "aviso" manda um e-mail livre, com o
 *   visual da Zoe, uma vez por endereço.
 * - Os envios vão em lotes pequenos (8 por minuto), em segundo plano, para
 *   não estourar o limite de e-mails por hora da hospedagem.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_ENVIO_LOTE', 8);

/** Troca {nome} e {evento} pelos dados do pedido. */
function zoe_conf_tokens($txt, $order = null, $nome = '', $evento = '')
{
    if ($order) {
        $nome = zoe_conf_primeiro_nome($order);
        $its  = zoe_conf_itens($order);
        $evento = $its ? $its[0]['nome'] : '';
    }
    $txt = (string) $txt;
    if (trim($nome) === '') {
        // sem nome no pedido: "Oi {nome}!" vira "Oi!" e "Tudo certo, {nome}!" vira "Tudo certo!"
        $txt = preg_replace('/[,\s]*\{nome\}/u', '', $txt);
    }
    return strtr($txt, array('{nome}' => $nome, '{evento}' => $evento));
}

/** Mensagem livre: quebras de linha, links clicáveis, link de grupo do WhatsApp vira botão. */
function zoe_msg_html($txt)
{
    $grupos = array();
    $txt = preg_replace_callback('~https?://chat\.whatsapp\.com/[A-Za-z0-9]+~', function ($m) use (&$grupos) {
        $grupos[] = $m[0];
        return '';
    }, (string) $txt);
    $html = '';
    foreach (preg_split("/\n\s*\n/", trim($txt)) as $par) {
        if (trim($par) !== '') {
            $html .= '<p style="margin:0 0 12px">' . nl2br(make_clickable(esc_html(trim($par)))) . '</p>';
        }
    }
    foreach (array_unique($grupos) as $g) {
        $html .= zoe_conf_botao($g, 'Entrar no grupo do WhatsApp', '#25D366');
    }
    return $html;
}

/** E-mail livre com o visual da Zoe (mesma moldura da confirmação). */
function zoe_aviso_html($assunto, $mensagem, $nome = '')
{
    $c  = zoe_email_titulo($nome ? 'Olá, ' . $nome . '.' : $assunto);
    $c .= '<div style="font-size:16px;line-height:1.65;color:#3d3a40">' . zoe_msg_html($mensagem) . '</div>';
    return zoe_email_moldura($assunto, $c);
}

function zoe_aviso_enviar($para, $assunto, $mensagem, $nome = '', $evento = '')
{
    $assunto  = zoe_conf_tokens($assunto, null, $nome, $evento);
    $mensagem = zoe_conf_tokens($mensagem, null, $nome, $evento);
    return wp_mail($para, $assunto, zoe_aviso_html($assunto, $mensagem, $nome), array('Content-Type: text/html; charset=UTF-8'));
}

/** Pedidos pagos que contêm algum dos produtos, nos últimos N dias (0 = todos). */
function zoe_envio_pedidos($produtos, $dias)
{
    global $wpdb;
    $produtos = array_values(array_filter(array_map('absint', (array) $produtos)));
    if (!$produtos) {
        return array();
    }
    $in  = implode(',', $produtos);
    $ids = $wpdb->get_col(
        "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_items oi
         JOIN {$wpdb->prefix}woocommerce_order_itemmeta im ON im.order_item_id = oi.order_item_id
         WHERE oi.order_item_type = 'line_item' AND im.meta_key = '_product_id' AND im.meta_value IN ($in)" // phpcs:ignore
    );
    $limite = $dias > 0 ? time() - $dias * DAY_IN_SECONDS : 0;
    $out = array();
    foreach ($ids as $id) {
        $o = wc_get_order((int) $id);
        if (!$o || !is_a($o, 'WC_Order') || !in_array($o->get_status(), array('processing', 'completed'), true)) {
            continue;
        }
        $d = $o->get_date_paid() ? $o->get_date_paid() : $o->get_date_created();
        if ($limite && (!$d || $d->getTimestamp() < $limite)) {
            continue;
        }
        $out[] = $o;
    }
    usort($out, function ($a, $b) {
        return $a->get_id() - $b->get_id();
    });
    return $out;
}

/** Monta a lista de destinos de um envio. */
function zoe_envio_alvos($modo, $produtos, $dias)
{
    $alvos = array();
    $vistos = array();
    foreach (zoe_envio_pedidos($produtos, $dias) as $o) {
        $email = zoe_conf_email($o);
        if (!$email) {
            continue;
        }
        if ($modo === 'aviso') {
            $k = strtolower($email);
            if (isset($vistos[$k])) {
                continue;
            }
            $vistos[$k] = true;
            $its = zoe_conf_itens($o);
            $alvos[] = array('e' => $email, 'n' => zoe_conf_primeiro_nome($o), 'ev' => $its ? $its[0]['nome'] : '', 'o' => $o->get_id());
        } else {
            $alvos[] = array('e' => $email, 'o' => $o->get_id());
        }
    }
    return $alvos;
}

function zoe_envios()
{
    $j = get_option('zoe_envios', array());
    return is_array($j) ? $j : array();
}

function zoe_envio_salvar($id, $job)
{
    $todos = zoe_envios();
    $todos[$id] = $job;
    // guarda só os 20 envios mais recentes
    if (count($todos) > 20) {
        $todos = array_slice($todos, -20, null, true);
    }
    update_option('zoe_envios', $todos, false);
}

/** Envia um destino. Retorna true/false. */
function zoe_envio_um($job, $alvo, $para = null)
{
    $para = $para ? $para : $alvo['e'];
    if ($job['modo'] === 'aviso') {
        return zoe_aviso_enviar($para, $job['assunto'], $job['mensagem'], isset($alvo['n']) ? $alvo['n'] : '', isset($alvo['ev']) ? $alvo['ev'] : '');
    }
    $o = wc_get_order($alvo['o']);
    if (!$o) {
        return false;
    }
    $GLOBALS['zoe_conf_extra']   = $job['mensagem'];
    $GLOBALS['zoe_conf_assunto'] = $job['assunto'];
    $ok = false;
    if ($para !== $alvo['e']) {
        // teste: manda a confirmação deste pedido para outro endereço, sem marcar o pedido
        $GLOBALS['zoe_conf_retro'] = true;
        $html = zoe_conf_html($o);
        $GLOBALS['zoe_conf_retro'] = false;
        $its  = zoe_conf_itens($o);
        $ass  = $job['assunto'] ? zoe_conf_tokens($job['assunto'], $o) : 'Inscrição confirmada' . ($its ? ': ' . $its[0]['nome'] : '');
        $ok   = wp_mail($para, '[TESTE] ' . $ass, $html, array('Content-Type: text/html; charset=UTF-8'));
    } else {
        $ok = zoe_conf_enviar($o, true);
    }
    $GLOBALS['zoe_conf_extra']   = '';
    $GLOBALS['zoe_conf_assunto'] = '';
    return $ok;
}

/** Processa o próximo lote de um envio e agenda o seguinte. */
function zoe_envio_lote($id)
{
    $todos = zoe_envios();
    if (empty($todos[$id]) || $todos[$id]['status'] !== 'enviando') {
        return;
    }
    $job = $todos[$id];
    if (get_transient('zoe_envio_trava_' . $id)) {
        return;
    }
    set_transient('zoe_envio_trava_' . $id, 1, 120);
    $fim = min(count($job['alvos']), $job['pos'] + ZOE_ENVIO_LOTE);
    for ($i = $job['pos']; $i < $fim; $i++) {
        if (zoe_envio_um($job, $job['alvos'][$i])) {
            $job['ok']++;
        } else {
            $job['falhas'][] = $job['alvos'][$i]['e'];
        }
        $job['pos'] = $i + 1;
    }
    $job['ultimo'] = time();
    if ($job['pos'] >= count($job['alvos'])) {
        $job['status'] = 'concluido';
        $job['fim'] = time();
    } else {
        wp_schedule_single_event(time() + 60, 'zoe_envio_lote', array($id));
    }
    zoe_envio_salvar($id, $job);
    delete_transient('zoe_envio_trava_' . $id);
}
add_action('zoe_envio_lote', 'zoe_envio_lote');

/** Se o agendador do WordPress atrasar, a próxima consulta de status empurra o envio. */
function zoe_envio_destravar()
{
    foreach (zoe_envios() as $id => $j) {
        if ($j['status'] === 'enviando' && time() - (int) $j['ultimo'] > 150) {
            zoe_envio_lote($id);
        }
    }
}

function zoe_envio_resumo($id, $j)
{
    $total = count($j['alvos']);
    $falta = $total - $j['pos'];
    return array(
        'id' => $id,
        'status' => $j['status'],
        'modo' => $j['modo'],
        'assunto' => $j['assunto'],
        'criado' => date_i18n('d/m/Y H:i', $j['criado']),
        'por' => $j['por'],
        'total' => $total,
        'enviados' => $j['ok'],
        'falhas' => count($j['falhas']),
        'enderecos_com_falha' => array_slice($j['falhas'], 0, 20),
        'faltam' => $falta,
        'previsao_fim' => $j['status'] === 'enviando' ? 'cerca de ' . max(1, (int) ceil($falta / ZOE_ENVIO_LOTE)) . ' min' : '',
    );
}
