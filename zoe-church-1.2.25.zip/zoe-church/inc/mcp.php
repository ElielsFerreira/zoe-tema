<?php

/**
 * Conector IA (servidor MCP) — permite que assistentes de IA (Claude, ChatGPT)
 * administrem o site por conversa, mediante um link secreto revogável por pessoa.
 *
 * O que o conector PODE fazer: eventos, inscrições, pendências e baixas,
 * lembretes, confirmações, relatórios, textos do site, células, páginas e imagens.
 *
 * O que o conector NUNCA faz (por construção — as ferramentas não existem):
 *  - configurações de pagamento, Mercado Pago, chaves e credenciais;
 *  - estornos e cancelamentos de cobranças;
 *  - alterar os dados de contribuição exibidos no site (Pix, CNPJ, razão social);
 *  - criar/alterar usuários do WordPress ou instalar plugins.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ZOE_MCP_VERSAO', '2025-03-26');

/* ---------------- Conexões (tokens) ---------------- */

function zoe_mcp_conexoes()
{
    $c = get_option('zoe_mcp_conexoes', array());
    return is_array($c) ? $c : array();
}

function zoe_mcp_url($token)
{
    return rest_url('zoe-mcp/v1/conector/' . $token);
}

function zoe_mcp_validar($token)
{
    foreach (zoe_mcp_conexoes() as $id => $c) {
        if (!empty($c['ativo']) && isset($c['token']) && hash_equals($c['token'], (string) $token)) {
            return array_merge($c, array('id' => $id));
        }
    }
    return null;
}

/* Executa como o primeiro administrador do site, para os registros de autoria. */
function zoe_mcp_assumir_admin()
{
    $u = get_users(array('role' => 'administrator', 'orderby' => 'ID', 'order' => 'ASC', 'number' => 1));
    if ($u) {
        wp_set_current_user($u[0]->ID);
    }
}

/* Reusa as rotas internas já existentes do painel (mesma lógica, mesmas validações). */
function zoe_mcp_interno($metodo, $rota, $json = null)
{
    $req = new WP_REST_Request($metodo, '/zoe/v1/' . ltrim($rota, '/'));
    if ($json !== null) {
        $req->set_header('Content-Type', 'application/json');
        $req->set_body(wp_json_encode($json));
    }
    $res = rest_do_request($req);
    if ($res->is_error()) {
        $e = $res->as_error();
        return new WP_Error($e->get_error_code(), $e->get_error_message());
    }
    return $res->get_data();
}

/* ---------------- O que fica fora do alcance: Mercado Pago e pagamentos ---------------- */

function zoe_mcp_gateways()
{
    $ids = array();
    if (function_exists('WC') && WC()->payment_gateways()) {
        $ids = array_keys((array) WC()->payment_gateways()->payment_gateways());
    }
    return $ids;
}

function zoe_mcp_opcao_bloqueada($nome)
{
    $n = strtolower((string) $nome);
    if (preg_match('/mercado.?pago|woo-mercado|^_mp_|^mp_|_mp_|checkout_credential|_site_id_v1|_collector_id|payment|gateway|pagamento|^active_plugins$|^woocommerce_pix/', $n)) {
        return true;
    }
    foreach (zoe_mcp_gateways() as $g) {
        if ($n === 'woocommerce_' . strtolower($g) . '_settings') {
            return true;
        }
    }
    return false;
}

/** Retorna o motivo do bloqueio, ou '' se a chamada pode seguir. */
function zoe_mcp_rota_bloqueada($metodo, $rota, $dados)
{
    $r = strtolower($rota);
    $msg = 'Bloqueado: o conector não mexe em Mercado Pago, formas de pagamento nem estornos.';
    if (preg_match('~mercado|payment_gateway|payment-gateway|/refunds|^/batch~', $r)) {
        return $msg;
    }
    if (preg_match('~^/wc/v\d/settings/(checkout|' . implode('|', array_map('preg_quote', zoe_mcp_gateways())) . ')~', $r)) {
        return $msg;
    }
    // plugins: pode listar; não pode desativar/apagar/alterar o do Mercado Pago
    if (strpos($r, '/wp/v2/plugins') === 0 && $metodo !== 'GET' && preg_match('~mercado|woo-mercado~', $r . ' ' . wp_json_encode($dados))) {
        return $msg;
    }
    // opções gravadas pela rota de configurações do WordPress
    if (strpos($r, '/wp/v2/settings') === 0 && $metodo !== 'GET') {
        foreach (array_keys($dados) as $k) {
            if (zoe_mcp_opcao_bloqueada($k)) {
                return $msg;
            }
        }
    }
    return '';
}

/* ---------------- Ferramentas ---------------- */

function zoe_mcp_ferramentas()
{
    $obj = function ($props, $req = array()) {
        return array('type' => 'object', 'properties' => (object) $props, 'required' => $req);
    };
    $s = function ($d) {
        return array('type' => 'string', 'description' => $d);
    };
    $n = function ($d) {
        return array('type' => 'integer', 'description' => $d);
    };
    return array(
        'resumo_site' => array(
            'desc' => 'Visão geral do site: eventos com inscrição aberta, estatísticas e o que este conector pode fazer. Comece por aqui.',
            'schema' => $obj(array()),
        ),
        'listar_eventos' => array(
            'desc' => 'Lista todos os eventos (cursos, conferências, ministérios) com id, nome, preço, datas, vagas, inscritos e status.',
            'schema' => $obj(array()),
        ),
        'ver_evento' => array(
            'desc' => 'Detalhes completos de um evento: descrição, nota pós-compra, formulário de inscrição, imagem e situação.',
            'schema' => $obj(array('id' => $n('ID do evento')), array('id')),
        ),
        'salvar_evento' => array(
            'desc' => 'Cria um evento novo (sem id) ou edita um existente (com id). Só os campos enviados são alterados. Preço em reais (ex.: "60" ou "59,90"); datas AAAA-MM-DD; status publish ou draft; vagas vazio = ilimitado.',
            'schema' => $obj(array(
                'id' => $n('ID do evento (omita para criar um novo)'),
                'nome' => $s('Nome do evento'),
                'preco' => $s('Preço em reais; "0" = gratuito'),
                'vagas' => $s('Número de vagas; vazio = ilimitado'),
                'resumo' => $s('Resumo curto (aparece no cartão do evento)'),
                'descricao' => $s('Descrição completa'),
                'nota' => $s('Nota pós-compra (aparece no e-mail; links de grupo do WhatsApp viram botão)'),
                'data' => $s('Data de início (AAAA-MM-DD)'),
                'fim' => $s('Data de término (AAAA-MM-DD)'),
                'prazo' => $s('Prazo final de inscrição (AAAA-MM-DD)'),
                'local' => $s('Local do evento'),
                'status' => $s('publish (no ar) ou draft (rascunho)'),
            )),
        ),
        'listar_inscricoes' => array(
            'desc' => 'Todas as inscrições de um evento, consolidadas (nome, rede/célula, líder, contato, status do pedido). Para filtrar por período, use relatorio.',
            'schema' => $obj(array('evento_id' => $n('ID do evento')), array('evento_id')),
        ),
        'pendencias' => array(
            'desc' => 'Pedidos aguardando pagamento ou cancelados sem pagamento nos últimos 30 dias, com contato para cobrança.',
            'schema' => $obj(array()),
        ),
        'dar_baixa' => array(
            'desc' => 'Marca um pedido como pago (pagamento recebido fora do site: dinheiro ou Pix direto). Use só com comprovante conferido.',
            'schema' => $obj(array('pedido_id' => $n('Número do pedido')), array('pedido_id')),
        ),
        'enviar_lembrete' => array(
            'desc' => 'Envia por e-mail o lembrete de pagamento de um pedido pendente, com o link para pagar.',
            'schema' => $obj(array('pedido_id' => $n('Número do pedido')), array('pedido_id')),
        ),
        'enviar_confirmacao' => array(
            'desc' => 'Reenvia o e-mail de confirmação de inscrição de pedidos pagos (até 10 por vez).',
            'schema' => $obj(array('pedido_ids' => array('type' => 'array', 'items' => array('type' => 'integer'), 'description' => 'Números dos pedidos')), array('pedido_ids')),
        ),
        'relatorio' => array(
            'desc' => 'Relatório consolidado de inscrições (dados brutos — monte o formato que a pessoa pedir). produtos: IDs de eventos (vazio = todos); escopo: hoje, d7, d30, d60, d90, todos; colunas: só as colunas pedidas (ex.: ["Nome completo","Rede / célula","Líder","WhatsApp","E-mail","Valor","Status"]); limite: linhas por evento (padrão 300, máx 1000). Não pagos estão em pendencias.',
            'schema' => $obj(array(
                'produtos' => array('type' => 'array', 'items' => array('type' => 'integer'), 'description' => 'IDs dos eventos (vazio = todos)'),
                'escopo' => $s('Período (padrão d90)'),
                'colunas' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Colunas a incluir (vazio = todas)'),
                'limite' => $n('Máximo de linhas por evento (padrão 300, máx 1000)'),
            )),
        ),
        'ver_textos_site' => array(
            'desc' => 'Todos os textos editáveis da página inicial: título, visão, pastores, ano, células, cultos, ministérios, contato e redes sociais.',
            'schema' => $obj(array()),
        ),
        'editar_textos_site' => array(
            'desc' => 'Edita textos da página inicial. Envie em dados só as chaves a alterar (veja as chaves em ver_textos_site). Asteriscos marcam a palavra destacada: "O ano do *fluir*".',
            'schema' => $obj(array('dados' => array('type' => 'object', 'description' => 'Pares chave: valor a alterar')), array('dados')),
        ),
        'editar_celulas' => array(
            'desc' => 'Define a lista de células que aparecem na pergunta "Qual a sua célula?" das inscrições. lista substitui a lista inteira; off esconde sem apagar.',
            'schema' => $obj(array(
                'lista' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Todas as células, na ordem'),
                'off' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Células escondidas da inscrição'),
            ), array('lista')),
        ),
        'listar_paginas' => array(
            'desc' => 'Lista as páginas e posts do site (id, título, tipo, status, link).',
            'schema' => $obj(array()),
        ),
        'ler_pagina' => array(
            'desc' => 'Conteúdo completo de uma página ou post.',
            'schema' => $obj(array('id' => $n('ID da página ou post')), array('id')),
        ),
        'salvar_pagina' => array(
            'desc' => 'Cria (sem id) ou edita (com id) uma página ou post. Conteúdo em HTML simples. status: publish ou draft.',
            'schema' => $obj(array(
                'id' => $n('ID (omita para criar)'),
                'titulo' => $s('Título'),
                'conteudo' => $s('Conteúdo em HTML'),
                'status' => $s('publish ou draft'),
                'tipo' => $s('page ou post (só ao criar; padrão page)'),
            )),
        ),
        'listar_imagens' => array(
            'desc' => 'Busca imagens já enviadas à biblioteca do site (id, título, url). Use busca para filtrar pelo nome.',
            'schema' => $obj(array('busca' => $s('Termo de busca (opcional)'))),
        ),
        'definir_imagem_evento' => array(
            'desc' => 'Define a imagem de capa de um evento usando uma imagem da biblioteca (veja listar_imagens).',
            'schema' => $obj(array('evento_id' => $n('ID do evento'), 'imagem_id' => $n('ID da imagem')), array('evento_id', 'imagem_id')),
        ),
        'editar_email_confirmacao' => array(
            'desc' => 'Personaliza o e-mail de confirmação de inscrição de um evento: assunto e mensagem próprios (substituem o texto padrão "Recebemos seu pagamento..."). Aceita {nome} (primeiro nome) e {evento}. Links de grupo do WhatsApp viram botão. Envie texto vazio para voltar ao padrão. Os detalhes do pedido, data, local e a nota pós-compra continuam no e-mail. imagem coloca uma capa (arte do evento) no topo do e-mail.',
            'schema' => $obj(array('evento_id' => $n('ID do evento'), 'assunto' => $s('Assunto do e-mail'), 'mensagem' => $s('Mensagem principal'), 'imagem' => $s('Capa no topo do e-mail: ID de imagem da biblioteca ou URL de uma imagem (é importada para a biblioteca). Vazio remove.')), array('evento_id')),
        ),
        'enviar_email_inscritos' => array(
            'desc' => 'Envia e-mail para quem comprou um ou mais eventos (só pedidos pagos). modo "confirmacao": cada pedido recebe de novo sua confirmação completa, com assunto e mensagem extra opcionais no topo. modo "aviso": e-mail livre com o visual da Zoe (assunto + mensagem), um por endereço. Aceita {nome} e {evento}. dias limita o período das compras (padrão 90; a mesma página de evento pode ter compras de edições passadas). Fluxo seguro: 1) chame sem confirmar para ver quantos vão receber; 2) use email_teste para mandar uma amostra; 3) chame com confirmar=true. O envio segue em segundo plano, 8 por minuto (limite da hospedagem). Acompanhe com envios_status.',
            'schema' => $obj(array(
                'eventos' => array('type' => 'array', 'items' => array('type' => 'integer'), 'description' => 'IDs dos eventos'),
                'modo' => $s('confirmacao ou aviso'),
                'assunto' => $s('Assunto (obrigatório no modo aviso)'),
                'mensagem' => $s('Mensagem (obrigatória no modo aviso; no modo confirmacao vai em destaque no topo)'),
                'capa' => $s('Imagem de capa no topo do e-mail: ID da biblioteca ou URL (opcional; sem ela, usa a capa do evento)'),
                'dias' => $n('Compras dos últimos N dias (padrão 90; 0 = desde o começo)'),
                'email_teste' => $s('Manda só uma amostra para este endereço'),
                'confirmar' => array('type' => 'boolean', 'description' => 'true para enviar de verdade'),
            ), array('eventos', 'modo')),
        ),
        'envios_status' => array(
            'desc' => 'Andamento dos envios de e-mail em massa (enviados, faltam, falhas). Sem id, lista os envios recentes.',
            'schema' => $obj(array('id' => $s('ID do envio (opcional)'))),
        ),
        'cancelar_envio' => array(
            'desc' => 'Interrompe um envio de e-mail em massa que ainda está em andamento.',
            'schema' => $obj(array('id' => $s('ID do envio')), array('id')),
        ),
        'wordpress_api' => array(
            'desc' => 'Acesso geral ao site pela API do WordPress e do WooCommerce, como administrador: páginas, posts, mídia, menus, produtos, variações, pedidos e notas de pedido, clientes, cupons, categorias, usuários, configurações da loja, plugins etc. Ex.: GET /wp/v2/pages, POST /wc/v3/products/123 {"regular_price":"70"}, GET /wc/v3/orders {"search":"Maria"}, POST /wc/v3/orders/7700/notes {"note":"..."}. Use para tudo que as outras ferramentas não cobrem. Bloqueado: Mercado Pago, formas de pagamento e estornos.',
            'schema' => $obj(array(
                'metodo' => $s('GET, POST, PUT, PATCH ou DELETE'),
                'rota' => $s('Rota da API, ex.: /wc/v3/orders ou /wp/v2/pages/12'),
                'dados' => array('type' => 'object', 'description' => 'Parâmetros (GET) ou corpo (POST/PUT/PATCH)'),
            ), array('metodo', 'rota')),
        ),
        'opcoes_wordpress' => array(
            'desc' => 'Lê ou altera configurações gerais do WordPress e dos plugins (opções). acao "ler" (nome), "buscar" (parte do nome, lista até 50) ou "gravar" (nome + valor). Bloqueado: Mercado Pago e formas de pagamento.',
            'schema' => $obj(array(
                'acao' => $s('ler, buscar ou gravar'),
                'nome' => $s('Nome (ou parte do nome, em buscar)'),
                'valor' => array('description' => 'Novo valor (texto, número, lista ou objeto)'),
            ), array('acao', 'nome')),
        ),
        'enviar_imagem' => array(
            'desc' => 'Sobe uma imagem para a biblioteca do site e devolve o ID e a URL, para usar em capa de evento, capa de e-mail, páginas etc. Envie url (endereço público da imagem) ou base64 (conteúdo do arquivo, com ou sem o prefixo data:image/...;base64,). JPG, PNG, WEBP ou GIF, até 8 MB.',
            'schema' => $obj(array(
                'url' => $s('Endereço público da imagem'),
                'base64' => $s('Conteúdo da imagem em base64'),
                'nome' => $s('Nome do arquivo, ex.: capa-start.jpg'),
                'titulo' => $s('Título na biblioteca (opcional)'),
            )),
        ),
        'css_personalizado' => array(
            'desc' => 'Ajustes visuais do site sem mexer no código do tema: lê ou grava o CSS adicional do WordPress (vale para todas as páginas). acao "ler", "adicionar" (acrescenta ao fim) ou "gravar" (substitui tudo). Classes úteis do tema: .hero, .titulo, .eyebrow, .btn, .ev-card, .rodape.',
            'schema' => $obj(array('acao' => $s('ler, adicionar ou gravar'), 'css' => $s('Código CSS')), array('acao')),
        ),
        'atualizar_tema' => array(
            'desc' => 'Verifica agora se há versão nova do tema no servidor de atualizações e instala na hora, sem esperar a checagem automática.',
            'schema' => $obj(array()),
        ),
    );
}

function zoe_mcp_executar($nome, $arg, $conexao)
{
    $arg = is_array($arg) ? $arg : array();
    switch ($nome) {
        case 'resumo_site':
            $evs = array_values(array_filter(zoe_p_eventos(), function ($e) {
                return $e['status'] === 'publish';
            }));
            return array(
                'site' => home_url('/'),
                'stats' => zoe_p_stats(),
                'eventos_no_ar' => array_map(function ($e) {
                    return array('id' => $e['id'], 'nome' => $e['nome'], 'aberto' => $e['aberto'], 'inscritos' => $e['inscritos'], 'preco' => $e['precoTxt'], 'data' => $e['data']);
                }, $evs),
                'escopo' => 'Este conector administra eventos, inscrições, baixas, lembretes, relatórios, textos do site, células, páginas e imagens. Não acessa configurações de pagamento nem Mercado Pago.',
            );

        case 'listar_eventos':
            return array_map(function ($e) {
                return array(
                    'id' => $e['id'], 'nome' => $e['nome'], 'status' => $e['status'], 'aberto' => $e['aberto'],
                    'preco' => $e['precoTxt'], 'vagas' => $e['vagas'], 'inscritos' => $e['inscritos'],
                    'data' => $e['data'], 'fim' => $e['fim'], 'prazo' => $e['prazo'], 'local' => $e['local'], 'link' => $e['link'],
                );
            }, zoe_p_eventos());

        case 'ver_evento':
            $p = wc_get_product(absint(isset($arg['id']) ? $arg['id'] : 0));
            if (!$p) {
                return new WP_Error('nao', 'Evento não encontrado');
            }
            return zoe_p_evento($p);

        case 'salvar_evento':
            $json = array_intersect_key($arg, array_flip(array('id', 'nome', 'preco', 'vagas', 'resumo', 'descricao', 'nota', 'data', 'fim', 'prazo', 'local', 'status')));
            if (empty($json['id'])) {
                unset($json['id']);
                if (!isset($json['nome'])) {
                    return new WP_Error('nome', 'Para criar um evento, informe o nome');
                }
            } elseif (!isset($json['nome'])) {
                $p = wc_get_product(absint($json['id']));
                if (!$p) {
                    return new WP_Error('nao', 'Evento não encontrado');
                }
                $json['nome'] = $p->get_name();
            }
            return zoe_mcp_interno('POST', 'evento', $json);

        case 'listar_inscricoes':
            return zoe_mcp_interno('GET', 'inscricoes/' . absint(isset($arg['evento_id']) ? $arg['evento_id'] : 0));

        case 'pendencias':
            return zoe_mcp_interno('GET', 'pendentes');

        case 'dar_baixa':
            return zoe_mcp_interno('POST', 'pendentes/' . absint(isset($arg['pedido_id']) ? $arg['pedido_id'] : 0) . '/pago', array());

        case 'enviar_lembrete':
            return zoe_mcp_interno('POST', 'pendentes/' . absint(isset($arg['pedido_id']) ? $arg['pedido_id'] : 0) . '/lembrar', array());

        case 'enviar_confirmacao':
            return zoe_mcp_interno('POST', 'confirmacao/enviar', array('ids' => array_map('absint', (array) (isset($arg['pedido_ids']) ? $arg['pedido_ids'] : array()))));

        case 'relatorio':
            $prods = implode(',', array_map('absint', (array) (isset($arg['produtos']) ? $arg['produtos'] : array())));
            $esc = isset($arg['escopo']) && preg_match('/^(todos|abertos|hoje|d\d{1,3})$/', $arg['escopo']) ? $arg['escopo'] : 'd90';
            $d = zoe_rel_dados($esc, $prods);
            $lim = min(1000, max(1, absint(isset($arg['limite']) ? $arg['limite'] : 300)));
            $cols = array_values(array_filter(array_map('strval', (array) (isset($arg['colunas']) ? $arg['colunas'] : array()))));
            $out = array('escopo' => $esc, 'eventos' => array());
            foreach ($d['eventos'] as $pid => $ev) {
                $linhas = array_slice(array_reverse($ev['linhas']), 0, $lim);
                if ($cols) {
                    $chaves = array_flip($cols);
                    $linhas = array_map(function ($l) use ($chaves) {
                        return array_intersect_key($l, $chaves);
                    }, $linhas);
                }
                $out['eventos'][] = array(
                    'id' => $pid, 'nome' => $ev['nome'], 'pagos' => $ev['pagos'], 'aguardando' => $ev['aguard'],
                    'inscricoes' => $linhas,
                    'aviso' => count($ev['linhas']) > $lim ? 'Mostrando as ' . $lim . ' mais recentes de ' . count($ev['linhas']) : '',
                );
            }
            return $out;

        case 'ver_textos_site':
            $o = zoe_p_site();
            unset($o['_img']);
            return $o;

        case 'editar_textos_site':
            $dados = (array) (isset($arg['dados']) ? $arg['dados'] : array());
            $r = zoe_mcp_interno('POST', 'site', array('dados' => $dados));
            return is_wp_error($r) ? $r : array('ok' => true, 'alteradas' => array_keys($dados));

        case 'editar_celulas':
            return zoe_mcp_interno('POST', 'celulas', array(
                'lista' => (array) (isset($arg['lista']) ? $arg['lista'] : array()),
                'off' => (array) (isset($arg['off']) ? $arg['off'] : array()),
            ));

        case 'listar_paginas':
            $posts = get_posts(array('post_type' => array('page', 'post'), 'post_status' => array('publish', 'draft', 'private'), 'numberposts' => 200, 'orderby' => 'modified', 'order' => 'DESC'));
            return array_map(function ($p) {
                return array('id' => $p->ID, 'titulo' => $p->post_title, 'tipo' => $p->post_type, 'status' => $p->post_status, 'link' => get_permalink($p), 'modificado' => $p->post_modified);
            }, $posts);

        case 'ler_pagina':
            $p = get_post(absint(isset($arg['id']) ? $arg['id'] : 0));
            if (!$p || !in_array($p->post_type, array('page', 'post'), true)) {
                return new WP_Error('nao', 'Página não encontrada');
            }
            return array('id' => $p->ID, 'titulo' => $p->post_title, 'tipo' => $p->post_type, 'status' => $p->post_status, 'conteudo' => $p->post_content, 'link' => get_permalink($p));

        case 'salvar_pagina':
            $id = absint(isset($arg['id']) ? $arg['id'] : 0);
            $dados = array();
            if ($id) {
                $p = get_post($id);
                if (!$p || !in_array($p->post_type, array('page', 'post'), true)) {
                    return new WP_Error('nao', 'Página não encontrada (só páginas e posts podem ser editados por aqui)');
                }
                $dados['ID'] = $id;
            } else {
                if (trim((string) (isset($arg['titulo']) ? $arg['titulo'] : '')) === '') {
                    return new WP_Error('titulo', 'Para criar, informe o título');
                }
                $dados['post_type'] = isset($arg['tipo']) && $arg['tipo'] === 'post' ? 'post' : 'page';
                $dados['post_status'] = 'draft';
            }
            if (isset($arg['titulo'])) {
                $dados['post_title'] = sanitize_text_field($arg['titulo']);
            }
            if (isset($arg['conteudo'])) {
                $dados['post_content'] = wp_kses_post($arg['conteudo']);
            }
            if (isset($arg['status']) && in_array($arg['status'], array('publish', 'draft'), true)) {
                $dados['post_status'] = $arg['status'];
            }
            $nid = $id ? wp_update_post($dados, true) : wp_insert_post($dados, true);
            if (is_wp_error($nid)) {
                return $nid;
            }
            do_action('litespeed_purge_all');
            $p = get_post($nid);
            return array('id' => $p->ID, 'titulo' => $p->post_title, 'status' => $p->post_status, 'link' => get_permalink($p));

        case 'listar_imagens':
            $q = array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'numberposts' => 30, 'orderby' => 'date', 'order' => 'DESC');
            if (!empty($arg['busca'])) {
                $q['s'] = sanitize_text_field($arg['busca']);
            }
            return array_map(function ($p) {
                return array('id' => $p->ID, 'titulo' => $p->post_title, 'url' => wp_get_attachment_image_url($p->ID, 'large'));
            }, get_posts($q));

        case 'definir_imagem_evento':
            return zoe_mcp_interno('POST', 'evento/' . absint(isset($arg['evento_id']) ? $arg['evento_id'] : 0) . '/flag', array('imgId' => absint(isset($arg['imagem_id']) ? $arg['imagem_id'] : 0)));

        case 'editar_email_confirmacao':
            $pid = absint(isset($arg['evento_id']) ? $arg['evento_id'] : 0);
            if (!$pid || get_post_type($pid) !== 'product') {
                return new WP_Error('nao', 'Evento não encontrado');
            }
            foreach (array('assunto' => '_zoe_email_assunto', 'mensagem' => '_zoe_email_msg') as $k => $mk) {
                if (array_key_exists($k, $arg)) {
                    $v = $k === 'assunto' ? sanitize_text_field((string) $arg[$k]) : sanitize_textarea_field((string) $arg[$k]);
                    $v === '' ? delete_post_meta($pid, $mk) : update_post_meta($pid, $mk, $v);
                }
            }
            if (array_key_exists('imagem', $arg)) {
                $r = zoe_conf_definir_capa($pid, $arg['imagem']);
                if (is_wp_error($r)) {
                    return $r;
                }
            }
            return array('ok' => true, 'evento' => get_the_title($pid), 'assunto' => (string) get_post_meta($pid, '_zoe_email_assunto', true), 'mensagem' => (string) get_post_meta($pid, '_zoe_email_msg', true), 'imagem' => zoe_conf_capa($pid), 'obs' => 'Vale para as próximas confirmações. Para mandar a quem já comprou, use enviar_email_inscritos.');

        case 'enviar_email_inscritos':
            $modo = isset($arg['modo']) && $arg['modo'] === 'aviso' ? 'aviso' : 'confirmacao';
            $assunto = sanitize_text_field((string) (isset($arg['assunto']) ? $arg['assunto'] : ''));
            $mensagem = sanitize_textarea_field((string) (isset($arg['mensagem']) ? $arg['mensagem'] : ''));
            if ($modo === 'aviso' && ($assunto === '' || $mensagem === '')) {
                return new WP_Error('falta', 'No modo aviso, informe assunto e mensagem.');
            }
            $evs = array_values(array_filter(array_map('absint', (array) (isset($arg['eventos']) ? $arg['eventos'] : array()))));
            $dias = isset($arg['dias']) ? absint($arg['dias']) : 90;
            $alvos = zoe_envio_alvos($modo, $evs, $dias);
            if (!$alvos) {
                return new WP_Error('vazio', 'Nenhum comprador com e-mail encontrado para esses eventos nesse período.');
            }
            $job = array('modo' => $modo, 'assunto' => $assunto, 'mensagem' => $mensagem, 'alvos' => $alvos, 'pos' => 0, 'ok' => 0, 'falhas' => array(), 'status' => 'enviando', 'criado' => time(), 'ultimo' => time(), 'por' => $conexao['nome'], 'eventos' => $evs, 'dias' => $dias, 'capa' => sanitize_text_field((string) (isset($arg['capa']) ? $arg['capa'] : '')));
            if (!empty($arg['email_teste'])) {
                $t = sanitize_email((string) $arg['email_teste']);
                if (!is_email($t)) {
                    return new WP_Error('email', 'E-mail de teste inválido');
                }
                $ok = zoe_envio_um($job, $alvos[0], $t);
                return array('teste' => $ok ? 'Amostra enviada para ' . $t : 'Falhou ao enviar a amostra', 'baseado_em' => $modo === 'aviso' ? 'dados de ' . $alvos[0]['n'] : 'pedido ' . $alvos[0]['o'], 'total_que_receberia' => count($alvos));
            }
            if (empty($arg['confirmar'])) {
                $amostra = array();
                foreach (array_slice($alvos, 0, 5) as $a) {
                    $o = wc_get_order($a['o']);
                    $amostra[] = ($o ? zoe_conf_nome_completo($o) : '') . ' <' . $a['e'] . '>';
                }
                return array(
                    'previa' => true,
                    'vao_receber' => count($alvos),
                    'modo' => $modo,
                    'periodo' => $dias ? 'compras dos últimos ' . $dias . ' dias' : 'todas as compras',
                    'amostra' => $amostra,
                    'tempo_estimado' => 'cerca de ' . max(1, (int) ceil(count($alvos) / ZOE_ENVIO_LOTE)) . ' min',
                    'proximo_passo' => 'Mostre isto à pessoa, ofereça uma amostra com email_teste e, com o ok dela, chame de novo com confirmar=true.',
                );
            }
            $id = 'e' . time();
            zoe_envio_salvar($id, $job);
            zoe_envio_lote($id); // primeiro lote já sai agora
            $tudo = zoe_envios();
            return zoe_envio_resumo($id, $tudo[$id]);

        case 'envios_status':
            zoe_envio_destravar();
            $tudo = zoe_envios();
            if (!empty($arg['id'])) {
                return isset($tudo[$arg['id']]) ? zoe_envio_resumo($arg['id'], $tudo[$arg['id']]) : new WP_Error('nao', 'Envio não encontrado');
            }
            $out = array();
            foreach (array_reverse($tudo, true) as $id => $j) {
                $out[] = zoe_envio_resumo($id, $j);
            }
            return $out ? $out : array('msg' => 'Nenhum envio em massa ainda.');

        case 'cancelar_envio':
            $tudo = zoe_envios();
            $id = (string) (isset($arg['id']) ? $arg['id'] : '');
            if (!isset($tudo[$id])) {
                return new WP_Error('nao', 'Envio não encontrado');
            }
            if ($tudo[$id]['status'] === 'enviando') {
                $tudo[$id]['status'] = 'cancelado';
                zoe_envio_salvar($id, $tudo[$id]);
                wp_clear_scheduled_hook('zoe_envio_lote', array($id));
            }
            return zoe_envio_resumo($id, $tudo[$id]);

        case 'wordpress_api':
            $metodo = strtoupper((string) (isset($arg['metodo']) ? $arg['metodo'] : 'GET'));
            $rota = '/' . ltrim((string) (isset($arg['rota']) ? $arg['rota'] : ''), '/');
            $dados = isset($arg['dados']) && is_array($arg['dados']) ? $arg['dados'] : array();
            if (!in_array($metodo, array('GET', 'POST', 'PUT', 'PATCH', 'DELETE'), true)) {
                return new WP_Error('metodo', 'Método inválido');
            }
            if (strpos($rota, '?') !== false) {
                list($rota, $qs) = explode('?', $rota, 2);
                parse_str($qs, $q2);
                $dados = array_merge($q2, $dados);
            }
            $bloq = zoe_mcp_rota_bloqueada($metodo, $rota, $dados);
            if ($bloq) {
                return new WP_Error('bloqueado', $bloq);
            }
            $req = new WP_REST_Request($metodo, $rota);
            if ($metodo === 'GET' || $metodo === 'DELETE') {
                $req->set_query_params($dados);
            } else {
                $req->set_header('Content-Type', 'application/json');
                $req->set_body(wp_json_encode($dados));
            }
            $res = rest_do_request($req);
            $dadosRes = rest_get_server()->response_to_data($res, false);
            $saida = array('status' => $res->get_status(), 'dados' => $dadosRes);
            $h = $res->get_headers();
            if (isset($h['X-WP-Total'])) {
                $saida['total'] = (int) $h['X-WP-Total'];
                $saida['paginas'] = isset($h['X-WP-TotalPages']) ? (int) $h['X-WP-TotalPages'] : 1;
            }
            $json = wp_json_encode($saida, JSON_UNESCAPED_UNICODE);
            if (strlen($json) > 80000) {
                return array('status' => $res->get_status(), 'aviso' => 'Resposta grande demais (' . round(strlen($json) / 1024) . ' KB). Peça menos itens (per_page) ou só os campos necessários (_fields).', 'inicio' => mb_substr($json, 0, 60000));
            }
            return $saida;

        case 'opcoes_wordpress':
            $acao = (string) (isset($arg['acao']) ? $arg['acao'] : 'ler');
            $nome = trim((string) (isset($arg['nome']) ? $arg['nome'] : ''));
            if ($nome === '') {
                return new WP_Error('nome', 'Informe o nome da opção');
            }
            if ($acao === 'buscar') {
                global $wpdb;
                $nomes = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name NOT LIKE %s ORDER BY option_name LIMIT 80", '%' . $wpdb->esc_like($nome) . '%', '\_transient%'));
                return array_values(array_filter($nomes, function ($n) {
                    return !zoe_mcp_opcao_bloqueada($n);
                }));
            }
            if (zoe_mcp_opcao_bloqueada($nome)) {
                return new WP_Error('bloqueado', 'Esta opção é de pagamento/Mercado Pago e não pode ser lida nem alterada pelo conector.');
            }
            if ($acao === 'gravar') {
                if (!array_key_exists('valor', $arg)) {
                    return new WP_Error('valor', 'Informe o valor');
                }
                update_option($nome, $arg['valor']);
                do_action('litespeed_purge_all');
                return array('ok' => true, 'nome' => $nome, 'valor' => get_option($nome));
            }
            return array('nome' => $nome, 'valor' => get_option($nome, null));

        case 'enviar_imagem':
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $nome = sanitize_file_name((string) (isset($arg['nome']) ? $arg['nome'] : ''));
            if (!empty($arg['base64'])) {
                $b = preg_replace('~^data:image/[a-z+]+;base64,~i', '', (string) $arg['base64']);
                $bin = base64_decode(preg_replace('/\s+/', '', $b), true);
                if ($bin === false || strlen($bin) < 100) {
                    return new WP_Error('img', 'Base64 inválido');
                }
                if (strlen($bin) > 8 * 1024 * 1024) {
                    return new WP_Error('img', 'Imagem maior que 8 MB');
                }
                $tmp = wp_tempnam($nome ? $nome : 'imagem');
                file_put_contents($tmp, $bin);
            } elseif (!empty($arg['url'])) {
                $tmp = download_url(esc_url_raw((string) $arg['url']), 30);
                if (is_wp_error($tmp)) {
                    return $tmp;
                }
                if (!$nome) {
                    $nome = sanitize_file_name(basename(wp_parse_url((string) $arg['url'], PHP_URL_PATH)));
                }
            } else {
                return new WP_Error('img', 'Envie url ou base64');
            }
            $tipo = wp_get_image_mime($tmp);
            $ext = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif');
            if (!isset($ext[$tipo])) {
                @unlink($tmp);
                return new WP_Error('img', 'O arquivo não é uma imagem JPG, PNG, WEBP ou GIF');
            }
            $nome = preg_replace('/\.[a-z0-9]+$/i', '', $nome ? $nome : 'imagem-' . time()) . '.' . $ext[$tipo];
            $id = media_handle_sideload(array('name' => $nome, 'tmp_name' => $tmp), 0, isset($arg['titulo']) ? sanitize_text_field($arg['titulo']) : null);
            if (is_wp_error($id)) {
                @unlink($tmp);
                return $id;
            }
            $m = wp_get_attachment_metadata($id);
            return array('id' => $id, 'url' => wp_get_attachment_url($id), 'largura' => isset($m['width']) ? $m['width'] : null, 'altura' => isset($m['height']) ? $m['height'] : null);

        case 'css_personalizado':
            $acao = (string) (isset($arg['acao']) ? $arg['acao'] : 'ler');
            $atual = wp_get_custom_css();
            if ($acao === 'ler') {
                return array('css' => $atual);
            }
            $css = (string) (isset($arg['css']) ? $arg['css'] : '');
            if (preg_match('~</?\s*(script|style)~i', $css)) {
                return new WP_Error('css', 'Envie só CSS, sem tags.');
            }
            $novo = $acao === 'gravar' ? $css : rtrim($atual) . "\n\n" . $css;
            $r = wp_update_custom_css_post($novo);
            if (is_wp_error($r)) {
                return $r;
            }
            do_action('litespeed_purge_all');
            return array('ok' => true, 'css' => wp_get_custom_css());

        case 'atualizar_tema':
            delete_site_transient('zoe_tema_info');
            $info = function_exists('zoe_atual_info') ? zoe_atual_info(true) : null;
            if (!$info) {
                return new WP_Error('offline', 'Não consegui consultar o servidor de atualizações agora. Tente de novo em instantes.');
            }
            if (version_compare($info['version'], ZOE_TEMA_V, '<=')) {
                return array('ok' => true, 'instalada' => ZOE_TEMA_V, 'disponivel' => $info['version'], 'msg' => 'O tema já está na versão mais recente.');
            }
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/misc.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
            require_once ABSPATH . 'wp-admin/includes/theme.php';
            // Grava a atualização direto na lista do WordPress (a reconsulta normal
            // tem trava de 12h e deixaria o instalador sem saber da versão nova).
            $tr = get_site_transient('update_themes');
            if (!is_object($tr)) {
                $tr = new stdClass();
            }
            if (!isset($tr->response) || !is_array($tr->response)) {
                $tr->response = array();
            }
            $tr->response['zoe-church'] = array(
                'theme'        => 'zoe-church',
                'new_version'  => $info['version'],
                'url'          => isset($info['url']) ? $info['url'] : 'https://github.com/ElielsFerreira/zoe-tema',
                'package'      => $info['package'],
                'requires'     => isset($info['requires']) ? $info['requires'] : '6.1',
                'requires_php' => isset($info['requires_php']) ? $info['requires_php'] : '7.4',
            );
            set_site_transient('update_themes', $tr);
            $up = new Theme_Upgrader(new Automatic_Upgrader_Skin());
            $r = $up->upgrade('zoe-church');
            $msgs = method_exists($up->skin, 'get_upgrade_messages') ? implode(' · ', (array) $up->skin->get_upgrade_messages() ) : '';
            if (is_wp_error($r)) {
                return new WP_Error($r->get_error_code(), $r->get_error_message() . ($msgs ? ' (' . $msgs . ')' : ''));
            }
            if (!$r) {
                return new WP_Error('falhou', 'A instalação não concluiu. ' . ($msgs ? 'Detalhes: ' . $msgs : 'Verifique em Painel WP → Atualizações.'));
            }
            do_action('litespeed_purge_all');
            return array('ok' => true, 'de' => ZOE_TEMA_V, 'para' => $info['version'], 'msg' => 'Tema atualizado para ' . $info['version'] . '.' . ($msgs ? ' Detalhes: ' . $msgs : ''));
    }
    return new WP_Error('nao_existe', 'Ferramenta desconhecida: ' . $nome);
}

/* ---------------- Protocolo MCP (JSON-RPC sobre HTTP) ---------------- */

function zoe_mcp_rpc($msg, $conexao)
{
    $id = isset($msg['id']) ? $msg['id'] : null;
    $metodo = isset($msg['method']) ? (string) $msg['method'] : '';
    $par = isset($msg['params']) && is_array($msg['params']) ? $msg['params'] : array();
    $ok = function ($result) use ($id) {
        return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $result);
    };
    $erro = function ($cod, $txt) use ($id) {
        return array('jsonrpc' => '2.0', 'id' => $id, 'error' => array('code' => $cod, 'message' => $txt));
    };

    // Notificações (sem id) não têm resposta.
    if ($id === null && strpos($metodo, 'notifications/') === 0) {
        return null;
    }

    switch ($metodo) {
        case 'initialize':
            $pv = isset($par['protocolVersion']) ? (string) $par['protocolVersion'] : '';
            return $ok(array(
                'protocolVersion' => in_array($pv, array('2024-11-05', '2025-03-26', '2025-06-18'), true) ? $pv : ZOE_MCP_VERSAO,
                'capabilities' => array('tools' => (object) array()),
                'serverInfo' => array('name' => 'Zoe Church', 'version' => ZOE_TEMA_V),
                'instructions' => 'Administração completa do site da Zoe Church (zoechurchfrg.com.br). Ferramentas prontas para eventos, inscrições, pendências e baixas, lembretes, relatórios (dados brutos, formate como a pessoa pedir), textos da página inicial, células, páginas, imagens, e-mail de confirmação personalizado e envio de e-mail em massa para inscritos. Para qualquer outra coisa, use wordpress_api (API completa do WordPress/WooCommerce) e opcoes_wordpress: quase tudo é possível. Imagens: suba com enviar_imagem (aceita o arquivo em base64), sem precisar hospedar em outro lugar. Visual do site: css_personalizado. Não é preciso (nem possível) mexer no código do tema ou no GitHub: tudo que a equipe precisa é feito por estas ferramentas; se algo realmente exigir programar uma função nova no tema, diga à pessoa que isso é com o administrador do site. A única coisa fora do alcance é Mercado Pago, formas de pagamento e estornos. Antes de ações em massa ou irreversíveis (envio de e-mails, exclusões), mostre o que vai acontecer e peça confirmação à pessoa. Conexão de: ' . $conexao['nome'] . '. Comece com resumo_site.',
            ));

        case 'ping':
            return $ok((object) array());

        case 'tools/list':
            $tools = array();
            foreach (zoe_mcp_ferramentas() as $nome => $f) {
                $tools[] = array('name' => $nome, 'description' => $f['desc'], 'inputSchema' => $f['schema']);
            }
            return $ok(array('tools' => $tools));

        case 'tools/call':
            $nome = isset($par['name']) ? (string) $par['name'] : '';
            if (!array_key_exists($nome, zoe_mcp_ferramentas())) {
                return $erro(-32602, 'Ferramenta desconhecida: ' . $nome);
            }
            $r = zoe_mcp_executar($nome, isset($par['arguments']) ? $par['arguments'] : array(), $conexao);
            if (is_wp_error($r)) {
                return $ok(array('content' => array(array('type' => 'text', 'text' => 'Erro: ' . $r->get_error_message())), 'isError' => true));
            }
            return $ok(array('content' => array(array('type' => 'text', 'text' => wp_json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)))));

        case 'resources/list':
            return $ok(array('resources' => array()));

        case 'prompts/list':
            return $ok(array('prompts' => array()));
    }
    return $erro(-32601, 'Método não suportado: ' . $metodo);
}

/* Página de instruções para quem abre o link como página comum (ou cola o link numa conversa). */
function zoe_mcp_pagina_ajuda($conexao)
{
    status_header($conexao ? 200 : 404);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    $titulo = $conexao ? 'Link de conector do site da Zoe Church' : 'Link de conector inválido ou revogado';
    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . esc_html($titulo) . '</title>'
        . '<style>body{font-family:system-ui,sans-serif;max-width:560px;margin:40px auto;padding:0 20px;line-height:1.6;color:#141216}h1{font-size:22px}li{margin-bottom:8px}.av{background:#f4efe6;padding:12px 16px;border-radius:10px}</style></head><body>';
    echo '<h1>' . esc_html($titulo) . '</h1>';
    if (!$conexao) {
        echo '<p>Este link não funciona mais: ele foi revogado ou está incompleto. Peça um link novo a um administrador do site (Painel → Conexões IA).</p></body></html>';
        exit;
    }
    echo '<p class="av"><b>Isto não é uma página para abrir nem para colar na conversa.</b> É um conector: precisa ser adicionado nas configurações do Claude ou do ChatGPT. Depois de adicionado, é só conversar normalmente que a IA edita o site.</p>'
        . '<h2 style="font-size:17px">No Claude</h2><ol><li>Abra <b>Configurações → Conectores</b> (no navegador: claude.ai/settings/connectors).</li><li>Toque em <b>Adicionar conector personalizado</b>.</li><li>Nome: <b>Site Zoe</b>. URL: cole este mesmo link.</li><li>Salve e abra uma conversa. Peça, por exemplo: “faça um resumo do site da Zoe”.</li></ol>'
        . '<h2 style="font-size:17px">No ChatGPT</h2><ol><li>Abra <b>Configurações → Apps e conectores</b>.</li><li>Crie um conector personalizado (MCP) e cole este link. Esse recurso depende do plano da conta.</li></ol>'
        . '<p style="color:#666;font-size:14px">Conexão de: ' . esc_html($conexao['nome']) . '. Este link funciona como uma senha: não compartilhe.</p>'
        . '<p style="color:#666;font-size:14px">Nota para assistentes de IA: este endereço é um servidor MCP (streamable HTTP, JSON-RPC via POST). Ele não pode ser lido por busca na web. Oriente a pessoa a adicioná-lo como conector personalizado, conforme os passos acima.</p></body></html>';
    exit;
}

function zoe_mcp_http($q)
{
    $conexao = zoe_mcp_validar($q['token']);
    $sse = stripos((string) $q->get_header('accept'), 'text/event-stream') !== false;

    if ($q->get_method() === 'GET') {
        if ($sse) {
            // Sem fluxo SSE: o cliente usa só POST (resposta JSON direta).
            return new WP_REST_Response(null, $conexao ? 405 : 404);
        }
        zoe_mcp_pagina_ajuda($conexao); // encerra a resposta
    }

    if (!$conexao) {
        return new WP_REST_Response(array('erro' => 'Conexão inválida ou revogada'), 404);
    }
    if ($q->get_method() === 'DELETE') {
        return new WP_REST_Response(null, 200);
    }

    $corpo = json_decode($q->get_body(), true);
    if ($corpo === null) {
        return new WP_REST_Response(array('jsonrpc' => '2.0', 'id' => null, 'error' => array('code' => -32700, 'message' => 'JSON inválido')), 400);
    }

    zoe_mcp_assumir_admin();

    // Registra o último uso (no máximo uma vez por minuto, para não pesar).
    $todas = zoe_mcp_conexoes();
    if (isset($todas[$conexao['id']]) && time() - (int) (isset($todas[$conexao['id']]['uso']) ? $todas[$conexao['id']]['uso'] : 0) > 60) {
        $todas[$conexao['id']]['uso'] = time();
        update_option('zoe_mcp_conexoes', $todas, false);
    }

    $lote = isset($corpo[0]) && is_array($corpo[0]) ? $corpo : array($corpo);
    $respostas = array();
    foreach ($lote as $msg) {
        $r = zoe_mcp_rpc(is_array($msg) ? $msg : array(), $conexao);
        if ($r !== null) {
            $respostas[] = $r;
        }
    }
    if (!$respostas) {
        return new WP_REST_Response(null, 202);
    }
    $saida = isset($corpo[0]) && is_array($corpo[0]) ? $respostas : $respostas[0];
    return new WP_REST_Response($saida, 200);
}

/* ---------------- Rotas ---------------- */

add_action('rest_api_init', function () {
    register_rest_route('zoe-mcp/v1', '/conector/(?P<token>[A-Za-z0-9]{24,64})', array(
        'methods' => array('GET', 'POST', 'DELETE'),
        'callback' => 'zoe_mcp_http',
        'permission_callback' => '__return_true',
    ));

    // Gestão das conexões — só administradores do WordPress.
    $admin = function () {
        return current_user_can('manage_options');
    };
    register_rest_route('zoe/v1', '/conexoes', array(
        array(
            'methods' => 'GET',
            'permission_callback' => $admin,
            'callback' => function () {
                $out = array();
                foreach (zoe_mcp_conexoes() as $id => $c) {
                    $out[] = array(
                        'id' => $id,
                        'nome' => $c['nome'],
                        'criado' => date_i18n('d/m/Y', $c['criado']),
                        'uso' => !empty($c['uso']) ? date_i18n('d/m/Y H:i', $c['uso']) : '',
                        'url' => zoe_mcp_url($c['token']),
                    );
                }
                return $out;
            },
        ),
        array(
            'methods' => 'POST',
            'permission_callback' => $admin,
            'callback' => function ($q) {
                $d = $q->get_json_params();
                $nome = trim(sanitize_text_field((string) (isset($d['nome']) ? $d['nome'] : '')));
                if ($nome === '') {
                    return new WP_Error('nome', 'Dê um nome à conexão (ex.: o nome da pessoa)', array('status' => 400));
                }
                $todas = zoe_mcp_conexoes();
                $id = 'c' . time() . wp_rand(100, 999);
                $todas[$id] = array(
                    'token' => wp_generate_password(40, false, false),
                    'nome' => $nome,
                    'criado' => time(),
                    'uso' => 0,
                    'ativo' => 1,
                );
                update_option('zoe_mcp_conexoes', $todas, false);
                return array('id' => $id, 'nome' => $nome, 'url' => zoe_mcp_url($todas[$id]['token']));
            },
        ),
    ));
    register_rest_route('zoe/v1', '/conexoes/(?P<id>[a-z0-9]+)', array(
        'methods' => 'DELETE',
        'permission_callback' => $admin,
        'callback' => function ($q) {
            $todas = zoe_mcp_conexoes();
            if (!isset($todas[$q['id']])) {
                return new WP_Error('nao', 'Conexão não encontrada', array('status' => 404));
            }
            unset($todas[$q['id']]);
            update_option('zoe_mcp_conexoes', $todas, false);
            return array('ok' => true);
        },
    ));
});
