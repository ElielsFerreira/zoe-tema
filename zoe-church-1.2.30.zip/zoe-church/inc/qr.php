<?php

/**
 * Gerador de QR Code próprio (ISO/IEC 18004), sem bibliotecas externas e sem GD.
 * Modo byte, correção de erro nível M, versões 1 a 6 (até 106 bytes).
 * Saídas: matriz (array de linhas de 0/1), PNG (PHP puro + zlib) e SVG.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zoe_QR
{
    /** Nível M: versão => [códigos de correção por bloco, nº de blocos, dados por bloco] */
    private static $tab = array(
        1 => array(10, 1, 16),
        2 => array(16, 1, 28),
        3 => array(26, 1, 44),
        4 => array(18, 2, 32),
        5 => array(24, 2, 43),
        6 => array(16, 4, 27),
    );
    private static $alin = array(1 => array(), 2 => array(6, 18), 3 => array(6, 22), 4 => array(6, 26), 5 => array(6, 30), 6 => array(6, 34));
    private static $exp = array();
    private static $log = array();

    private static function gf()
    {
        if (self::$exp) {
            return;
        }
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            self::$exp[$i] = $x;
            self::$log[$x] = $i;
            $x <<= 1;
            if ($x & 0x100) {
                $x ^= 0x11D;
            }
        }
        for ($i = 255; $i < 512; $i++) {
            self::$exp[$i] = self::$exp[$i - 255];
        }
    }

    private static function mul($a, $b)
    {
        return ($a && $b) ? self::$exp[self::$log[$a] + self::$log[$b]] : 0;
    }

    /** Códigos de correção Reed-Solomon de um bloco. */
    private static function rs($dados, $n)
    {
        $g = array(1);
        for ($i = 0; $i < $n; $i++) {
            $ng = array_fill(0, count($g) + 1, 0);
            foreach ($g as $j => $c) {
                $ng[$j] ^= $c;
                $ng[$j + 1] ^= self::mul($c, self::$exp[$i]);
            }
            $g = $ng;
        }
        $res = array_merge($dados, array_fill(0, $n, 0));
        $nd = count($dados);
        $ng = count($g);
        for ($i = 0; $i < $nd; $i++) {
            $c = $res[$i];
            if ($c) {
                for ($j = 0; $j < $ng; $j++) {
                    $res[$i + $j] ^= self::mul($g[$j], $c);
                }
            }
        }
        return array_slice($res, $nd);
    }

    /** Matriz do QR Code. $mascara = -1 escolhe a melhor; 0..7 força uma (para testes). */
    public static function matriz($texto, $mascara = -1)
    {
        self::gf();
        $bytes = array_values(unpack('C*', (string) $texto));
        $len = count($bytes);
        $ver = 0;
        foreach (self::$tab as $v => $t) {
            if ($len <= intdiv($t[1] * $t[2] * 8 - 12, 8)) {
                $ver = $v;
                break;
            }
        }
        if (!$ver) {
            return null; // texto longo demais
        }
        list($nec, $nblocos, $ndados) = self::$tab[$ver];
        $cap = $nblocos * $ndados;

        // Fluxo de bits: modo byte (0100), tamanho (8 bits), dados, terminador, preenchimento.
        $bits = '0100' . str_pad(decbin($len), 8, '0', STR_PAD_LEFT);
        foreach ($bytes as $b) {
            $bits .= str_pad(decbin($b), 8, '0', STR_PAD_LEFT);
        }
        $bits .= str_repeat('0', min(4, $cap * 8 - strlen($bits)));
        if (strlen($bits) % 8) {
            $bits .= str_repeat('0', 8 - strlen($bits) % 8);
        }
        $cw = array();
        foreach (str_split($bits, 8) as $o) {
            $cw[] = bindec($o);
        }
        for ($p = 0; count($cw) < $cap; $p++) {
            $cw[] = $p % 2 ? 0x11 : 0xEC;
        }

        // Blocos, correção e intercalação.
        $blocos = array_chunk($cw, $ndados);
        $ecs = array();
        foreach ($blocos as $b) {
            $ecs[] = self::rs($b, $nec);
        }
        $final = array();
        for ($i = 0; $i < $ndados; $i++) {
            foreach ($blocos as $b) {
                $final[] = $b[$i];
            }
        }
        for ($i = 0; $i < $nec; $i++) {
            foreach ($ecs as $e) {
                $final[] = $e[$i];
            }
        }
        $fluxo = '';
        foreach ($final as $c) {
            $fluxo .= str_pad(decbin($c), 8, '0', STR_PAD_LEFT);
        }

        // Padrões fixos.
        $n = 17 + 4 * $ver;
        $m = array_fill(0, $n, array_fill(0, $n, 0));
        $f = array_fill(0, $n, array_fill(0, $n, false));
        $set = function ($r, $c, $v) use (&$m, &$f, $n) {
            if ($r >= 0 && $r < $n && $c >= 0 && $c < $n) {
                $m[$r][$c] = $v ? 1 : 0;
                $f[$r][$c] = true;
            }
        };
        foreach (array(array(0, 0), array(0, $n - 7), array($n - 7, 0)) as $p) {
            for ($dy = -1; $dy <= 7; $dy++) {
                for ($dx = -1; $dx <= 7; $dx++) {
                    $dentro = $dy >= 0 && $dy <= 6 && $dx >= 0 && $dx <= 6;
                    $esc = $dentro && ($dy === 0 || $dy === 6 || $dx === 0 || $dx === 6 || ($dy >= 2 && $dy <= 4 && $dx >= 2 && $dx <= 4));
                    $set($p[0] + $dy, $p[1] + $dx, $esc);
                }
            }
        }
        for ($i = 8; $i < $n - 8; $i++) {
            $set(6, $i, $i % 2 === 0);
            $set($i, 6, $i % 2 === 0);
        }
        $al = self::$alin[$ver];
        $na = count($al);
        for ($a = 0; $a < $na; $a++) {
            for ($b = 0; $b < $na; $b++) {
                if (($a === 0 && $b === 0) || ($a === 0 && $b === $na - 1) || ($a === $na - 1 && $b === 0)) {
                    continue;
                }
                for ($dy = -2; $dy <= 2; $dy++) {
                    for ($dx = -2; $dx <= 2; $dx++) {
                        $set($al[$a] + $dy, $al[$b] + $dx, max(abs($dy), abs($dx)) !== 1);
                    }
                }
            }
        }
        // Reserva das áreas de formato (valores gravados depois) e módulo escuro.
        for ($i = 0; $i < 9; $i++) {
            if ($i === 6) {
                continue; // é linha/coluna de sincronismo
            }
            $set(8, $i, 0);
            $set($i, 8, 0);
        }
        for ($i = 0; $i < 8; $i++) {
            $set(8, $n - 1 - $i, 0);
            $set($n - 1 - $i, 8, 0);
        }
        $set($n - 8, 8, 1);

        // Dados em zigue-zague.
        $k = 0;
        $tot = strlen($fluxo);
        for ($dir = $n - 1; $dir >= 1; $dir -= 2) {
            if ($dir === 6) {
                $dir = 5;
            }
            $sobe = (($dir + 1) & 2) === 0;
            for ($v = 0; $v < $n; $v++) {
                for ($j = 0; $j < 2; $j++) {
                    $c = $dir - $j;
                    $r = $sobe ? $n - 1 - $v : $v;
                    if (!$f[$r][$c]) {
                        $m[$r][$c] = ($k < $tot && $fluxo[$k] === '1') ? 1 : 0;
                        $k++;
                    }
                }
            }
        }

        // Máscara.
        $melhor = null;
        $menor = PHP_INT_MAX;
        foreach ($mascara >= 0 ? array($mascara) : range(0, 7) as $mk) {
            $t = self::aplicar($m, $f, $n, $mk);
            $pen = $mascara >= 0 ? 0 : self::penalidade($t, $n);
            if ($pen < $menor) {
                $menor = $pen;
                $melhor = $t;
            }
        }
        return array_map(function ($l) {
            return implode('', $l);
        }, $melhor);
    }

    private static function aplicar($m, $f, $n, $mk)
    {
        for ($r = 0; $r < $n; $r++) {
            for ($c = 0; $c < $n; $c++) {
                if ($f[$r][$c]) {
                    continue;
                }
                switch ($mk) {
                    case 0: $inv = ($r + $c) % 2 === 0; break;
                    case 1: $inv = $r % 2 === 0; break;
                    case 2: $inv = $c % 3 === 0; break;
                    case 3: $inv = ($r + $c) % 3 === 0; break;
                    case 4: $inv = (intdiv($r, 2) + intdiv($c, 3)) % 2 === 0; break;
                    case 5: $inv = ($r * $c) % 2 + ($r * $c) % 3 === 0; break;
                    case 6: $inv = (($r * $c) % 2 + ($r * $c) % 3) % 2 === 0; break;
                    default: $inv = (($r + $c) % 2 + ($r * $c) % 3) % 2 === 0;
                }
                if ($inv) {
                    $m[$r][$c] ^= 1;
                }
            }
        }
        // Bits de formato: nível M (00) + máscara, BCH(15,5), XOR 0x5412.
        $d = $mk;
        $rem = $d;
        for ($i = 0; $i < 10; $i++) {
            $rem = ($rem << 1) ^ (($rem >> 9) * 0x537);
        }
        $fmt = (($d << 10) | ($rem & 0x3FF)) ^ 0x5412;
        $bit = function ($i) use ($fmt) {
            return ($fmt >> $i) & 1;
        };
        for ($i = 0; $i <= 5; $i++) {
            $m[$i][8] = $bit($i);
        }
        $m[7][8] = $bit(6);
        $m[8][8] = $bit(7);
        $m[8][7] = $bit(8);
        for ($i = 9; $i < 15; $i++) {
            $m[8][14 - $i] = $bit($i);
        }
        for ($i = 0; $i < 8; $i++) {
            $m[8][$n - 1 - $i] = $bit($i);
        }
        for ($i = 8; $i < 15; $i++) {
            $m[$n - 15 + $i][8] = $bit($i);
        }
        $m[$n - 8][8] = 1;
        return $m;
    }

    private static function penalidade($m, $n)
    {
        $p = 0;
        $linhas = array();
        for ($r = 0; $r < $n; $r++) {
            $linhas[] = implode('', $m[$r]);
            $col = '';
            for ($c = 0; $c < $n; $c++) {
                $col .= $m[$c][$r];
            }
            $linhas[] = $col;
        }
        foreach ($linhas as $l) {
            if (preg_match_all('/0{5,}|1{5,}/', $l, $mm)) {
                foreach ($mm[0] as $run) {
                    $p += 3 + strlen($run) - 5;
                }
            }
            $pad = '0000' . $l . '0000';
            $p += 40 * (substr_count($pad, '10111010000') + substr_count($pad, '00001011101'));
        }
        $esc = 0;
        for ($r = 0; $r < $n; $r++) {
            for ($c = 0; $c < $n; $c++) {
                $esc += $m[$r][$c];
                if ($r < $n - 1 && $c < $n - 1 && $m[$r][$c] === $m[$r][$c + 1] && $m[$r][$c] === $m[$r + 1][$c] && $m[$r][$c] === $m[$r + 1][$c + 1]) {
                    $p += 3;
                }
            }
        }
        $p += 10 * (int) max(0, ceil(abs($esc * 20 - $n * $n * 10) / ($n * $n)) - 1);
        return $p;
    }

    /** PNG em PHP puro (zlib). $escala = pixels por módulo; $borda = módulos de margem branca. */
    public static function png($texto, $escala = 10, $borda = 4)
    {
        $mat = self::matriz($texto);
        if (!$mat) {
            return '';
        }
        $n = count($mat);
        $w = ($n + 2 * $borda) * $escala;
        $branca = "\0" . str_repeat("\xFF", $w);
        $raw = str_repeat($branca, $borda * $escala);
        $margem = str_repeat("\xFF", $borda * $escala);
        foreach ($mat as $linha) {
            $px = "\0" . $margem;
            for ($c = 0; $c < $n; $c++) {
                $px .= str_repeat($linha[$c] === '1' ? "\x00" : "\xFF", $escala);
            }
            $px .= $margem;
            $raw .= str_repeat($px, $escala);
        }
        $raw .= str_repeat($branca, $borda * $escala);
        $chunk = function ($tipo, $dados) {
            return pack('N', strlen($dados)) . $tipo . $dados . pack('N', crc32($tipo . $dados));
        };
        return "\x89PNG\r\n\x1a\n" . $chunk('IHDR', pack('NNCCCCC', $w, $w, 8, 0, 0, 0, 0)) . $chunk('IDAT', gzcompress($raw, 9)) . $chunk('IEND', '');
    }

    /** SVG (para páginas web). */
    public static function svg($texto, $borda = 2, $cor = '#141216')
    {
        $mat = self::matriz($texto);
        if (!$mat) {
            return '';
        }
        $n = count($mat);
        $t = $n + 2 * $borda;
        $d = '';
        foreach ($mat as $r => $linha) {
            for ($c = 0; $c < $n; $c++) {
                if ($linha[$c] === '1') {
                    $d .= 'M' . ($c + $borda) . ' ' . ($r + $borda) . 'h1v1h-1z';
                }
            }
        }
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $t . ' ' . $t . '" shape-rendering="crispEdges"><rect width="' . $t . '" height="' . $t . '" fill="#fff"/><path fill="' . $cor . '" d="' . $d . '"/></svg>';
    }
}
