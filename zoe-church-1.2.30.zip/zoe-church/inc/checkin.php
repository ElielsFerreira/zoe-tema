<?php

/**
 * Check-in com QR Code.
 *
 * - Cada evento pode ligar o check-in (meta _zoe_checkin) e dizer a partir de que
 *   data de compra os ingressos valem (_zoe_checkin_desde), para não misturar
 *   compras de edições anteriores na mesma página de evento.
 * - Cada inscrição (vaga) de um pedido pago vira um ingresso com código assinado:
 *   Z<pedido>-<item>-<vaga>-<assinatura>. Ninguém consegue inventar um código válido.
 * - O check-in fica numa tabela própria com o código como chave única: se duas
 *   portas lerem o mesmo QR ao mesmo tempo, só uma registra.
 * - O leitor abre por um link secreto gerado no Painel (Check-in), sem login,
 *   para os voluntários usarem no próprio celular. Cada link pode ser revogado.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ================= Base ================= */

function zoe_ci_segredo()
{
    $s = get_option('zoe_ci_segredo');
    if (!$s) {
        $s = wp_generate_password(48, false, false);
        update_option('zoe_ci_segredo', $s, false);
    }
    return $s;
}

function zoe_ci_tabela()
{
    global $wpdb;
    return $wpdb->prefix . 'zoe_checkin';
}

add_action('init', function () {
    if (get_option('zoe_ci_db') === '1') {
        return;
    }
    global $wpdb;
    $t = zoe_ci_tabela();
    $wpdb->query("CREATE TABLE IF NOT EXISTS $t (
        codigo VARCHAR(48) NOT NULL,
        pedido BIGINT UNSIGNED NOT NULL,
        item BIGINT UNSIGNED NOT NULL,
        vaga SMALLINT UNSIGNED NOT NULL,
        produto BIGINT UNSIGNED NOT NULL,
        quando INT UNSIGNED NOT NULL,
        por VARCHAR(80) NOT NULL DEFAULT '',
        modo VARCHAR(10) NOT NULL DEFAULT 'qr',
        PRIMARY KEY (codigo),
        KEY produto (produto),
        KEY pedido (pedido)
    ) " . $wpdb->get_charset_collate()); // phpcs:ignore
    if ($wpdb->get_var("SHOW TABLES LIKE '$t'") === $t) { // phpcs:ignore
        update_option('zoe_ci_db', '1');
    }
});

function zoe_ci_ativo($pid)
{
    return $pid && get_post_meta($pid, '_zoe_checkin', true) === '1';
}

function zoe_ci_desde($pid)
{
    return (string) get_post_meta($pid, '_zoe_checkin_desde', true);
}

function zoe_ci_eventos_ativos()
{
    $ids = get_posts(array('post_type' => 'product', 'post_status' => array('publish', 'draft', 'private'), 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_zoe_checkin', 'meta_value' => '1'));
    return array_map('intval', $ids);
}

function zoe_ci_assinar($txt, $n = 8)
{
    return strtoupper(substr(hash_hmac('sha256', $txt, zoe_ci_segredo()), 0, $n));
}

function zoe_ci_codigo($oid, $iid, $vaga)
{
    return 'Z' . strtoupper(base_convert((string) $oid, 10, 36)) . '-' . strtoupper(base_convert((string) $iid, 10, 36)) . '-' . (int) $vaga . '-' . zoe_ci_assinar("$oid|$iid|$vaga");
}

/** Decodifica e confere a assinatura. Retorna [pedido, item, vaga] ou null. */
function zoe_ci_ler_codigo($codigo)
{
    $codigo = strtoupper(trim((string) $codigo));
    if (!preg_match('/^Z([0-9A-Z]{1,10})-([0-9A-Z]{1,10})-(\d{1,4})-([0-9A-F]{8})$/', $codigo, $m)) {
        return null;
    }
    $oid = (int) base_convert($m[1], 36, 10);
    $iid = (int) base_convert($m[2], 36, 10);
    $vaga = (int) $m[3];
    if (!hash_equals(zoe_ci_assinar("$oid|$iid|$vaga"), $m[4])) {
        return null;
    }
    return array($oid, $iid, $vaga);
}

function zoe_ci_link_ingresso($oid)
{
    return add_query_arg('zoe_ingresso', $oid . '-' . zoe_ci_assinar("ing|$oid", 12), home_url('/'));
}

function zoe_ci_qr_url($codigo)
{
    return rest_url('zoe/v1/qr/' . $codigo);
}

/**
 * Nomes recuperados pelo relatório (inclui campos apagados do formulário antigo):
 * "pedido|vaga" => nome. Guardado por 10 min.
 */
function zoe_ci_nomes_rel($pid)
{
    static $mem = array();
    if (isset($mem[$pid])) {
        return $mem[$pid];
    }
    $k = 'zoe_ci_nomes_' . $pid;
    $m = get_transient($k);
    if (!is_array($m)) {
        $m = array();
        if (function_exists('zoe_rel_dados')) {
            $d = zoe_rel_dados('todos', (string) $pid);
            foreach ((array) $d['eventos'] as $ev) {
                foreach ((array) $ev['linhas'] as $l) {
                    $nm = isset($l['Nome completo']) ? trim((string) $l['Nome completo']) : '';
                    if ($nm !== '' && isset($l['Pedido'], $l['Inscrição'])) {
                        $m[$l['Pedido'] . '|' . (int) $l['Inscrição']] = $nm;
                    }
                    // telefone recuperado (WhatsApp/telefone, inclusive do responsável)
                    if (isset($l['Pedido']) && !isset($m[$l['Pedido'] . '|tel'])) {
                        foreach (array('WhatsApp', 'WhatsApp do responsável', 'Telefone', 'Contato do responsável') as $ck) {
                            $dg = isset($l[$ck]) ? preg_replace('/\D/', '', (string) $l[$ck]) : '';
                            if (strlen($dg) >= 10) {
                                $m[$l['Pedido'] . '|tel'] = $dg;
                                break;
                            }
                        }
                    }
                }
            }
        }
        set_transient($k, $m, 600);
    }
    return $mem[$pid] = $m;
}

/** Ingressos (uma entrada por vaga) de um pedido pago, nos eventos com check-in. */
function zoe_ci_ingressos($order, $pids = null)
{
    if (!$order || !is_a($order, 'WC_Order') || !in_array($order->get_status(), array('processing', 'completed'), true)) {
        return array();
    }
    $d = $order->get_date_paid() ? $order->get_date_paid() : $order->get_date_created();
    $ts = $d ? $d->getTimestamp() : 0;
    $comprador = zoe_conf_nome_completo($order);
    if ($comprador === '' && function_exists('zoe_pend_contato')) {
        $ct = zoe_pend_contato($order); // formulário antigo: nome em campos do plugin anterior
        $comprador = isset($ct['nome']) ? trim((string) $ct['nome']) : '';
    }
    $out = array();
    $primeiro = true;
    foreach ($order->get_items() as $iid => $item) {
        if (!is_a($item, 'WC_Order_Item_Product')) {
            continue;
        }
        $pid = (int) $item->get_product_id();
        if (($pids && !in_array($pid, $pids, true)) || !zoe_ci_ativo($pid)) {
            continue;
        }
        $desde = zoe_ci_desde($pid);
        if ($desde && $ts) {
            try {
                $lim = (new DateTime($desde . ' 00:00:00', wp_timezone()))->getTimestamp();
                if ($ts < $lim) {
                    continue;
                }
            } catch (Exception $e) {
                // data inválida: ignora o filtro
            }
        }
        $qtd = max(1, (int) $item->get_quantity());
        $insc = $item->get_meta('_zoe_inscricoes');
        $prod = $item->get_product();
        $opcao = ($prod && $prod->is_type('variation')) ? wp_strip_all_tags(wc_get_formatted_variation($prod, true, false, false)) : '';
        // Formulário antigo: nomes recuperados pelo relatório; "Livia / Alice" numa vaga só vira um nome por vaga.
        $antigos = array();
        if (!is_array($insc)) {
            $mapa = zoe_ci_nomes_rel($pid);
            $num = $order->get_order_number();
            for ($v = 1; $v <= $qtd; $v++) {
                $antigos[$v] = isset($mapa[$num . '|' . $v]) ? $mapa[$num . '|' . $v] : '';
            }
            if ($qtd > 1 && strpos($antigos[1], '/') !== false) {
                $partes = array_values(array_filter(array_map('trim', explode('/', $antigos[1]))));
                if (count($partes) === $qtd) {
                    foreach ($partes as $k => $pt) {
                        $antigos[$k + 1] = $pt;
                    }
                }
            }
        }
        $primeiroNome = '';
        for ($v = 1; $v <= $qtd; $v++) {
            $nm = (is_array($insc) && isset($insc[$v - 1])) ? zoe_conf_nome_insc($insc[$v - 1]) : (isset($antigos[$v]) ? $antigos[$v] : '');
            if ($nm === '' && $v === 1 && $primeiro) {
                $nm = $comprador; // formulário antigo: só tinha os dados de quem comprou
            }
            if ($v === 1) {
                $primeiroNome = $nm;
            }
            $ref = $primeiroNome !== '' ? $primeiroNome : $comprador;
            $out[] = array(
                'codigo'    => zoe_ci_codigo($order->get_id(), $iid, $v),
                'pedido'    => $order->get_id(),
                'item'      => (int) $iid,
                'vaga'      => $v,
                'qtd'       => $qtd,
                'nome'      => $nm !== '' ? $nm : 'Vaga ' . $v . ' de ' . $qtd . ($ref !== '' ? ' · pedido de ' . $ref : ''),
                'evento'    => get_the_title($pid),
                'opcao'     => $opcao,
                'pid'       => $pid,
                'comprador' => $comprador,
            );
        }
        $primeiro = false;
    }
    return $out;
}

/** Registro de check-in de uma lista de códigos: codigo => linha. */
function zoe_ci_registros($codigos)
{
    global $wpdb;
    $codigos = array_values(array_filter(array_map('strval', (array) $codigos)));
    if (!$codigos) {
        return array();
    }
    $t = zoe_ci_tabela();
    $out = array();
    foreach (array_chunk($codigos, 300) as $lote) {
        $in = implode(',', array_fill(0, count($lote), '%s'));
        foreach ((array) $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE codigo IN ($in)", $lote), ARRAY_A) as $r) { // phpcs:ignore
            $out[$r['codigo']] = $r;
        }
    }
    return $out;
}

/** Lista completa de ingressos de um conjunto de eventos (guardada por 60 s). */
function zoe_ci_lista($pids)
{
    $pids = array_values(array_unique(array_map('intval', (array) $pids)));
    sort($pids);
    $chave = 'zoe_ci_lista_' . md5(implode(',', $pids));
    $l = get_transient($chave);
    if (is_array($l)) {
        return $l;
    }
    $l = array();
    foreach (zoe_envio_pedidos($pids, 0) as $o) {
        $tel = preg_replace('/\D/', '', (string) $o->get_billing_phone());
        $email = strtolower((string) $o->get_billing_email());
        foreach (zoe_ci_ingressos($o, $pids) as $i) {
            $i['tel'] = $tel;
            $i['email'] = $email;
            $l[] = $i;
        }
    }
    set_transient($chave, $l, 60);
    return $l;
}

function zoe_ci_normalizar($s)
{
    return strtolower(remove_accents((string) $s));
}

/** Registra o check-in. Retorna ['status' => ok|ja|..., ...]. */
function zoe_ci_registrar($ing, $por, $modo)
{
    global $wpdb;
    $t = zoe_ci_tabela();
    $wpdb->query($wpdb->prepare( // phpcs:ignore
        "INSERT IGNORE INTO $t (codigo, pedido, item, vaga, produto, quando, por, modo) VALUES (%s, %d, %d, %d, %d, %d, %s, %s)",
        $ing['codigo'], $ing['pedido'], $ing['item'], $ing['vaga'], $ing['pid'], time(), mb_substr((string) $por, 0, 80), $modo
    ));
    $novo = $wpdb->rows_affected > 0; // ler antes de qualquer outra consulta
    $reg = zoe_ci_registros(array($ing['codigo']));
    $r = isset($reg[$ing['codigo']]) ? $reg[$ing['codigo']] : null;
    return array(
        'status' => $novo ? 'ok' : 'ja',
        'codigo' => $ing['codigo'],
        'nome'   => $ing['nome'],
        'evento' => $ing['evento'],
        'opcao'  => $ing['opcao'],
        'pedido' => $ing['pedido'],
        'item'   => $ing['item'],
        'vaga'   => $ing['vaga'],
        'quando' => $r ? wp_date('H:i', (int) $r['quando']) : '',
        'dia'    => $r ? wp_date('d/m', (int) $r['quando']) : '',
        'por'    => $r ? $r['por'] : '',
    );
}

/** Valida um código lido no leitor e faz o check-in. */
function zoe_ci_validar($codigo, $pids, $por)
{
    $p = zoe_ci_ler_codigo($codigo);
    if (!$p) {
        return array('status' => 'invalido', 'msg' => 'Este QR Code não é um ingresso da Zoe.');
    }
    list($oid, $iid, $vaga) = $p;
    $o = wc_get_order($oid);
    if (!$o) {
        return array('status' => 'invalido', 'msg' => 'Pedido não encontrado.');
    }
    $item = $o->get_item($iid);
    if (!$item || !is_a($item, 'WC_Order_Item_Product')) {
        return array('status' => 'invalido', 'msg' => 'Ingresso não encontrado no pedido.');
    }
    $pid = (int) $item->get_product_id();
    if (!in_array($pid, $pids, true)) {
        return array('status' => 'outro', 'msg' => 'Este ingresso é de outro evento: ' . get_the_title($pid) . '.');
    }
    if (!in_array($o->get_status(), array('processing', 'completed'), true)) {
        return array('status' => 'naopago', 'msg' => 'O pagamento deste pedido não foi confirmado (' . wc_get_order_status_name($o->get_status()) . ').', 'pedido' => $oid);
    }
    foreach (zoe_ci_ingressos($o, array($pid)) as $ing) {
        if ($ing['item'] === $iid && $ing['vaga'] === $vaga) {
            return zoe_ci_registrar($ing, $por, 'qr');
        }
    }
    return array('status' => 'invalido', 'msg' => 'Este ingresso não vale para esta edição do evento.');
}

/* ================= Links do leitor ================= */

function zoe_ci_links()
{
    $l = get_option('zoe_ci_links', array());
    return is_array($l) ? $l : array();
}

function zoe_ci_link_por_token($tok)
{
    foreach (zoe_ci_links() as $id => $l) {
        if (!empty($l['ativo']) && hash_equals($l['token'], (string) $tok)) {
            $l['id'] = $id;
            $l['eventos'] = array_values(array_filter(array_map('intval', (array) $l['eventos']), 'zoe_ci_ativo'));
            return $l;
        }
    }
    return null;
}

function zoe_ci_url_leitor($tok)
{
    return add_query_arg('zoe_checkin', $tok, home_url('/'));
}

function zoe_ci_resumo_eventos($pids)
{
    global $wpdb;
    $out = array();
    $t = zoe_ci_tabela();
    foreach ($pids as $pid) {
        $total = count(zoe_ci_lista(array($pid)));
        $pres = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE produto = %d", $pid)); // phpcs:ignore
        $out[] = array('id' => $pid, 'nome' => get_the_title($pid), 'total' => $total, 'presentes' => $pres, 'desde' => zoe_ci_desde($pid));
    }
    return $out;
}

/* ================= E-mail do ingresso ================= */

/** Cards de ingresso para e-mail (tabelas, compatível com Gmail/Outlook). */
function zoe_ci_cards_html($ings)
{
    $sans = "font-family:'Inter Tight',Helvetica,Arial,sans-serif;";
    $h = '';
    foreach ($ings as $i) {
        $pid = $i['pid'];
        $quando = zoe_conf_quando((string) get_post_meta($pid, '_zoe_data', true), (string) get_post_meta($pid, '_zoe_data_fim', true));
        $local = (string) get_post_meta($pid, '_zoe_local', true);
        $meta = array_filter(array($i['opcao'], $quando ? ucfirst($quando) : '', $local));
        $h .= '<table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="margin:0 0 16px;background:#141216;border-radius:18px">'
            . '<tr><td style="padding:24px 24px 6px;' . $sans . '">'
            . '<div style="font-size:11px;letter-spacing:.22em;text-transform:uppercase;font-weight:600;color:#bdb6ad">Ingresso · ' . esc_html($i['evento']) . '</div>'
            . '<div style="margin:10px 0 6px;font-family:\'Instrument Serif\',Georgia,\'Times New Roman\',serif;font-style:italic;font-size:30px;line-height:1.1;color:#ffffff">' . esc_html($i['nome']) . '</div>'
            . ($meta ? '<div style="font-size:13px;line-height:1.6;color:#a8a29b">' . esc_html(implode(' · ', $meta)) . '</div>' : '')
            . '</td></tr>'
            . '<tr><td align="center" style="padding:18px 24px 10px">'
            . '<table role="presentation" border="0" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:14px"><tr><td style="padding:12px;line-height:0">'
            . '<img src="' . esc_url(zoe_ci_qr_url($i['codigo'])) . '" width="210" height="210" alt="QR Code do ingresso" style="display:block;width:210px;height:210px;border:0">'
            . '</td></tr></table></td></tr>'
            . '<tr><td align="center" style="padding:4px 24px 22px;' . $sans . 'font-size:12px;letter-spacing:.12em;color:#8d8792">' . esc_html($i['codigo']) . '</td></tr>'
            . '</table>';
    }
    return $h;
}

function zoe_ci_assunto($ings)
{
    $evs = array_values(array_unique(wp_list_pluck($ings, 'evento')));
    return (count($ings) > 1 ? 'Seus ingressos' : 'Seu ingresso') . ' · ' . implode(' + ', $evs);
}

function zoe_ci_email_html($order, $ings)
{
    $nome = zoe_conf_primeiro_nome($order);
    $evs = array_values(array_unique(wp_list_pluck($ings, 'evento')));
    $varios = count($ings) > 1;
    $txt = 'font-size:16px;line-height:1.65;color:#3d3a40';
    $c  = zoe_email_eyebrow(($varios ? 'Seus ingressos' : 'Seu ingresso') . ' · ' . implode(' + ', $evs));
    $c .= zoe_email_titulo('Olá' . ($nome ? ', ' . $nome : '') . '.');
    $c .= '<div style="' . $txt . ';margin:0 0 24px"><p style="margin:0 0 12px">' . ($varios ? 'Aqui estão os ingressos da sua inscrição.' : 'Aqui está o seu ingresso.') . ' No dia, é só mostrar o QR Code na entrada' . ($varios ? ': cada pessoa tem o seu.' : '.') . '</p>'
        . '<p style="margin:0;color:#6f6a74;font-size:14px">Dica: deixe este e-mail à mão no celular ou tire um print do QR Code.</p></div>';
    $c .= zoe_ci_cards_html($ings);
    $c .= '<div style="margin:8px 0 0">' . zoe_conf_botao(zoe_ci_link_ingresso($order->get_id()), $varios ? 'Abrir ingressos no celular' : 'Abrir ingresso no celular', '#141216') . '</div>';
    $c .= '<div style="font-size:13px;line-height:1.7;color:#6f6a74;margin-top:18px">Pedido nº ' . esc_html($order->get_order_number()) . '. Se o QR Code não abrir, é só dizer seu nome na recepção.</div>';
    $capa = zoe_conf_capa($ings[0]['pid']);
    return zoe_email_moldura(zoe_ci_assunto($ings), $c, $capa, '');
}

/** Envia o ingresso do pedido. $para substitui o destinatário (teste). */
function zoe_ci_enviar($order, $para = '')
{
    $ings = zoe_ci_ingressos($order);
    if (!$ings) {
        return false;
    }
    $teste = $para !== '';
    $para = $teste ? $para : zoe_conf_email($order);
    if (!$para) {
        return false;
    }
    $ok = wp_mail($para, ($teste ? '[TESTE] ' : '') . zoe_ci_assunto($ings), zoe_ci_email_html($order, $ings), array('Content-Type: text/html; charset=UTF-8'));
    if ($ok && !$teste) {
        $order->update_meta_data('_zoe_ci_enviado', time());
        $order->add_order_note('Ingresso com QR Code enviado por e-mail (' . count($ings) . ' ' . (count($ings) > 1 ? 'ingressos' : 'ingresso') . ').');
        $order->save();
    }
    return $ok;
}

/* ================= Rotas ================= */

add_action('rest_api_init', function () {
    // Imagem do QR Code (só para códigos com assinatura válida).
    register_rest_route('zoe/v1', '/qr/(?P<c>[A-Za-z0-9\-]{10,48})', array(
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function ($q) {
            $c = strtoupper((string) $q['c']);
            if (!zoe_ci_ler_codigo($c)) {
                return new WP_Error('nao', 'Código inválido', array('status' => 404));
            }
            $png = Zoe_QR::png($c, 10, 3);
            nocache_headers();
            header_remove('Cache-Control');
            header('Content-Type: image/png');
            header('Cache-Control: public, max-age=31536000, immutable');
            header('Content-Length: ' . strlen($png));
            echo $png; // phpcs:ignore
            exit;
        },
    ));

    // ---- Leitor (link secreto) ----
    $perm = function ($q) {
        return (bool) zoe_ci_link_por_token($q['t']);
    };
    $tok = '/ci/(?P<t>[A-Za-z0-9]{32})';
    register_rest_route('zoe/v1', $tok . '/resumo', array(
        'methods' => 'GET',
        'permission_callback' => $perm,
        'callback' => function ($q) {
            global $wpdb;
            $l = zoe_ci_link_por_token($q['t']);
            $t = zoe_ci_tabela();
            $ult = array();
            if ($l['eventos']) {
                $in = implode(',', array_map('intval', $l['eventos']));
                $rows = $wpdb->get_results("SELECT * FROM $t WHERE produto IN ($in) ORDER BY quando DESC LIMIT 20", ARRAY_A); // phpcs:ignore
                $mapa = array();
                foreach (zoe_ci_lista($l['eventos']) as $i) {
                    $mapa[$i['codigo']] = $i;
                }
                foreach ((array) $rows as $r) {
                    $i = isset($mapa[$r['codigo']]) ? $mapa[$r['codigo']] : null;
                    $ult[] = array('nome' => $i ? $i['nome'] : $r['codigo'], 'evento' => $i ? $i['evento'] : '', 'opcao' => $i ? $i['opcao'] : '', 'quando' => wp_date('H:i', (int) $r['quando']), 'por' => $r['por'], 'modo' => $r['modo'], 'pedido' => (int) $r['pedido'], 'item' => (int) $r['item'], 'vaga' => (int) $r['vaga']);
                }
            }
            return array('nome' => $l['nome'], 'eventos' => zoe_ci_resumo_eventos($l['eventos']), 'ultimos' => $ult);
        },
    ));
    register_rest_route('zoe/v1', $tok . '/ler', array(
        'methods' => 'POST',
        'permission_callback' => $perm,
        'callback' => function ($q) {
            $l = zoe_ci_link_por_token($q['t']);
            $d = $q->get_json_params();
            return zoe_ci_validar(isset($d['codigo']) ? $d['codigo'] : '', $l['eventos'], $l['nome']);
        },
    ));
    register_rest_route('zoe/v1', $tok . '/buscar', array(
        'methods' => 'GET',
        'permission_callback' => $perm,
        'callback' => function ($q) {
            $l = zoe_ci_link_por_token($q['t']);
            $termo = zoe_ci_normalizar(trim((string) $q->get_param('q')));
            if (mb_strlen($termo) < 2) {
                return array();
            }
            $dig = preg_replace('/\D/', '', $termo);
            $achados = array();
            foreach (zoe_ci_lista($l['eventos']) as $i) {
                $alvo = zoe_ci_normalizar($i['nome'] . ' ' . $i['comprador'] . ' ' . $i['email']);
                $bate = strpos($alvo, $termo) !== false
                    || (strlen($dig) >= 4 && strpos($i['tel'], $dig) !== false)
                    || ($dig !== '' && $dig === (string) $i['pedido']);
                if ($bate) {
                    $achados[] = $i;
                    if (count($achados) >= 40) {
                        break;
                    }
                }
            }
            $reg = zoe_ci_registros(wp_list_pluck($achados, 'codigo'));
            return array_map(function ($i) use ($reg) {
                $r = isset($reg[$i['codigo']]) ? $reg[$i['codigo']] : null;
                return array(
                    'nome' => $i['nome'], 'evento' => $i['evento'], 'opcao' => $i['opcao'], 'comprador' => $i['comprador'],
                    'tel' => $i['tel'], 'pedido' => $i['pedido'], 'item' => $i['item'], 'vaga' => $i['vaga'], 'qtd' => $i['qtd'],
                    'checkin' => $r ? array('quando' => wp_date('H:i', (int) $r['quando']), 'dia' => wp_date('d/m', (int) $r['quando']), 'por' => $r['por'], 'modo' => $r['modo']) : null,
                );
            }, $achados);
        },
    ));
    $acharIngresso = function ($l, $d) {
        $o = wc_get_order(absint(isset($d['pedido']) ? $d['pedido'] : 0));
        if (!$o) {
            return null;
        }
        foreach (zoe_ci_ingressos($o, $l['eventos']) as $i) {
            if ($i['item'] === absint(isset($d['item']) ? $d['item'] : 0) && $i['vaga'] === absint(isset($d['vaga']) ? $d['vaga'] : 0)) {
                return $i;
            }
        }
        return null;
    };
    register_rest_route('zoe/v1', $tok . '/marcar', array(
        'methods' => 'POST',
        'permission_callback' => $perm,
        'callback' => function ($q) use ($acharIngresso) {
            $l = zoe_ci_link_por_token($q['t']);
            $i = $acharIngresso($l, $q->get_json_params());
            return $i ? zoe_ci_registrar($i, $l['nome'], 'manual') : new WP_Error('nao', 'Ingresso não encontrado', array('status' => 404));
        },
    ));
    register_rest_route('zoe/v1', $tok . '/desfazer', array(
        'methods' => 'POST',
        'permission_callback' => $perm,
        'callback' => function ($q) use ($acharIngresso) {
            global $wpdb;
            $l = zoe_ci_link_por_token($q['t']);
            $i = $acharIngresso($l, $q->get_json_params());
            if (!$i) {
                return new WP_Error('nao', 'Ingresso não encontrado', array('status' => 404));
            }
            $wpdb->delete(zoe_ci_tabela(), array('codigo' => $i['codigo']));
            return array('ok' => true, 'nome' => $i['nome']);
        },
    ));

    // ---- Painel (equipe logada) ----
    $equipe = function () {
        return current_user_can('manage_woocommerce');
    };
    register_rest_route('zoe/v1', '/checkin', array(
        array(
            'methods' => 'GET',
            'permission_callback' => $equipe,
            'callback' => function () {
                $evs = zoe_ci_eventos_ativos();
                $links = array();
                foreach (zoe_ci_links() as $id => $l) {
                    if (empty($l['ativo'])) {
                        continue;
                    }
                    $url = zoe_ci_url_leitor($l['token']);
                    $links[] = array(
                        'id' => $id,
                        'nome' => $l['nome'],
                        'eventos' => implode(', ', array_map('get_the_title', array_filter(array_map('intval', (array) $l['eventos'])))),
                        'criado' => wp_date('d/m/Y', $l['criado']),
                        'url' => $url,
                        'qr' => 'data:image/png;base64,' . base64_encode(Zoe_QR::png($url, 6, 2)),
                    );
                }
                return array('eventos' => zoe_ci_resumo_eventos($evs), 'links' => $links);
            },
        ),
        array(
            'methods' => 'POST',
            'permission_callback' => $equipe,
            'callback' => function ($q) {
                $d = $q->get_json_params();
                $nome = trim(sanitize_text_field((string) (isset($d['nome']) ? $d['nome'] : '')));
                $evs = array_values(array_filter(array_map('intval', (array) (isset($d['eventos']) ? $d['eventos'] : array())), 'zoe_ci_ativo'));
                if ($nome === '') {
                    return new WP_Error('nome', 'Dê um nome ao link (ex.: Porta principal)', array('status' => 400));
                }
                if (!$evs) {
                    return new WP_Error('evs', 'Escolha pelo menos um evento com check-in ligado', array('status' => 400));
                }
                $todos = zoe_ci_links();
                $id = 'l' . time() . wp_rand(10, 99);
                $todos[$id] = array('token' => wp_generate_password(32, false, false), 'nome' => $nome, 'eventos' => $evs, 'criado' => time(), 'ativo' => 1, 'por' => wp_get_current_user()->display_name);
                update_option('zoe_ci_links', $todos, false);
                return array('id' => $id, 'url' => zoe_ci_url_leitor($todos[$id]['token']));
            },
        ),
    ));
    // Quem comprou sem e-mail (formulário antigo): lista para mandar o ingresso pelo WhatsApp.
    register_rest_route('zoe/v1', '/checkin/sem-email', array(
        'methods' => 'GET',
        'permission_callback' => $equipe,
        'callback' => function () {
            $evs = zoe_ci_eventos_ativos();
            $out = array();
            $vistos = array();
            foreach (zoe_ci_lista($evs) as $i) {
                if (isset($vistos[$i['pedido']])) {
                    $out[$vistos[$i['pedido']]]['inscritos'][] = $i['nome'];
                    continue;
                }
                $o = wc_get_order($i['pedido']);
                if (!$o || zoe_conf_email($o)) {
                    continue;
                }
                $ct = function_exists('zoe_pend_contato') ? zoe_pend_contato($o) : array();
                $tel = preg_replace('/\D/', '', isset($ct['tel']) ? (string) $ct['tel'] : (string) $o->get_billing_phone());
                if ($tel === '') {
                    $mapa = zoe_ci_nomes_rel($i['pid']);
                    $tel = isset($mapa[$o->get_order_number() . '|tel']) ? $mapa[$o->get_order_number() . '|tel'] : '';
                }
                if ($tel !== '' && strlen($tel) <= 11) {
                    $tel = '55' . ltrim($tel, '0');
                }
                $nome = !empty($ct['nome']) ? $ct['nome'] : ($i['comprador'] ? $i['comprador'] : $i['nome']);
                $link = zoe_ci_link_ingresso($i['pedido']);
                $msg = 'Olá' . ($nome ? ', ' . strtok($nome, ' ') : '') . '! Aqui está o seu ingresso para o ' . $i['evento'] . ': ' . $link . ' No dia, é só mostrar o QR Code na entrada. Zoe Church';
                $vistos[$i['pedido']] = count($out);
                $out[] = array(
                    'pedido' => $i['pedido'],
                    'nome' => $nome,
                    'evento' => $i['evento'],
                    'inscritos' => array($i['nome']),
                    'tel' => $tel,
                    'link' => $link,
                    'whats' => $tel ? 'https://wa.me/' . $tel . '?text=' . rawurlencode($msg) : '',
                );
            }
            return $out;
        },
    ));
    register_rest_route('zoe/v1', '/checkin/links/(?P<id>[a-z0-9]+)', array(
        'methods' => 'DELETE',
        'permission_callback' => $equipe,
        'callback' => function ($q) {
            $todos = zoe_ci_links();
            if (!isset($todos[$q['id']])) {
                return new WP_Error('nao', 'Link não encontrado', array('status' => 404));
            }
            unset($todos[$q['id']]);
            update_option('zoe_ci_links', $todos, false);
            return array('ok' => true);
        },
    ));
});

/* ================= Páginas (leitor e ingresso) ================= */

function zoe_ci_cabeca($titulo)
{
    nocache_headers();
    do_action('litespeed_control_set_nocache', 'zoe check-in');
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    $logo = function_exists('zoe_img') && function_exists('zoe_opt') ? zoe_img(zoe_opt('logo'), 'thumbnail') : '';
    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#141216">'
        . '<title>' . esc_html($titulo) . ' · Zoe Church</title>'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap">'
        . ($logo ? '<link rel="icon" href="' . esc_url($logo) . '">' : '')
        . '<link rel="stylesheet" href="' . esc_url(get_template_directory_uri() . '/assets/checkin.css?v=' . ZOE_TEMA_V) . '">'
        . '</head>';
    return $logo;
}

add_action('template_redirect', function () {
    // ---- Leitor de check-in ----
    if (isset($_GET['zoe_checkin'])) { // phpcs:ignore
        $tok = preg_replace('/[^A-Za-z0-9]/', '', (string) wp_unslash($_GET['zoe_checkin'])); // phpcs:ignore
        $l = zoe_ci_link_por_token($tok);
        $logo = zoe_ci_cabeca('Check-in');
        if (!$l) {
            echo '<body class="ci-body"><main class="ci-vazio"><h1>Link inválido</h1><p>Este link de check-in foi revogado ou está incompleto. Peça um novo link a quem administra o site (Painel → Check-in).</p></main></body></html>';
            exit;
        }
        $cfg = array('api' => rest_url('zoe/v1/ci/' . $tok . '/'), 'nome' => $l['nome']);
        echo '<body class="ci-body"><div class="ci-app" id="app">'
            . '<header class="ci-topo">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="" class="ci-logo">' : '') . '<div><div class="ci-eyebrow">Check-in · ' . esc_html($l['nome']) . '</div><div class="ci-titulo">Zoe <em>Church</em></div></div></header>'
            . '<section class="ci-placar" id="placar"></section>'
            . '<nav class="ci-abas"><button class="on" data-aba="ler">Ler QR Code</button><button data-aba="buscar">Buscar nome</button><button data-aba="ultimos">Últimos</button></nav>'
            . '<section class="ci-aba on" id="aba-ler"><div class="ci-camera" id="camera"><video id="video" playsinline muted></video><div class="ci-mira"></div><button class="ci-ligar" id="ligar"><span>Toque para ligar a câmera</span></button></div>'
            . '<form class="ci-codigo" id="formCodigo"><input id="codigoManual" placeholder="Ou digite o código (ex.: Z5XH-8VQ-1-…)" autocapitalize="characters" autocomplete="off"><button>OK</button></form></section>'
            . '<section class="ci-aba" id="aba-buscar"><input class="ci-busca" id="busca" placeholder="Nome, telefone ou nº do pedido" autocomplete="off"><div id="resultados" class="ci-lista"><p class="ci-dica">Para quem não recebeu ou não trouxe o QR Code: busque e faça o check-in manual.</p></div></section>'
            . '<section class="ci-aba" id="aba-ultimos"><div id="ultimos" class="ci-lista"></div></section>'
            . '</div><div class="ci-resultado" id="resultado"></div>'
            . '<script>window.ZCI=' . wp_json_encode($cfg) . ';</script>'
            . '<script src="' . esc_url(get_template_directory_uri() . '/assets/jsqr.js?v=1.4.0') . '"></script>'
            . '<script src="' . esc_url(get_template_directory_uri() . '/assets/checkin.js?v=' . ZOE_TEMA_V) . '"></script>'
            . '</body></html>';
        exit;
    }

    // ---- Ingresso na web (link do e-mail) ----
    if (isset($_GET['zoe_ingresso'])) { // phpcs:ignore
        $v = (string) wp_unslash($_GET['zoe_ingresso']); // phpcs:ignore
        $oid = 0;
        if (preg_match('/^(\d+)-([0-9A-Fa-f]{12})$/', $v, $m) && hash_equals(zoe_ci_assinar('ing|' . $m[1], 12), strtoupper($m[2]))) {
            $oid = (int) $m[1];
        }
        $o = $oid ? wc_get_order($oid) : null;
        $ings = $o ? zoe_ci_ingressos($o) : array();
        $logo = zoe_ci_cabeca(count($ings) > 1 ? 'Seus ingressos' : 'Seu ingresso');
        echo '<body class="ci-body ci-ingresso-pag"><main class="ci-ingressos">';
        echo '<header class="ci-topo">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="" class="ci-logo">' : '') . '<div><div class="ci-eyebrow">' . (count($ings) > 1 ? 'Seus ingressos' : 'Seu ingresso') . '</div><div class="ci-titulo">Zoe <em>Church</em></div></div></header>';
        if (!$ings) {
            echo '<div class="ci-vazio"><h1>Ingresso não encontrado</h1><p>O link pode estar incompleto, ou o pagamento ainda não foi confirmado. Na dúvida, diga seu nome na recepção.</p></div>';
        } else {
            echo '<p class="ci-intro">Mostre o QR Code na entrada. ' . (count($ings) > 1 ? 'Cada pessoa tem o seu. ' : '') . 'Aumente o brilho da tela para ler mais rápido.</p>';
            $reg = zoe_ci_registros(wp_list_pluck($ings, 'codigo'));
            foreach ($ings as $i) {
                $quando = zoe_conf_quando((string) get_post_meta($i['pid'], '_zoe_data', true), (string) get_post_meta($i['pid'], '_zoe_data_fim', true));
                $local = (string) get_post_meta($i['pid'], '_zoe_local', true);
                $meta = array_filter(array($i['opcao'], $quando ? ucfirst($quando) : '', $local));
                $r = isset($reg[$i['codigo']]) ? $reg[$i['codigo']] : null;
                echo '<article class="ci-card"><div class="ci-eyebrow">Ingresso · ' . esc_html($i['evento']) . '</div><h2>' . esc_html($i['nome']) . '</h2>'
                    . ($meta ? '<p class="ci-meta">' . esc_html(implode(' · ', $meta)) . '</p>' : '')
                    . '<div class="ci-qr">' . Zoe_QR::svg($i['codigo'], 2) . '</div>' // phpcs:ignore
                    . '<p class="ci-cod">' . esc_html($i['codigo']) . '</p>'
                    . ($r ? '<p class="ci-feito">✓ Check-in feito ' . esc_html(wp_date('d/m \à\s H:i', (int) $r['quando'])) . '</p>' : '')
                    . '</article>';
            }
        }
        echo '</main></body></html>';
        exit;
    }
}, 0);
