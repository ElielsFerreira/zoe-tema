/* Leitor de check-in da Zoe. Usa o leitor nativo do navegador (BarcodeDetector) quando existe e o jsQR no resto (iPhone). */
(function () {
  'use strict';
  var C = window.ZCI || {};
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  function api(rota, corpo) {
    var op = corpo ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) } : {};
    return fetch(C.api + rota, op).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) throw new Error((j && j.message) || 'Erro ' + r.status);
        return j;
      });
    });
  }

  /* ---------- placar ---------- */
  function placar() {
    return api('resumo').then(function (d) {
      $('#placar').innerHTML = (d.eventos || []).map(function (e) {
        var p = e.total ? Math.min(100, Math.round(e.presentes * 100 / e.total)) : 0;
        return '<div class="ci-ev"><b>' + esc(e.nome) + '</b><div class="num"><strong>' + e.presentes + '</strong><span>de ' + e.total + ' presentes</span></div><div class="ci-barra"><i style="width:' + p + '%"></i></div></div>';
      }).join('');
      $('#ultimos').innerHTML = (d.ultimos || []).length ? d.ultimos.map(function (u) {
        return '<div class="ci-pessoa"><div class="info"><b>' + esc(u.nome) + '</b><small>' + esc([u.evento, u.opcao].filter(Boolean).join(' · ')) + '</small><small class="ok">✓ ' + esc(u.quando) + ' · ' + (u.modo === 'manual' ? 'manual' : 'QR') + ' · ' + esc(u.por) + '</small></div>' +
          '<button class="ci-btn sec" data-desfazer=\'' + esc(JSON.stringify({ pedido: u.pedido, item: u.item, vaga: u.vaga })) + '\'>Desfazer</button></div>';
      }).join('') : '<p class="ci-dica">Nenhum check-in ainda.</p>';
    }).catch(function () {});
  }
  setInterval(function () { if (!document.hidden) placar(); }, 15000);
  placar();

  /* ---------- abas ---------- */
  $$('[data-aba]').forEach(function (b) {
    b.onclick = function () {
      $$('[data-aba]').forEach(function (x) { x.classList.toggle('on', x === b); });
      $$('.ci-aba').forEach(function (x) { x.classList.toggle('on', x.id === 'aba-' + b.dataset.aba); });
      if (b.dataset.aba === 'buscar') setTimeout(function () { $('#busca').focus(); }, 50);
      if (b.dataset.aba === 'ultimos') placar();
    };
  });

  /* ---------- som e vibração ---------- */
  var audio;
  function bip(freq, dur) {
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      var o = audio.createOscillator(), g = audio.createGain();
      o.frequency.value = freq; o.connect(g); g.connect(audio.destination);
      g.gain.setValueAtTime(0.25, audio.currentTime); g.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + dur);
      o.start(); o.stop(audio.currentTime + dur);
    } catch (e) {}
  }
  function vibra(p) { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} }

  /* ---------- resultado em tela cheia ---------- */
  var pausado = false, timer;
  function mostrar(r) {
    var el = $('#resultado'), tipo, ico, tit, nome = '', det = '', acoes = '';
    if (r.status === 'ok') {
      tipo = 'ok'; ico = '✓'; tit = 'Liberado'; nome = r.nome; det = esc([r.evento, r.opcao].filter(Boolean).join(' · '));
      acoes = '<button data-desfazer=\'' + esc(JSON.stringify({ pedido: r.pedido, item: r.item, vaga: r.vaga })) + '\'>Desfazer</button><button class="forte" id="continuar">Próximo</button>';
      bip(1046, 0.18); vibra(90);
    } else if (r.status === 'ja') {
      tipo = 'ja'; ico = '!'; tit = 'Já fez check-in'; nome = r.nome; det = esc('Entrou às ' + r.quando + (r.dia ? ' (' + r.dia + ')' : '') + (r.por ? ' · ' + r.por : '')) + '<br>' + esc([r.evento, r.opcao].filter(Boolean).join(' · '));
      acoes = '<button class="forte" id="continuar">Continuar</button>';
      bip(660, 0.15); setTimeout(function () { bip(660, 0.15); }, 200); vibra([80, 60, 80]);
    } else {
      tipo = 'erro'; ico = '✕'; tit = r.status === 'outro' ? 'Outro evento' : r.status === 'naopago' ? 'Pagamento não confirmado' : 'Ingresso inválido'; det = esc(r.msg || r.message || 'Não foi possível validar.');
      acoes = '<button class="forte" id="continuar">Continuar</button>';
      bip(220, 0.45); vibra(400);
    }
    el.className = 'ci-resultado on ' + tipo;
    el.innerHTML = '<div class="ico">' + ico + '</div><div class="tit">' + tit + '</div>' + (nome ? '<div class="nome">' + esc(nome) + '</div>' : '') + '<div class="det">' + det + '</div><div class="acoes">' + acoes + '</div>';
    pausado = true;
    clearTimeout(timer);
    if (r.status === 'ok') timer = setTimeout(fechar, 2600);
    $('#continuar').onclick = fechar;
    ligarDesfazer(el);
    placar();
  }
  function fechar() { clearTimeout(timer); $('#resultado').className = 'ci-resultado'; pausado = false; ultimoCod = ''; }

  function ligarDesfazer(raiz) {
    Array.prototype.forEach.call(raiz.querySelectorAll('[data-desfazer]'), function (b) {
      b.onclick = function (ev) {
        ev.stopPropagation();
        if (!confirm('Desfazer este check-in?')) return;
        api('desfazer', JSON.parse(b.dataset.desfazer)).then(function () { fechar(); placar(); if ($('#busca').value.trim()) buscar(); }).catch(function (e) { alert(e.message); });
      };
    });
  }

  function validar(codigo) {
    pausado = true;
    api('ler', { codigo: codigo }).then(mostrar).catch(function (e) { mostrar({ status: 'invalido', msg: e.message === 'Failed to fetch' ? 'Sem internet. Confira a conexão e tente de novo.' : e.message }); });
  }

  /* ---------- câmera ---------- */
  var video = $('#video'), canvas = document.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
  var detector = null, ultimoCod = '', ultimoQuando = 0, rodando = false;
  if ('BarcodeDetector' in window) {
    try { detector = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) { detector = null; }
  }
  function lido(txt) {
    if (!txt || pausado) return;
    var agora = Date.now();
    if (txt === ultimoCod && agora - ultimoQuando < 4000) return;
    ultimoCod = txt; ultimoQuando = agora;
    validar(txt);
  }
  function quadro() {
    if (!rodando) return;
    if (!pausado && video.readyState >= 2) {
      if (detector) {
        detector.detect(video).then(function (r) { if (r && r[0]) lido(r[0].rawValue); }).catch(function () {});
      } else if (window.jsQR) {
        var w = video.videoWidth, h = video.videoHeight, s = Math.min(1, 640 / Math.max(w, h));
        canvas.width = Math.round(w * s); canvas.height = Math.round(h * s);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        var img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        var q = window.jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
        if (q && q.data) lido(q.data);
      }
    }
    setTimeout(function () { requestAnimationFrame(quadro); }, 160);
  }
  $('#ligar').onclick = function () {
    try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); audio.resume && audio.resume(); } catch (e) {}
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { alert('Este navegador não libera a câmera. Use o Chrome ou o Safari atualizado, ou a busca por nome.'); return; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 1280 } }, audio: false }).then(function (st) {
      video.srcObject = st; video.play();
      $('#ligar').style.display = 'none';
      rodando = true; quadro();
    }).catch(function () { alert('Não foi possível usar a câmera. Confira a permissão de câmera do navegador para este site.'); });
  };

  /* ---------- código digitado ---------- */
  $('#formCodigo').onsubmit = function (e) {
    e.preventDefault();
    var v = $('#codigoManual').value.trim().toUpperCase();
    if (v) { validar(v); $('#codigoManual').value = ''; }
  };

  /* ---------- busca e check-in manual ---------- */
  var tBusca;
  function buscar() {
    var q = $('#busca').value.trim();
    if (q.length < 2) { $('#resultados').innerHTML = '<p class="ci-dica">Para quem não recebeu ou não trouxe o QR Code: busque e faça o check-in manual.</p>'; return; }
    api('buscar?q=' + encodeURIComponent(q)).then(function (l) {
      if (!l.length) { $('#resultados').innerHTML = '<p class="ci-dica">Ninguém encontrado com “' + esc(q) + '”. Confira se a inscrição foi paga (no Painel, em Inscrições).</p>'; return; }
      $('#resultados').innerHTML = l.map(function (p) {
        var chave = esc(JSON.stringify({ pedido: p.pedido, item: p.item, vaga: p.vaga }));
        var sub = [p.evento, p.opcao].filter(Boolean).join(' · ');
        var quem = (p.comprador && p.comprador !== p.nome ? 'Responsável: ' + p.comprador + ' · ' : '') + 'Pedido ' + p.pedido + (p.qtd > 1 ? ' · vaga ' + p.vaga + ' de ' + p.qtd : '');
        return '<div class="ci-pessoa"><div class="info"><b>' + esc(p.nome) + '</b><small>' + esc(sub) + '</small><small>' + esc(quem) + '</small>' +
          (p.checkin ? '<small class="ok">✓ Entrou às ' + esc(p.checkin.quando) + ' · ' + esc(p.checkin.por) + '</small>' : '') + '</div>' +
          (p.checkin ? '<button class="ci-btn sec" data-desfazer=\'' + chave + '\'>Desfazer</button>' : '<button class="ci-btn" data-marcar=\'' + chave + '\'>Check-in</button>') + '</div>';
      }).join('');
      $$('[data-marcar]').forEach(function (b) {
        b.onclick = function () {
          b.disabled = true;
          api('marcar', JSON.parse(b.dataset.marcar)).then(function (r) { mostrar(r); buscar(); }).catch(function (e) { alert(e.message); b.disabled = false; });
        };
      });
      ligarDesfazer($('#resultados'));
    }).catch(function (e) { $('#resultados').innerHTML = '<p class="ci-dica">' + esc(e.message) + '</p>'; });
  }
  $('#busca').oninput = function () { clearTimeout(tBusca); tBusca = setTimeout(buscar, 300); };
  ligarDesfazer($('#ultimos'));
  new MutationObserver(function () { ligarDesfazer($('#ultimos')); }).observe($('#ultimos'), { childList: true });
})();
